const https = require('https');
const jsonexport = require('jsonexport');
const fs = require('fs');
const util = require('util');
const { exec } = require('child_process');

const log_file = fs.createWriteStream(__dirname + '/debug.log', {flags : 'a'});
const log_stdout = process.stdout;
logging = function(d) { //
  log_file.write(util.format(d) + '\n');
  log_stdout.write(util.format(d) + '\n');
};
const currentdate = new Date(); 
const datetime = currentdate.getDate() + "/"
                + (currentdate.getMonth()+1)  + "/" 
                + currentdate.getFullYear() + " @ "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds() + " " ;

const data = JSON.stringify({
});

const options = {
    hostname: 'bayer.tinosstech.com',
    path: '/getsamplemy',
    method: 'GET',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
    }
};

const req = https.request(options, (res) => {
    let data = '';

    logging(datetime+'MY Data Status Code:'+ res.statusCode);

    res.on('data', (chunk) => {
        data += chunk;
    });

    res.on('end', () => {

        logging(datetime+ 'MY Data Success GET');

        jsonexport(JSON.parse(data), function(err, csv) {
          if (err) return console.error(err);
          fs.writeFile('sales_invoice_my_r_data.csv', csv, function(err) {
            if (err) return console.error(err);
            logging(datetime+ 'sales_invoice_my_r_data.csv saved');
          });
        });

        var cmdString = 'mysql -u debian-sys-maint -ptqExB0kMtYzlfQML sampledb -e "SET GLOBAL local_infile=1;"; mysql -u debian-sys-maint -ptqExB0kMtYzlfQML sampledb -e "delete from sales_invoice_my_r_data;"; mysqlimport --ignore-lines=1 --fields-terminated-by=, --fields-optionally-enclosed-by=\\" --local -u debian-sys-maint -ptqExB0kMtYzlfQML sampledb /mnt/data/html/portal/sales_invoice_my_r_data.csv;';
        
        var yourscript = exec(cmdString,
          (error, stdout, stderr) => {
              logging(datetime+ stdout);
              logging(datetime+ stderr);
              if (error !== null) {
                  logging(datetime+ `exec error: ${error}`);
              }
          });
    });

}).on("error", (err) => {
    logging(datetime+ "Error: "+ err.message);
});
//req.write(data);
req.end();

const options2 = {
    hostname: 'bayer.tinosstech.com',
    path: '/getsamplesg',
    method: 'GET',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
    }
};

const req2 = https.request(options2, (res) => {
    let data = '';

    logging(datetime+'SG Data Status Code:'+ res.statusCode);

    res.on('data', (chunk) => {
        data += chunk;
    });

    res.on('end', () => {

        logging(datetime+ 'SG Data Success GET');

        jsonexport(JSON.parse(data), function(err, csv) {
          if (err) return console.error(err);
          fs.writeFile('sales_invoice_sg_r_data.csv', csv, function(err) {
            if (err) return console.error(err);
            logging(datetime+ 'sales_invoice_sg_r_data.csv saved');
          });
        });

        var cmdString = 'mysql -u debian-sys-maint -ptqExB0kMtYzlfQML sampledb -e "SET GLOBAL local_infile=1;"; mysql -u debian-sys-maint -ptqExB0kMtYzlfQML sampledb -e "delete from sales_invoice_sg_r_data;"; mysqlimport --ignore-lines=1 --fields-terminated-by=, --fields-optionally-enclosed-by=\\" --local -u debian-sys-maint -ptqExB0kMtYzlfQML sampledb /mnt/data/html/portal/sales_invoice_sg_r_data.csv;';
        
        var yourscript = exec(cmdString,
          (error, stdout, stderr) => {
              logging(datetime+ stdout);
              logging(datetime+ stderr);
              if (error !== null) {
                  logging(datetime+ `exec error: ${error}`);
              }
          });
    });

}).on("error", (err) => {
    logging(datetime+ "Error: "+ err.message);
});

//req2.write(data);
req2.end();
