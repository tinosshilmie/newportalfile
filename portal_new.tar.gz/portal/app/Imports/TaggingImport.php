<?php
namespace App\Imports;

use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\ToArray;
use DB;
use Auth;

class TaggingImport implements ToCollection
{
    /**
     * @param array $row
     *
     * @return User|null
     */
    public function collection(Collection $rows)
    {
               return $rows;
      /*echo "<pre>";
        var_dump($rows[1][2]);

        var_dump($rows[1][2]);*/
        /*foreach ($rows as $row)
        {
          /*DB::select(DB::raw("
              update `sales.Target_dtl`
              set fc_temp = ".(float)$row[4]."
              where id = ".$row[0]."
              ;"
          ));
        }*/
    }

}
?>
