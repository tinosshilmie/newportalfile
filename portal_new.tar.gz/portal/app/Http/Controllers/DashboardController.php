<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use Auth;
use DB;
use Session;
class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
 
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

   public function updatelog($type) {
     $query = DB::select(DB::raw("
       insert into `master.accesslog`
       values (null,'".Auth::user()->id."',now(),'".$type."')
       ;"
     ));
   }
  public function getdashboard(Request $data)
  {
    $this->updatelog('View dashboard');
    if(Auth::user()->territorytypeid==0){
      $where = "and 1=1";
    }elseif(Auth::user()->territorytypeid==1){
      if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
        $where = "and nsmid in (1,2)";
      }else{
        $where = "and nsmid = ".Auth::user()->territoryid;
      }
    }elseif(Auth::user()->territorytypeid==2){
      $where = "and flmid = ".Auth::user()->territoryid;
    }elseif(Auth::user()->territorytypeid==3){
      $where = "and mrid = ".Auth::user()->territoryid;
    }
    if(Session::get('ka')==0){
      $targettablename = "`sales.portal_target_trail`";
    }else{
      $targettablename = "`sales.portal_target2_trail`";
    }

    $data['lyyear'] = $data['year']-1;
    $currentYear = date('Y');

    $whereyear = " AND year in ( ".$data['lyyear'].", ".($data['lyyear']+1)." ) ";
    $whereyear2 = "and a.year in ( ".$data['year'].") ";
    $whereffyear = " AND ffyear=".$currentYear;

    $periodlist;
    if($data['period']!=""){
      $periodlist = explode(" ", $data['period']);
    }else{
      $periodlist = array(date('n'));
    }
    //$whereperiod = "AND a.period IN ( ".end($periodlist)." ) ";
    $whereperiod = "AND a.period IN ( ".$data['period']." ) ";
    $whereperiod2 = "and a.period <= ".end($periodlist)."";

    //dd($periodlist);
    if($data['mrid']!=""){
      $wheremr = "and a.mrid in ( ".$data['mrid'].")";
    }else{
      $wheremr = "and 1=1";
    }
    if($data['flmid']!=""){
      $whereflm = "and a.flmid in ( ".$data['flmid'].")";
    }else{
      $whereflm = "and 1=1";
    }
    if($data['productgroupid']!=""){
      $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
    }else{
      $whereproductgroup = "and 1=1";
    }
    if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
    }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
    }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
    if($data['seq']!=""){
      $whereseq = "and a.seq in ( ".$data['seq'].")";
    }else{
      $whereseq = "and 1=1";
    }
    if($data['tgttype']!=""){
      $wheretgttype = "and a.tgttypeid in ( ".$data['tgttype'].")";
    }else{
      $wheretgttype = "and 1=1";
    }
    if($data['salesline']!=""){
      $wheresalesline = "and a.saleslineid in ( ".$data['salesline'].")";
    }else{
      $wheresalesline = "and 1=1";
    }

    //$mtd = "SUM(IF(year=".$data['year']." and period=".end($periodlist).", sls, 0)) as 'mtd'";
    //$lymtd = "SUM(IF(year=".$data['lyyear']." and period=".end($periodlist).", sls, 0)) as 'lymtd'";
    $mtd = "SUM(IF(year=".$data['year']." and period in (".$data['period']."), sls, 0)) as 'mtd'";
    $lymtd = "SUM(IF(year=".$data['lyyear']." and period in (".$data['period']."), sls, 0)) as 'lymtd'";
    $cytd = "SUM(IF(year=".$data['year']." and period<=".end($periodlist).", sls, 0)) as 'cytd'";
    $lytd = "SUM(IF(year=".$data['lyyear']." and period<=".end($periodlist).", sls, 0)) as 'lytd'";

    $data['mtdtarget'] = DB::select(DB::raw("
       SELECT round(sum(tgt)) as tgt
       FROM ".$targettablename." a
       where true
       ".$where."
       ".$whereyear."
       ".$whereffyear."
       ".$whereperiod."
       ".$wheremr."
       ".$whereflm."
       ".$whereproductgroup."
       ".$wherechanneltgt."
       ".$wherebu."
       ".$wheretgttype."
       ".$wheresalesline."
       ;"
    ));

    $data['ytdtarget'] = DB::select(DB::raw("
       SELECT round(sum(tgt)) as tgt
       FROM ".$targettablename." a
       where true
       ".$where."
       ".$whereyear."
       ".$whereffyear."
       ".$whereperiod2."
       ".$wheremr."
       ".$whereflm."
       ".$whereproductgroup."
       ".$wherechanneltgt."
       ".$wherebu."
       ".$wheretgttype."
       ".$wheresalesline."
       ;"
    ));

    $query =
      "SELECT
      ".$mtd.",
      ".$lymtd.",
      ".$cytd.",
      ".$lytd."
      FROM `sales.portal_invoice_trail` a
      WHERE true
      ".$where."
      ".$whereseq ."
      ".$whereyear."
      ".$whereperiod2."
      ".$wheremr."
      ".$whereflm."
      ".$whereproductgroup."
      ".$wherechannel."
      ".$wherebu."
      ".$wheresubchannel2."
      ".$wheresource."
      ".$whereffyear."
      ".$wheresalesline."
    ;";
     //echo json_encode($query); exit();
    $result =  DB::select(DB::raw($query));



    $data['mtdsales'] = round($result[0]->mtd);
    $data['lymtdsales'] = round($result[0]->lymtd);
    $data['cytdsales'] = round($result[0]->cytd);
    $data['lytdsales'] = round($result[0]->lytd);

    if((int)$data['mtdtarget'][0]->tgt != 0){
      $data['perf'] = round(($data['mtdsales']/$data['mtdtarget'][0]->tgt) * 100);
    }else{
      $data['perf'] = 100;
    }
    if((int)$data['ytdtarget'][0]->tgt != 0){
      $data['perf2'] = round(($data['cytdsales']/$data['ytdtarget'][0]->tgt) * 100);
    }else{
      $data['perf2'] = 100;
    }

    if((int)$data['lymtdsales'] != 0){
      $data['growth'] = round(($data['mtdsales']/$data['lymtdsales']) * 100);
    }else{
      $data['growth'] = 100;
    }
    if((int)$data['lytdsales'] != 0){
      $data['growth2'] = round(($data['cytdsales']/$data['lytdsales']) * 100);
    }else{
      $data['growth2'] = 100;
    }
    // echo json_encode($data); exit();
    return response()->json($data);
  }

  public function getdashboard2(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mrid = ".Auth::user()->territoryid;
      }

      if(Session::get('ka')==0){
        $targettablename = "`sales.portal_target_trail`";
      }else{
        $targettablename = "`sales.portal_target2_trail`";
      }
    $data['lyyear'] = $data['year']-1;
    $currentYear = date('Y');

    $whereyear = " AND year in ( ".$data['lyyear'].", ".($data['lyyear']+1)." ) ";
    $whereyear2 = "and a.year in ( ".$data['year'].") ";
    $whereffyear = " AND ffyear=".$currentYear;

    $periodlist;
    if($data['period']!=""){
      $periodlist = explode(" ", $data['period']);
    }else{
      $periodlist = array(date('n'));
    }
    $whereperiod = "AND a.period IN ( ".end($periodlist)." ) ";
    $whereperiod2 = "and a.period <= ".end($periodlist)."";

    // $data['lyyear'] = $data['year']-1;
    // if($data['year']!=""){
    //   $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
    //   $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
    // }else{
    //   $whereyear = "and 1=1";
    //   $whereyear2 = "and 1=1";
    // }
    // if($data['period']!=""){
    //   $whereperiod = "and a.period in ( ".$data['period'].")";
    //   $whereperiod2 = "and a.period <= ".$data['period']."";
    // }else{
    //   $whereperiod = "and 1=1";
    //   $whereperiod2 = "and 1=1";
    // }

    if($data['mrid']!=""){
      $wheremr = "and a.mrid in ( ".$data['mrid'].")";
    }else{
      $wheremr = "and 1=1";
    }

    if($data['flmid']!=""){
      $whereflm = "and a.flmid in ( ".$data['flmid'].")";
    }else{
      $whereflm = "and 1=1";
    }

    if($data['productgroupid']!=""){
      $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
    }else{
      $whereproductgroup = "and 1=1";
    }

    if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
    }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
    }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
    if($data['seq']!=""){
      $whereseq = "and a.seq in ( ".$data['seq'].")";
    }else{
      $whereseq = "and 1=1";
    }
    if($data['tgttype']!=""){
      $wheretgttype = "and a.tgttypeid in ( ".$data['tgttype'].")";
    }else{
      $wheretgttype = "and 1=1";
    }
    if($data['salesline']!=""){
      $wheresalesline = "and a.saleslineid in ( ".$data['salesline'].")";
    }else{
      $wheresalesline = "and 1=1";
    }

    $sls = "SUM(IF(year=".$data['year'].", sls, 0)) as 'sls'";
    $lysls = "SUM(IF(year=".$data['lyyear'].", sls, 0)) as 'lysls'";
    $tgt = "SUM(IF(year=".$data['year'].", tgt, 0)) as 'tgt'";

    $query = DB::select(DB::raw("
      SELECT sum(a.sls) as sls,sum(a.tgt) as tgt ,(sum(sls)/sum(tgt)) * 100 as perf ,(sum(a.sls)/sum(a.lysls)) * 100 as growth
      FROM (
        SELECT $sls, $lysls,0 as tgt, period, year, mrid
        FROM `sales.portal_invoice_trail` a
        WHERE true
        ".$whereseq."
        ".$where."
        ".$whereyear."
        ".$whereffyear."
        ".$whereperiod2."
        ".$wheremr."
        ".$whereflm."
        ".$whereproductgroup."
        ".$wherechannel."
        ".$wherebu."
        ".$wheresubchannel2."
        ".$wheresource."
        ".$wheresalesline."
        GROUP BY period,year,mrid
        union
        SELECT 0 as sls,0 as lysls, $tgt,period,year,mrid
        FROM ".$targettablename." a
        WHERE true
        ".$where."
        ".$whereyear."
        ".$whereffyear."
        ".$wheremr."
        ".$whereflm."
        ".$whereproductgroup."
        ".$wherechanneltgt."
        ".$wherebu."
        ".$wheretgttype."
        ".$wheresalesline."
        GROUP BY period,year,mrid
      )  a
      WHERE TRUE
      GROUP BY a.period
      ORDER BY a.period
    ;"));

    /*
    $query = DB::select(DB::raw("
        SELECT sum(a.sls) as sls,sum(b.tgt) as tgt ,(sum(sls)/sum(tgt)) * 100 as perf ,(sum(a.sls)/sum(c.lysls)) * 100 as growth
         FROM (
           select sum(sls) as sls,period,year,mrid
           from `sales.portal_invoice_trail` a
           where true
           ".$whereseq."
           ".$where."
           "
           .$whereyear.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           group by period,year,mrid
           ) a
         left join (
           select sum(tgt) as tgt,period,year,mrid
           from `sales.portal_target_trail` a
           where true
           ".$where."
           "
           .$whereyear.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechanneltgt.
           "
           "
           .$wherebu.
           "
           group by period,year,mrid
           ) b on a.mrid = b.mrid and a.year = b.year and a.period = b.period
         left join (
           select sum(sls) as lysls,period,year,mrid
           from `sales.portal_invoice_trail` a
           where true
           ".$whereseq."
           ".$where."
           "
           .$whereyear2.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           group by period,year,mrid
           ) c on a.mrid = c.mrid and a.period = c.period
        where true
        group by a.period
        order by a.period
        ;"
     ));
    */
    $counter1 = 0;
    $salesarray = array();
    $targetarray = array();
    $perfarray = array();
    $growtharray = array();
    foreach($query as $key => $val){
      $salesarray[$counter1]=round($val->sls);
      $targetarray[$counter1]=round($val->tgt);
      $perfarray[$counter1]=round($val->perf);
      $growtharray[$counter1]=round($val->growth);
      $counter1 = $counter1 + 1;
    }
    $data['sales'] = json_encode($salesarray);
    $data['target'] = json_encode($targetarray);
    $data['perf'] = json_encode($perfarray);
    $data['growth'] = json_encode($growtharray);
    return response()->json($data);
  }

  public function getdashboard3(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
      $where = "and 1=1";
    }elseif(Auth::user()->territorytypeid==1){
      if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
        $where = "and nsmid in (1,2)";
      }else{
        $where = "and nsmid = ".Auth::user()->territoryid;
      }
    }elseif(Auth::user()->territorytypeid==2){
      $where = "and flmid = ".Auth::user()->territoryid;
    }elseif(Auth::user()->territorytypeid==3){
      $where = "and mrid = ".Auth::user()->territoryid;
    }

    if(Session::get('ka')==0){
      $targettablename = "`sales.portal_target_trail`";
    }else{
      $targettablename = "`sales.portal_target2_trail`";
    }
    $data['lyyear'] = $data['year']-1;
    $currentYear = date('Y');

    $whereyear = " AND year in ( ".$data['lyyear'].", ".($data['lyyear']+1)." ) ";
    $whereyear2 = "and a.year in ( ".$data['year'].") ";
    $whereffyear = " AND ffyear=".$currentYear;

    $periodlist;
    if($data['period']!=""){
      $periodlist = explode(" ", $data['period']);
    }else{
      $periodlist = array(date('n'));
    }
    $whereperiod = "AND a.period IN ( ".end($periodlist)." ) ";
    $whereperiod2 = "and a.period <= ".end($periodlist)."";

    // $data['lyyear'] = $data['year']-1;
    // if($data['year']!=""){
    //   $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
    //   $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
    // }else{
    //   $whereyear = "and 1=1";
    //   $whereyear2 = "and 1=1";
    // }
    // if($data['period']!=""){
    //   $whereperiod = "and a.period in ( ".$data['period'].")";
    //   $whereperiod2 = "and a.period <= ".$data['period']."";
    // }else{
    //   $whereperiod = "and 1=1";
    //   $whereperiod2 = "and 1=1";
    // }

    if($data['mrid']!=""){
     $wheremr = "and a.mrid in ( ".$data['mrid'].")";
    }else{
      $wheremr = "and 1=1";
    }

    if($data['flmid']!=""){
      $whereflm = "and a.flmid in ( ".$data['flmid'].")";
    }else{
      $whereflm = "and 1=1";
    }

    if($data['productgroupid']!=""){
      $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
    }else{
      $whereproductgroup = "and 1=1";
    }

    if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
    }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
    }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
    if($data['seq']!=""){
      $whereseq = "and a.seq in ( ".$data['seq'].")";
    }else{
      $whereseq = "and 1=1";
    }
    if($data['tgttype']!=""){
      $wheretgttype = "and a.tgttypeid in ( ".$data['tgttype'].")";
    }else{
      $wheretgttype = "and 1=1";
    }
    if($data['salesline']!=""){
      $wheresalesline = "and a.saleslineid in ( ".$data['salesline'].")";
    }else{
      $wheresalesline = "and 1=1";
    }

    $query = DB::select(DB::raw("
       SELECT sum(a.sls) as sls,productgroup
        FROM `sales.portal_invoice_trail` a
       where true
       ".$whereseq."
       ".$where."
       ".$whereyear."
       ".$whereffyear."
       ".$whereperiod."
       ".$wheremr."
       ".$whereflm."
       ".$whereproductgroup."
       ".$wherechannel."
       ".$wherebu."
       ".$wheresubchannel2."
       ".$wheresource."
       ".$wheresalesline."
       group by productgroup
       ;"
    ));
    /*
    $query = DB::select(DB::raw("
       SELECT sum(a.sls) as sls,productgroup,b.sls as total
        FROM `sales.portal_invoice_trail` a, (
          SELECT sum(a.sls) as sls
           FROM `sales.portal_invoice_trail` a
          where true
          ".$whereseq."
          ".$where."
          "
          .$whereyear.
          "
          "
          .$whereperiod.
          "
          "
          .$wheremr.
          "
          "
          .$whereflm.
          "
          "
          .$whereproductgroup.
          "
          "
          .$wherechannel.
          "
          "
          .$wherebu.
          "
          "
          .$wheresubchannel2.
          "
          "
          .$wheresource.
          "
          ) b
       where true
       ".$whereseq."
       ".$where."
       "
       .$whereyear.
       "
       "
       .$whereperiod.
       "
       "
       .$wheremr.
       "
       "
       .$whereflm.
       "
       "
       .$whereproductgroup.
       "
       "
       .$wherechannel.
       "
       "
       .$wherebu.
       "
       "
       .$wheresubchannel2.
       "
       "
       .$wheresource.
       "
       group by productgroup,b.sls
       ;"
    ));
    */

    $counter1 = 0;
    $salesarray = array();
    $labelarray = array();
    $total = 0;

    foreach($query as $key => $val){
        $salesarray[$counter1]=round($val->sls);
        $labelarray[$counter1]=($val->productgroup);
        $counter1 = $counter1 + 1;
        $total += $val->sls;
    }

    $data['sales'] = json_encode($salesarray);
    $data['total'] = json_encode($total);
    $data['label'] = json_encode($labelarray);

     return response()->json($data);
  }

  public function getdashboard4(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mrid = ".Auth::user()->territoryid;
      }
      if(Session::get('ka')==0){
        $targettablename = "`sales.portal_target_trail`";
      }else{
        $targettablename = "`sales.portal_target2_trail`";
      }
      $data['lyyear'] = $data['year']-1;
      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
        $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
      }else{
        $whereyear = "and 1=1";
        $whereyear2 = "and 1=1";
      }
      if($data['period']!=""){
        $whereperiod = "and a.period in ( ".$data['period'].")";
        $whereperiod2 = "and a.period <= ".$data['period']."";
      }else{
        $whereperiod = "and 1=1";
        $whereperiod2 = "and 1=1";
      }

     if($data['mrid']!=""){
       $wheremr = "and a.mrid in ( ".$data['mrid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['flmid']!=""){
       $whereflm = "and a.flmid in ( ".$data['flmid'].")";
     }else{
       $whereflm = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }


     if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
     }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
     }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
    if($data['seq']!=""){
      $whereseq = "and a.seq in ( ".$data['seq'].")";
    }else{
      $whereseq = "and 1=1";
    }
    if($data['tgttype']!=""){
      $wheretgttype = "and a.tgttypeid in ( ".$data['tgttype'].")";
    }else{
      $wheretgttype = "and 1=1";
    }
    if($data['salesline']!=""){
      $wheresalesline = "and a.saleslineid in ( ".$data['salesline'].")";
    }else{
      $wheresalesline = "and 1=1";
    }


    $query = DB::select(DB::raw("
    SELECT shiptoname, sum(sls) as totalsls FROM `sales.portal_invoice_trail` a
    where true
    ".$whereseq."
    ".$where."
    "
    .$whereyear.
    "
    "
    .$whereperiod.
    "
    "
    .$wheremr.
    "
    "
    .$whereflm.
    "
    "
    .$whereproductgroup.
    "
    "
    .$wherechannel.
    "
    "
    .$wherebu.
    "
    "
    .$wheresubchannel2.
    "
    "
    .$wheresource.
    "
    ".$wheresalesline."
    GROUP BY shiptoname
    ORDER BY totalsls DESC limit 20;"

    ));
    $counter1 = 0;
    $salesarray = array();
    $labelarray = array();
    foreach($query as $key => $val){
        $salesarray[$counter1]=round($val->totalsls);
        $array = explode( "\n", wordwrap( $val->shiptoname, 40));
        $labelarray[$counter1]=($array);
        $counter1 = $counter1 + 1;
    }
    $data['sales'] = json_encode($salesarray);
    $data['label'] = json_encode($labelarray);

     return response()->json($data);
  }


  public function getdashboard5(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
      $where = "and 1=1";
    }elseif(Auth::user()->territorytypeid==1){
      if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
        $where = "and nsmid in (1,2)";
      }else{
        $where = "and nsmid = ".Auth::user()->territoryid;
      }
    }elseif(Auth::user()->territorytypeid==2){
      $where = "and flmid = ".Auth::user()->territoryid;
    }elseif(Auth::user()->territorytypeid==3){
      $where = "and mrid = ".Auth::user()->territoryid;
    }

    if(Session::get('ka')==0){
      $targettablename = "`sales.portal_target_trail`";
    }else{
      $targettablename = "`sales.portal_target2_trail`";
    }
    $data['lyyear'] = $data['year']-1;
    $currentYear = date('Y');

    $whereyear = " AND year in ( ".$data['lyyear'].", ".($data['lyyear']+1)." ) ";
    $whereyear2 = "and a.year in ( ".$data['year'].") ";
    $whereffyear = " AND ffyear=".$currentYear;

    $periodlist;
    if($data['period']!=""){
      $periodlist = explode(" ", $data['period']);
    }else{
      $periodlist = array(date('n'));
    }
    $whereperiod = "AND a.period IN ( ".end($periodlist)." ) ";
    $whereperiod2 = "and a.period <= ".end($periodlist)."";

    // $data['lyyear'] = $data['year']-1;
    // if($data['year']!=""){
    //   $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
    //   $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
    // }else{
    //   $whereyear = "and 1=1";
    //   $whereyear2 = "and 1=1";
    // }
    // if($data['period']!=""){
    //   $whereperiod = "and a.period in ( ".$data['period'].")";
    //   $whereperiod2 = "and a.period <= ".$data['period']."";
    // }else{
    //   $whereperiod = "and 1=1";
    //   $whereperiod2 = "and 1=1";
    // }

     if($data['mrid']!=""){
       $wheremr = "and a.mrid in ( ".$data['mrid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['flmid']!=""){
       $whereflm = "and a.flmid in ( ".$data['flmid'].")";
     }else{
       $whereflm = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }


     if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
     }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
     }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
    if($data['seq']!=""){
      $whereseq = "and a.seq in ( ".$data['seq'].")";
    }else{
      $whereseq = "and 1=1";
    }
    if($data['tgttype']!=""){
      $wheretgttype = "and a.tgttypeid in ( ".$data['tgttype'].")";
    }else{
      $wheretgttype = "and 1=1";
    }
    if($data['salesline']!=""){
      $wheresalesline = "and a.saleslineid in ( ".$data['salesline'].")";
    }else{
      $wheresalesline = "and 1=1";
    }

    $sls = "SUM(IF(year=".$data['year'].", sls, 0)) as 'sls'";
    $lysls = "SUM(IF(year=".$data['lyyear'].", sls, 0)) as 'lysls'";
    $tgt = "SUM(IF(year=".$data['year'].", tgt, 0)) as 'tgt'";

    $data['table'] = DB::select(DB::raw("
      SELECT a.productgroup,a.salesline,a.mrname,sum(IFNULL(a.sls, 0)) as sls,sum(IFNULL(a.lysls, 0)) as lysls ,round(IFNULL((sum(a.sls)/sum(a.lysls)) * 100, 0)) as growth,round(IFNULL((sum(a.sls)/sum(c.tgt)) * 100, 0)) as performance
      FROM (
        SELECT $sls, $lysls, 0 as tgt, period, year, mrid, productgroup, salesline, mrname
        FROM `sales.portal_invoice_trail` a
        WHERE true
        ".$whereseq."
        ".$where."
        ".$whereyear."
        ".$whereffyear."
        ".$whereperiod."
        ".$wheremr."
        ".$whereflm."
        ".$whereproductgroup."
        ".$wherechannel."
        ".$wherebu."
        ".$wheresubchannel2."
        ".$wheresource."
        ".$wheresalesline."
        group by period,year,mrid,productgroup,salesline,mrname
      ) a
      LEFT JOIN (
        SELECT 0 as sls, $tgt, period, year, mrid, productgroup, salesline, mrname
        FROM ".$targettablename." a
        WHERE true
        ".$where."
        ".$whereyear."
        ".$whereffyear."
        ".$whereperiod."
        ".$wheremr."
        ".$whereflm."
        ".$whereproductgroup."
        ".$wherechanneltgt."
        ".$wherebu."
        ".$wheretgttype."
        ".$wheresalesline."
        group by period,year,mrid,productgroup,salesline,mrname
      ) c on a.mrid = c.mrid and a.year = c.year and a.period = c.period and a.productgroup = c.productgroup
      where true
      group by  a.productgroup,a.salesline,a.mrname
      order by a.mrname,a.productgroup
    ;"));
    $data['table2'] = DB::select(DB::raw("
      SELECT a.productgroup,sum(IFNULL(a.sls, 0)) as sls,sum(IFNULL(a.lysls, 0)) as lysls ,round(IFNULL((sum(a.sls)/sum(a.lysls)) * 100, 0)) as growth,round(IFNULL((sum(a.sls)/sum(c.tgt)) * 100, 0)) as performance
      FROM (
        SELECT $sls, $lysls, 0 as tgt, period, year, productgroup
        FROM `sales.portal_invoice_trail` a
        WHERE true
        ".$whereseq."
        ".$where."
        ".$whereyear."
        ".$whereffyear."
        ".$whereperiod."
        ".$wheremr."
        ".$whereflm."
        ".$whereproductgroup."
        ".$wherechannel."
        ".$wherebu."
        ".$wheresubchannel2."
        ".$wheresource."
        ".$wheresalesline."
        group by period,year,productgroup
      ) a
      LEFT JOIN (
        SELECT 0 as sls, $tgt, period, year, productgroup
        FROM ".$targettablename." a
        WHERE true
        ".$where."
        ".$whereyear."
        ".$whereffyear."
        ".$whereperiod."
        ".$wheremr."
        ".$whereflm."
        ".$whereproductgroup."
        ".$wherechanneltgt."
        ".$wherebu."
        ".$wheretgttype."
        ".$wheresalesline."
        group by period,year,productgroup
      ) c on a.year = c.year and a.period = c.period and a.productgroup = c.productgroup
      where true
      group by  a.productgroup
      order by a.productgroup
    ;"));
    /*
    $data['table'] = DB::select(DB::raw("
       SELECT a.productgroup,a.salesline,a.mrname,sum(IFNULL(a.sls, 0)) as sls,sum(IFNULL(b.sls, 0)) as lysls ,round(IFNULL((sum(a.sls)/sum(b.sls)) * 100, 0)) as growth,round(IFNULL((sum(a.sls)/sum(c.tgt)) * 100, 0)) as performance
        FROM (
          select sum(sls) as sls,0 as tgt,period,year,mrid,productgroup,salesline,mrname
          from `sales.portal_invoice_trail` a
          where true
          ".$whereseq."
          ".$where."
          "
          .$whereyear.
          "
          "
          .$whereperiod.
          "
          "
          .$wheremr.
          "
          "
          .$whereflm.
          "
          "
          .$whereproductgroup.
          "
          "
          .$wherechannel.
          "
          "
          .$wherebu.
          "
          "
          .$wheresubchannel2.
          "
          "
          .$wheresource.
          "
          group by period,year,mrid,productgroup,salesline,mrname
          ) a
        left join (
          select sum(sls) as sls,0 as tgt,period,year,mrid,productgroup,salesline,mrname
          from `sales.portal_invoice_trail` a
          where true
          ".$whereseq."
          ".$where."
          "
          .$whereyear2.
          "
          "
          .$whereperiod.
          "
          "
          .$wheremr.
          "
          "
          .$whereflm.
          "
          "
          .$whereproductgroup.
          "
          "
          .$wherechannel.
          "
          "
          .$wherebu.
          "
          "
          .$wheresubchannel2.
          "
          "
          .$wheresource.
          "
          group by period,year,mrid,productgroup,salesline,mrname
          ) b on a.mrid = b.mrid and a.period = b.period and a.productgroup = b.productgroup
        left join (
          select 0 as sls,sum(tgt) as tgt,period,year,mrid,productgroup,salesline,mrname
          from `sales.portal_target_trail` a
          where true
          ".$where."
          "
          .$whereyear.
          "
          "
          .$whereperiod.
          "
          "
          .$wheremr.
          "
          "
          .$whereflm.
          "
          "
          .$whereproductgroup.
          "
          "
          .$wherechanneltgt.
          "
          "
          .$wherebu.
          "
          group by period,year,mrid,productgroup,salesline,mrname
          ) c on a.mrid = c.mrid and a.year = c.year and a.period = c.period and a.productgroup = c.productgroup
       where true
       group by  a.productgroup,a.salesline,a.mrname
       order by a.mrname,a.productgroup
       ;"
    ));
    */

     return response()->json($data);
  }


  public function getdashboard6(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mrid = ".Auth::user()->territoryid;
      }
      if(Session::get('ka')==0){
        $targettablename = "`sales.portal_target_trail`";
      }else{
        $targettablename = "`sales.portal_target2_trail`";
      }
      $data['lyyear'] = $data['year']-1;
      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].") ";
        $whereyear2 = "and a.year in ( ".$data['lyyear'].")";
      }else{
        $whereyear = "and 1=1";
        $whereyear2 = "and 1=1";
      }
      if($data['period']!=""){
        $whereperiod = "and a.period in ( ".$data['period'].")";
        $whereperiod2 = "and a.period <= ".$data['period']."";
      }else{
        $whereperiod = "and 1=1";
        $whereperiod2 = "and 1=1";
      }

     if($data['mrid']!=""){
       $wheremr = "and a.mrid in ( ".$data['mrid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['flmid']!=""){
       $whereflm = "and a.flmid in ( ".$data['flmid'].")";
     }else{
       $whereflm = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }


     if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
     }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
     }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
    if($data['seq']!=""){
      $whereseq = "and a.seq in ( ".$data['seq'].")";
    }else{
      $whereseq = "and 1=1";
    }
    if($data['tgttype']!=""){
      $wheretgttype = "and a.tgttypeid in ( ".$data['tgttype'].")";
    }else{
      $wheretgttype = "and 1=1";
    }
    if($data['salesline']!=""){
      $wheresalesline = "and a.saleslineid in ( ".$data['salesline'].")";
    }else{
      $wheresalesline = "and 1=1";
    }


    $data['table'] = DB::select(DB::raw("
        select mrname, productgroup, sum(qty) as qty, sum(sls) as sls,concat(mrname,'_',productgroup) as recid
          from `sales.view_invoice_dtl` a
          left join `sales.purchased_records` b on a.customerid=b.customerid and a.productgroupid=b.productgroupid and a.year=b.year and a.period=b.period
          where true
          and a.shared=0
          ".$whereseq."
          ".$where."
          "
          .$whereyear.
          "
          "
          .$whereperiod.
          "
          "
          .$wheremr.
          "
          "
          .$whereflm.
          "
          "
          .$whereproductgroup.
          "
          "
          .$wherechannel.
          "
          "
          .$wherebu.
          "
          "
          .$wheresubchannel2.
          "
          "
          .$wheresource.
          "
          ".$wheresalesline."
          and b.customerid is null
          group by mrname, productgroup
          union all

          select mrname, productgroup, sum(qty) as qty, sum(sls) as sls,concat(mrname,'_',productgroup) as recid
          from `sales.view_shared_invoice_dtl` a
          left join `sales.purchased_records` b on a.customerid=b.customerid and a.productgroupid=b.productgroupid and a.year=b.year and a.period=b.period
          where true
          and b.customerid is null
          ".$whereseq."
          ".$where."
          "
          .$whereyear.
          "
          "
          .$whereperiod.
          "
          "
          .$wheremr.
          "
          "
          .$whereflm.
          "
          "
          .$whereproductgroup.
          "
          "
          .$wherechannel.
          "
          "
          .$wherebu.
          "
          "
          .$wheresubchannel2.
          "
          "
          .$wheresource.
          "
          ".$wheresalesline."
          group by mrname, productgroup
          order by mrname, productgroup;
       ;"
    ));
    /*select mrname, productgroup, sum(qty) as qty, sum(sls) as sls,concat(mrname,'_',productgroup) as recid from `sales.portal_invoice_trail` a
      left join `sales.purchased_records` b on a.customerid=b.customerid and a.productgroupid=b.productgroupid
      where true
      ".$whereseq."
      ".$where."
      "
      .$whereyear.
      "
      "
      .$whereperiod.
      "
      "
      .$wheremr.
      "
      "
      .$whereflm.
      "
      "
      .$whereproductgroup.
      "
      "
      .$wherechannel.
      "
      "
      .$wherebu.
      "
      "
      .$wheresubchannel2.
      "
      "
      .$wheresource.
      "
      and b.customerid is null


      group by mrname, productgroup
      order by mrname, productgroup;*/
     return response()->json($data);
  }


  public function getdashboard7(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mrid = ".Auth::user()->territoryid;
      }
      if(Session::get('ka')==0){
        $targettablename = "`sales.portal_target_trail`";
      }else{
        $targettablename = "`sales.portal_target2_trail`";
      }
      $data['lyyear'] = $data['year']-1;
      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
        $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
      }else{
        $whereyear = "and 1=1";
        $whereyear2 = "and 1=1";
      }
      if($data['period']!=""){
        $whereperiod = "and a.period in ( ".$data['period'].")";
        $whereperiod2 = "and a.period <= ".$data['period']."";
      }else{
        $whereperiod = "and 1=1";
        $whereperiod2 = "and 1=1";
      }

     if($data['mrid']!=""){
       $wheremr = "and a.mrid in ( ".$data['mrid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['flmid']!=""){
       $whereflm = "and a.flmid in ( ".$data['flmid'].")";
     }else{
       $whereflm = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }


     if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
     }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
     }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
    if($data['seq']!=""){
      $whereseq = "and a.seq in ( ".$data['seq'].")";
    }else{
      $whereseq = "and 1=1";
    }
    if($data['tgttype']!=""){
      $wheretgttype = "and a.tgttypeid in ( ".$data['tgttype'].")";
    }else{
      $wheretgttype = "and 1=1";
    }
    if($data['salesline']!=""){
      $wheresalesline = "and a.saleslineid in ( ".$data['salesline'].")";
    }else{
      $wheresalesline = "and 1=1";
    }


      $query = DB::select(DB::raw("
         SELECT sum(a.sls) as sls,ifnull(channel,'null') as channel
          FROM `sales.portal_invoice_trail` a
         where true
         ".$whereseq."
         ".$where."
         ".$whereyear."
         ".$whereperiod."
         ".$wheremr."
         ".$whereflm."
         ".$whereproductgroup."
         ".$wherechannel."
         ".$wherebu."
         ".$wheresubchannel2."
         ".$wheresource."
         ".$wheresalesline."
         group by channel
         ;"
      ));
      /*
      $query = DB::select(DB::raw("
         SELECT sum(a.sls) as sls,ifnull(channel,'null') as channel,b.sls as total
          FROM `sales.portal_invoice_trail` a
          , (
            SELECT sum(a.sls) as sls
             FROM `sales.portal_invoice_trail` a
            where true
            ".$whereseq."
            ".$where."
            "
            .$whereyear.
            "
            "
            .$whereperiod.
            "
            "
            .$wheremr.
            "
            "
            .$whereflm.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechannel.
            "
            "
            .$wherebu.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$wheresource.
            "
            ) b
         where true
         ".$whereseq."
         ".$where."
         "
         .$whereyear.
         "
         "
         .$whereperiod.
         "
         "
         .$wheremr.
         "
         "
         .$whereflm.
         "
         "
         .$whereproductgroup.
         "
         "
         .$wherechannel.
         "
         "
         .$wherebu.
         "
         "
         .$wheresubchannel2.
         "
         "
         .$wheresource.
         "
         group by channel,b.sls
         ;"
      ));
      */
      $counter1 = 0;
      $salesarray = array();
      $labelarray = array();
      $total = 0;

      foreach($query as $key => $val){
          $salesarray[$counter1]=round($val->sls);
          $labelarray[$counter1]=($val->channel);
          $counter1 = $counter1 + 1;
          $total += $val->sls;
      }


      $data['sales'] = json_encode($salesarray);
      $data['total'] = json_encode($total);
      $data['label'] = json_encode($labelarray);

       return response()->json($data);
    }

  public function dashboard(Request $data)
  {
    /*if (!empty(Auth::user())) {
      $query = DB::select(DB::raw("
        update `master.user`
        set last_login = now()
        where id = '".Auth::user()->id."'
        ;"
      ));
    }*/
     if(Auth::user()->territorytypeid==0){
         $where = "and 1=1";
       }elseif(Auth::user()->territorytypeid==1){
         if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
           $where = "and nsmid in (1,2)";
         }else{
           $where = "and nsmid = ".Auth::user()->territoryid;
         }
       }elseif(Auth::user()->territorytypeid==2){
         $where = "and flmid = ".Auth::user()->territoryid;
       }elseif(Auth::user()->territorytypeid==3){
         $where = "and mrid = ".Auth::user()->territoryid;
       }
       if(Session::get('ka')==0){
         $targettablename = "`sales.portal_target_trail`";
       }else{
         $targettablename = "`sales.portal_target2_trail`";
       }
       //drop down list
       /*
       $yearlist = DB::select(DB::raw("
           SELECT distinct year
           FROM `sales.portal_invoice_trail`
           where true
           "
           .$where.
           "
           ;"
       ));
       $periodlist = DB::select(DB::raw("
           SELECT distinct period
           FROM `sales.portal_invoice_trail`
           where true
           "
           .$where.
           "
           ;"
       ));
       */

      $yearlist = array();
      $periodlist = array();

      $year = date('Y')-2;
      for($i=0; $i<3; $i++) {
        $yearlist[$i] = (object) array('year' => $year);
        $year++;
      }

      for($i=0; $i<12; $i++) {
        $periodlist[$i] = (object) array('period' => $i+1);
      }

       $mrcodelist = DB::select(DB::raw("
           SELECT mrid,mrcode,mrname
           FROM `master.view_territoryV2`
           where true
           and shared = 0
           "
           .$where.
           "
           order by mrcode,mrname
           ;"
       ));

      $saleslinelist = DB::select(DB::raw("
          SELECT id,salesline
          FROM `master.salesline`
          where true
          order by salesline
          ;"
      ));

       $flmcodelist = DB::select(DB::raw("
           SELECT distinct flmid,flmcode,flmname
           FROM `master.view_territoryV2`
           where true
           and shared = 0
           "
           .$where.
           "
           order by flmcode,flmname
           ;"
       ));

      $productgrouplist = DB::select(DB::raw("
          SELECT distinct productgroupid,productgroup
          FROM ".$targettablename."
          where true
          "
          .$where.
          "
          order by productgroup
        ;"
      ));
      /*$productgrouplist = DB::select(DB::raw("
        SELECT id as productgroupid, productgroup
        FROM `master.product_group`
        WHERE id in (
          SELECT productgroupid
          FROM `sales.portal_invoice_trail`
          WHERE true
          AND year >= year(DATE_ADD(now(), INTERVAL -1 MONTH))
          ".$where."
        )
        ORDER BY productgroup
        ;"
      ));*/
      /* $productgrouplist = DB::select(DB::raw("
           SELECT distinct productgroupid,productgroup
           FROM `sales.portal_invoice_trail`
           where true
           and year >= year(DATE_ADD(now(), INTERVAL -1 MONTH))
           "
           .$where.
           "
           order by productgroup
           ;"
       ));*/

       $channellist = DB::select(DB::raw("
           SELECT id as channelid,channel
           FROM `master.channel`
           where true
           ;"
       ));
      $bulist = DB::select(DB::raw("
          SELECT id as  buid,bu
          FROM `master.bu`
          where true
          ;"
      ));
     $subchannel2list = DB::select(DB::raw("
         SELECT id as subchannel2id,subchannel2
         FROM `master.subchannel2`
         where true
         ;"
     ));
    $sourcelist = DB::select(DB::raw("
        SELECT id as sourceid,datasource
        FROM `master.datasource`
        where true
        ;"
    ));

      return view('dashboard', ["yearlist"=>$yearlist,"periodlist"=>$periodlist,"bulist"=>$bulist,"saleslinelist"=>$saleslinelist,"subchannel2list"=>$subchannel2list,"sourcelist"=>$sourcelist,"mrcodelist"=>$mrcodelist,"flmcodelist"=>$flmcodelist,"productgrouplist"=>$productgrouplist,"channellist"=>$channellist]);
   }

}
