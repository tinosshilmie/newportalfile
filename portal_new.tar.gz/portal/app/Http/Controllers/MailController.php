<?php

namespace App\Http\Controllers;
use Mail;

use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Routing\Redirector;

class MailController extends Controller {
   public function __construct()
   {
   }
   public function generatepassword(Request $data){
     $temppassword = Str::random(8);
     $hashtemppassword = Hash::make($temppassword);
     $email = $data['email'];
     $user = DB::select(DB::raw("
       select * from `master.user`
       where email = '".$email."'
       and status = 1
       ;"
     ));
     $query = DB::select(DB::raw("
       update `master.user`
       set resetpassword = '".$temppassword."',
       resetrequestdate = now()
       where id = '".$user[0]->id."'
       ;"
     ));

     return redirect()->route('reset-mail', ['temppassword' => $temppassword,'name' => $user[0]->username,'email' => $email]);
   }

}
