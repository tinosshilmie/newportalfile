<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator,Redirect,Response,File;
use App\Document;

class FileController extends Controller
{

    public function index()
    {
        return view('file');
    }

    public function store(Request $request)
    {

        $request->validate([
            'file' => 'required|mimes:xlsx,xlx,csv',
        ]);


        if ($files = $request->file('file')) {

            $fileName = time().'_'.$request->input('module').'.'.$request->file->extension();

            $request->file->move(public_path('upload'), $fileName);

            //store file into document folder

            //store your file into database
            //$document = new Document();
            //$document->title = $file;
            //$document->save();
            return Response()->json([
                "success" => true,
                "file" => $fileName
            ]);

        }

        return Response()->json([
                "success" => false,
                "file" => '',
                'errors' => $validator->getMessageBag()->toArray()
          ]);

    }
}
