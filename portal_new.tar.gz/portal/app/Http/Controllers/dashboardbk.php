<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use Auth;
use DB;
class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

     public function getdashboard(Request $data)
     {


        if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==1){
          $where = "and nsmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and flmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==3){
          $where = "and mrid = ".Auth::user()->territoryid;
          }

          if(Auth::user()->territorytypeid==0){
            $targettablename = "`sales.view_comp_target_dtl`";
          }else{
            $targettablename = "`sales.rpt_target_trail`";
          }

        $data['lyyear'] = $data['year']-1;

        if($data['year']!=""){
          $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
          $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
          if(Auth::user()->territorytypeid==0){
            $whereyeartgt = "and a.year in ( ".$data['year'].")";
          }else{
            $whereyeartgt = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
          }
        }else{
          $whereyear = "and 1=1";
          $whereyear2 = "and 1=1";
          $whereyeartgt = "and 1=1";
        }

        if($data['period']!=""){
          $whereperiod = "and a.period in ( ".$data['period'].")";
          $period = explode(" ", $data['period']);
          $whereperiod2 = "and a.period <= ".end($period)."";
        }else{
          $whereperiod = "and 1=1";
          $whereperiod2 = "and 1=1";
        }

        if($data['mrid']!=""){
          $wheremr = "and a.mrid in ( ".$data['mrid'].")";
        }else{
          $wheremr = "and 1=1";
        }
        if(Auth::user()->territorytypeid==0){
          $wheremrtgt = "and 1=1";
          $selectmr = ",0 as mrid";
          $selectmr2 = ",null as salesline,null as mrname";
          $groupmr = "";
          $groupmr2 = "";
          $joinonmr = "";
        }else{
          if($data['mrid']!=""){
            $wheremrtgt = "and a.mrid in ( ".$data['mrid'].")";
          }else{
            $wheremrtgt = "and 1=1";
          }
          $selectmr = ",mrid";
          $selectmr2 = ",salesline,mrname";
          $groupmr = ",mrid";
          $groupmr2 = ",salesline,mrname";
          $joinonmr = "a.mrid = b.mrid and ";
        }

        if($data['flmid']!=""){
          $whereflm = "and a.flmid in ( ".$data['flmid'].")";
        }else{
          $whereflm = "and 1=1";
        }
        if(Auth::user()->territorytypeid==0){
          $whereflmtgt = "and 1=1";
          $selectflm = "";
        }else{
          if($data['flmid']!=""){
            $whereflmtgt = "and a.flmid in ( ".$data['flmid'].")";
          }else{
            $whereflmtgt = "and 1=1";
          }
          $selectflm = ",flmid";
        }


       if($data['productgroupid']!=""){
         $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
       }else{
         $whereproductgroup = "and 1=1";
       }

      if($data['channelid']!=""){
        $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        if(Auth::user()->territorytypeid==0){
          $wherechanneltgt = "and a.channelid in ( ".$data['channelid'].")";
        }else{
          $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
        }
      }else{
        $wherechannel = "and 1=1";
        $wherechanneltgt = "and 1=1";
      }
      if($data['buid']!=""){
        $wherebu = "and a.buid in ( ".$data['buid'].")";
      }else{
        $wherebu = "and 1=1";
      }
      if($data['subchannel2id']!=""){
        $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
      }else{
        $wheresubchannel2 = "and 1=1";
      }
      if($data['sourceid']!=""){
        $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
      }else{
        $wheresource = "and 1=1";
      }

        $data['mtdsales'] = DB::select(DB::raw("
           SELECT round(sum(sls)) as sls
           FROM `sales.rpt_invoice_trail` a
           where true
           and sourceid = 1 and seq = 1 and buid > 0
           ".$where."
           "
           .$whereyear.
           "
           "
           .$whereperiod.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           ;"
        ));
        $data['lymtdsales'] = DB::select(DB::raw("
           SELECT round(sum(sls)) as sls
           FROM `sales.rpt_invoice_trail` a
           where true
           and sourceid = 1 and seq = 1 and buid > 0
           ".$where."
           "
           .$whereyear2.
           "
           "
           .$whereperiod.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           ;"
        ));
        $data['ytdsales'] = DB::select(DB::raw("
           SELECT round(sum(sls)) as sls
           FROM `sales.rpt_invoice_trail` a
           where true
           and sourceid = 1 and seq = 1 and buid > 0
           ".$where."
           "
           .$whereyear.
           "
           "
           .$whereperiod2.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           ;"
        ));
        $data['lyytdsales'] = DB::select(DB::raw("
           SELECT round(sum(sls)) as sls
           FROM `sales.rpt_invoice_trail` a
           where true
           and sourceid = 1 and seq = 1 and buid > 0
           ".$where."
           "
           .$whereyear2.
           "
           "
           .$whereperiod2.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           ;"
        ));
        $data['mtdtarget'] = DB::select(DB::raw("
           SELECT round(sum(tgt)) as tgt
           FROM ".$targettablename." a
           where true
           ".$where."
           "
           .$whereyeartgt.
           "
           "
           .$whereperiod.
           "
           "
           .$wheremrtgt.
           "
           "
           .$whereflmtgt.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechanneltgt.
           "
           "
           .$wherebu.
           "
           ;"
        ));
        $data['ytdtarget'] = DB::select(DB::raw("
           SELECT round(sum(tgt)) as tgt
           FROM ".$targettablename." a
           where true
           ".$where."
           "
           .$whereyeartgt.
           "
           "
           .$whereperiod2.
           "
           "
           .$wheremrtgt.
           "
           "
           .$whereflmtgt.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechanneltgt.
           "
           "
           .$wherebu.
           "
           ;"
        ));
        if((int)$data['mtdtarget'][0]->tgt != 0){
          $data['perf'] = round(($data['mtdsales'][0]->sls/$data['mtdtarget'][0]->tgt) * 100);
        }else{
          $data['perf'] = 100;
        }
        if((int)$data['ytdtarget'][0]->tgt != 0){
          $data['perf2'] = round(($data['ytdsales'][0]->sls/$data['ytdtarget'][0]->tgt) * 100);
        }else{
          $data['perf2'] = 100;
        }

        if((int)$data['lymtdsales'][0]->sls != 0){
          $data['growth'] = round(($data['mtdsales'][0]->sls/$data['lymtdsales'][0]->sls) * 100);
        }else{
          $data['growth'] = 100;
        }
        if((int)$data['lyytdsales'][0]->sls != 0){
          $data['growth2'] = round(($data['ytdsales'][0]->sls/$data['lyytdsales'][0]->sls) * 100);
        }else{
          $data['growth2'] = 100;
        }

        return response()->json($data);
     }

  public function getdashboard2(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        $where = "and nsmid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mrid = ".Auth::user()->territoryid;
      }

      if(Auth::user()->territorytypeid==0){
        $targettablename = "`sales.view_comp_target_dtl`";
      }else{
        $targettablename = "`sales.rpt_target_trail`";
      }

      $data['lyyear'] = $data['year']-1;
      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
        $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
        if(Auth::user()->territorytypeid==0){
          $whereyeartgt = "and a.year in ( ".$data['year'].")";
        }else{
          $whereyeartgt = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
        }
      }else{
        $whereyear = "and 1=1";
        $whereyear2 = "and 1=1";
        $whereyeartgt = "and 1=1";
      }
      if($data['period']!=""){
        $whereperiod = "and a.period in ( ".$data['period'].")";
        $whereperiod2 = "and a.period <= ".$data['period']."";
      }else{
        $whereperiod = "and 1=1";
        $whereperiod2 = "and 1=1";
      }




      if($data['mrid']!=""){
        $wheremr = "and a.mrid in ( ".$data['mrid'].")";
      }else{
        $wheremr = "and 1=1";
      }
      if(Auth::user()->territorytypeid==0){
        $wheremrtgt = "and 1=1";
        $selectmr = ",0 as mrid";
        $selectmr2 = ",null as salesline,null as mrname";
        $groupmr = "";
        $groupmr2 = "";
        $joinonmr = "";
      }else{
        if($data['mrid']!=""){
          $wheremrtgt = "and a.mrid in ( ".$data['mrid'].")";
        }else{
          $wheremrtgt = "and 1=1";
        }
        $selectmr = ",mrid";
        $selectmr2 = ",salesline,mrname";
        $groupmr = ",mrid";
        $groupmr2 = ",salesline,mrname";
        $joinonmr = "a.mrid = b.mrid and ";
      }

      if($data['flmid']!=""){
        $whereflm = "and a.flmid in ( ".$data['flmid'].")";
      }else{
        $whereflm = "and 1=1";
      }
      if(Auth::user()->territorytypeid==0){
        $whereflmtgt = "and 1=1";
        $selectflm = "";
      }else{
        if($data['flmid']!=""){
          $whereflmtgt = "and a.flmid in ( ".$data['flmid'].")";
        }else{
          $whereflmtgt = "and 1=1";
        }
        $selectflm = ",flmid";
      }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }

    if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      if(Auth::user()->territorytypeid==0){
        $wherechanneltgt = "and a.channelid in ( ".$data['channelid'].")";
      }else{
        $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
      }
    }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
    }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }


     $query = DB::select(DB::raw("
        SELECT sum(a.sls) as sls,sum(a.tgt) as tgt ,(sum(sls)/sum(tgt)) * 100 as perf ,(sum(a.sls)/sum(c.lysls)) * 100 as growth
         FROM (
           select sum(sls) as sls,period,year,mrid,0 as tgt
           from `sales.rpt_invoice_trail` a
           where true
           and sourceid = 1 and seq = 1 and buid > 0
           ".$where."
           "
           .$whereyear.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           group by period,year,mrid
           union select 0 as sls,period,year".$selectmr.",sum(tgt) as tgt
           from ".$targettablename." a
           where true
           ".$where."
           "
           .$whereyeartgt.
           "
           "
           .$wheremrtgt.
           "
           "
           .$whereflmtgt.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechanneltgt.
           "
           "
           .$wherebu.
           "
           group by period,year".$groupmr."
           ) a
         left join (
           select sum(sls) as lysls,period,year,mrid
           from `sales.rpt_invoice_trail` a
           where true
           and sourceid = 1 and seq = 1 and buid > 0
           ".$where."
           "
           .$whereyear2.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           group by period,year,mrid
           ) c on a.mrid = c.mrid and a.period = c.period
        where true
        group by a.period
        order by a.period




        ;"
     ));
     $counter1 = 0;
     $salesarray = array();
     $targetarray = array();
     $perfarray = array();
     $growtharray = array();
     foreach($query as $key => $val){
         $salesarray[$counter1]=round($val->sls);
         $targetarray[$counter1]=round($val->tgt);
         $perfarray[$counter1]=round($val->perf);
         $growtharray[$counter1]=round($val->growth);
         $counter1 = $counter1 + 1;
     }
     $data['sales'] = json_encode($salesarray);
     $data['target'] = json_encode($targetarray);
     $data['perf'] = json_encode($perfarray);
     $data['growth'] = json_encode($growtharray);
     return response()->json($data);
  }


  public function getdashboard3(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        $where = "and nsmid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mrid = ".Auth::user()->territoryid;
      }

      if(Auth::user()->territorytypeid==0){
        $targettablename = "`sales.view_comp_target_dtl`";
      }else{
        $targettablename = "`sales.rpt_target_trail`";
      }

      $data['lyyear'] = $data['year']-1;
      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
        $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
        if(Auth::user()->territorytypeid==0){
          $whereyeartgt = "and a.year in ( ".$data['year'].")";
        }else{
          $whereyeartgt = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
        }
      }else{
        $whereyear = "and 1=1";
        $whereyear2 = "and 1=1";
        $whereyeartgt = "and 1=1";
      }
      if($data['period']!=""){
        $whereperiod = "and a.period in ( ".$data['period'].")";
        $whereperiod2 = "and a.period <= ".$data['period']."";
      }else{
        $whereperiod = "and 1=1";
        $whereperiod2 = "and 1=1";
      }




      if($data['mrid']!=""){
        $wheremr = "and a.mrid in ( ".$data['mrid'].")";
      }else{
        $wheremr = "and 1=1";
      }
      if(Auth::user()->territorytypeid==0){
        $wheremrtgt = "and 1=1";
        $selectmr = ",0 as mrid";
        $selectmr2 = ",null as salesline,null as mrname";
        $groupmr = "";
        $groupmr2 = "";
        $joinonmr = "";
      }else{
        if($data['mrid']!=""){
          $wheremrtgt = "and a.mrid in ( ".$data['mrid'].")";
        }else{
          $wheremrtgt = "and 1=1";
        }
        $selectmr = ",mrid";
        $selectmr2 = ",salesline,mrname";
        $groupmr = ",mrid";
        $groupmr2 = ",salesline,mrname";
        $joinonmr = "a.mrid = b.mrid and ";
      }

      if($data['flmid']!=""){
        $whereflm = "and a.flmid in ( ".$data['flmid'].")";
      }else{
        $whereflm = "and 1=1";
      }
      if(Auth::user()->territorytypeid==0){
        $whereflmtgt = "and 1=1";
        $selectflm = "";
      }else{
        if($data['flmid']!=""){
          $whereflmtgt = "and a.flmid in ( ".$data['flmid'].")";
        }else{
          $whereflmtgt = "and 1=1";
        }
        $selectflm = ",flmid";
      }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }

    if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      if(Auth::user()->territorytypeid==0){
        $wherechanneltgt = "and a.channelid in ( ".$data['channelid'].")";
      }else{
        $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
      }
    }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
    }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }


    $query = DB::select(DB::raw("
       SELECT sum(a.sls) as sls,productgroup,b.sls as total
        FROM `sales.rpt_invoice_trail` a, (
          SELECT sum(a.sls) as sls
           FROM `sales.rpt_invoice_trail` a
          where true
          and sourceid = 1 and seq = 1 and buid > 0
          ".$where."
          "
          .$whereyear.
          "
          "
          .$whereperiod.
          "
          "
          .$wheremr.
          "
          "
          .$whereflm.
          "
          "
          .$whereproductgroup.
          "
          "
          .$wherechannel.
          "
          "
          .$wherebu.
          "
          "
          .$wheresubchannel2.
          "
          "
          .$wheresource.
          "
          ) b
       where true
       ".$where."
       "
       .$whereyear.
       "
       "
       .$whereperiod.
       "
       "
       .$wheremr.
       "
       "
       .$whereflm.
       "
       "
       .$whereproductgroup.
       "
       "
       .$wherechannel.
       "
       "
       .$wherebu.
       "
       "
       .$wheresubchannel2.
       "
       "
       .$wheresource.
       "
       group by productgroup,b.sls
       ;"
    ));
    $counter1 = 0;
    $salesarray = array();
    $labelarray = array();
    $total = 0;

    foreach($query as $key => $val){
        $salesarray[$counter1]=round($val->sls);
        $labelarray[$counter1]=($val->productgroup);
        $counter1 = $counter1 + 1;
        $total = $val->total;
    }

    $data['sales'] = json_encode($salesarray);
    $data['total'] = json_encode($total);
    $data['label'] = json_encode($labelarray);

     return response()->json($data);
  }


    public function getdashboard4(Request $data)
    {
      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==1){
          $where = "and nsmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and flmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==3){
          $where = "and mrid = ".Auth::user()->territoryid;
        }

        if(Auth::user()->territorytypeid==0){
          $targettablename = "`sales.view_comp_target_dtl`";
        }else{
          $targettablename = "`sales.rpt_target_trail`";
        }

        $data['lyyear'] = $data['year']-1;
        if($data['year']!=""){
          $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
          $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
          if(Auth::user()->territorytypeid==0){
            $whereyeartgt = "and a.year in ( ".$data['year'].")";
          }else{
            $whereyeartgt = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
          }
        }else{
          $whereyear = "and 1=1";
          $whereyear2 = "and 1=1";
          $whereyeartgt = "and 1=1";
        }
        if($data['period']!=""){
          $whereperiod = "and a.period in ( ".$data['period'].")";
          $whereperiod2 = "and a.period <= ".$data['period']."";
        }else{
          $whereperiod = "and 1=1";
          $whereperiod2 = "and 1=1";
        }




        if($data['mrid']!=""){
          $wheremr = "and a.mrid in ( ".$data['mrid'].")";
        }else{
          $wheremr = "and 1=1";
        }
        if(Auth::user()->territorytypeid==0){
          $wheremrtgt = "and 1=1";
          $selectmr = ",0 as mrid";
          $selectmr2 = ",null as salesline,null as mrname";
          $groupmr = "";
          $groupmr2 = "";
          $joinonmr = "";
        }else{
          if($data['mrid']!=""){
            $wheremrtgt = "and a.mrid in ( ".$data['mrid'].")";
          }else{
            $wheremrtgt = "and 1=1";
          }
          $selectmr = ",mrid";
          $selectmr2 = ",salesline,mrname";
          $groupmr = ",mrid";
          $groupmr2 = ",salesline,mrname";
          $joinonmr = "a.mrid = b.mrid and ";
        }

        if($data['flmid']!=""){
          $whereflm = "and a.flmid in ( ".$data['flmid'].")";
        }else{
          $whereflm = "and 1=1";
        }
        if(Auth::user()->territorytypeid==0){
          $whereflmtgt = "and 1=1";
          $selectflm = "";
        }else{
          if($data['flmid']!=""){
            $whereflmtgt = "and a.flmid in ( ".$data['flmid'].")";
          }else{
            $whereflmtgt = "and 1=1";
          }
          $selectflm = ",flmid";
        }

       if($data['productgroupid']!=""){
         $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
       }else{
         $whereproductgroup = "and 1=1";
       }

      if($data['channelid']!=""){
        $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        if(Auth::user()->territorytypeid==0){
          $wherechanneltgt = "and a.channelid in ( ".$data['channelid'].")";
        }else{
          $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
        }
      }else{
        $wherechannel = "and 1=1";
        $wherechanneltgt = "and 1=1";
      }
      if($data['buid']!=""){
        $wherebu = "and a.buid in ( ".$data['buid'].")";
      }else{
        $wherebu = "and 1=1";
      }
      if($data['subchannel2id']!=""){
        $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
      }else{
        $wheresubchannel2 = "and 1=1";
      }
      if($data['sourceid']!=""){
        $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
      }else{
        $wheresource = "and 1=1";
      }

      $query = DB::select(DB::raw("
      SELECT shiptoname, sum(sls) as totalsls FROM `sales.rpt_invoice_trail` a
      where true
      and sourceid = 1 and seq = 1 and buid > 0
      ".$where."
      "
      .$whereyear.
      "
      "
      .$whereperiod.
      "
      "
      .$wheremr.
      "
      "
      .$whereflm.
      "
      "
      .$whereproductgroup.
      "
      "
      .$wherechannel.
      "
      "
      .$wherebu.
      "
      "
      .$wheresubchannel2.
      "
      "
      .$wheresource.
      "
      GROUP BY shiptoname
      ORDER BY totalsls DESC limit 20;"

      ));
      $counter1 = 0;
      $salesarray = array();
      $labelarray = array();
      foreach($query as $key => $val){
          $salesarray[$counter1]=round($val->totalsls);
          $array = explode( "\n", wordwrap( $val->shiptoname, 40));
          $labelarray[$counter1]=($array);
          $counter1 = $counter1 + 1;
      }
      $data['sales'] = json_encode($salesarray);
      $data['label'] = json_encode($labelarray);

       return response()->json($data);
    }


    public function getdashboard5(Request $data)
    {
      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==1){
          $where = "and nsmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and flmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==3){
          $where = "and mrid = ".Auth::user()->territoryid;
        }

        if(Auth::user()->territorytypeid==0){
          $targettablename = "`sales.view_comp_target_dtl`";
        }else{
          $targettablename = "`sales.rpt_target_trail`";
        }

        $data['lyyear'] = $data['year']-1;
        if($data['year']!=""){
          $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
          $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
          if(Auth::user()->territorytypeid==0){
            $whereyeartgt = "and a.year in ( ".$data['year'].")";
          }else{
            $whereyeartgt = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
          }
        }else{
          $whereyear = "and 1=1";
          $whereyear2 = "and 1=1";
          $whereyeartgt = "and 1=1";
        }
        if($data['period']!=""){
          $whereperiod = "and a.period in ( ".$data['period'].")";
          $whereperiod2 = "and a.period <= ".$data['period']."";
        }else{
          $whereperiod = "and 1=1";
          $whereperiod2 = "and 1=1";
        }



        if($data['mrid']!=""){
          $wheremr = "and a.mrid in ( ".$data['mrid'].")";
        }else{
          $wheremr = "and 1=1";
        }
        if(Auth::user()->territorytypeid==0){
          $wheremrtgt = "and 1=1";
          $selectmr = ",0 as mrid";
          $selectmr2 = ",null as salesline,null as mrname";
          $groupmr = "";
          $groupmr2 = "";
          $joinonmr = "";
        }else{
          if($data['mrid']!=""){
            $wheremrtgt = "and a.mrid in ( ".$data['mrid'].")";
          }else{
            $wheremrtgt = "and 1=1";
          }
          $selectmr = ",mrid";
          $selectmr2 = ",salesline,mrname";
          $groupmr = ",mrid";
          $groupmr2 = ",salesline,mrname";
          $joinonmr = "a.mrid = b.mrid and ";
        }

        if($data['flmid']!=""){
          $whereflm = "and a.flmid in ( ".$data['flmid'].")";
        }else{
          $whereflm = "and 1=1";
        }
        if(Auth::user()->territorytypeid==0){
          $whereflmtgt = "and 1=1";
          $selectflm = "";
        }else{
          if($data['flmid']!=""){
            $whereflmtgt = "and a.flmid in ( ".$data['flmid'].")";
          }else{
            $whereflmtgt = "and 1=1";
          }
          $selectflm = ",flmid";
        }

       if($data['productgroupid']!=""){
         $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
       }else{
         $whereproductgroup = "and 1=1";
       }

      if($data['channelid']!=""){
        $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        if(Auth::user()->territorytypeid==0){
          $wherechanneltgt = "and a.channelid in ( ".$data['channelid'].")";
        }else{
          $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
        }
      }else{
        $wherechannel = "and 1=1";
        $wherechanneltgt = "and 1=1";
      }
      if($data['buid']!=""){
        $wherebu = "and a.buid in ( ".$data['buid'].")";
      }else{
        $wherebu = "and 1=1";
      }
      if($data['subchannel2id']!=""){
        $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
      }else{
        $wheresubchannel2 = "and 1=1";
      }
      if($data['sourceid']!=""){
        $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
      }else{
        $wheresource = "and 1=1";
      }

      $data['table'] = DB::select(DB::raw("
         SELECT a.productgroup,a.salesline,a.mrname,sum(IFNULL(a.sls, 0)) as sls,sum(IFNULL(b.sls, 0)) as lysls ,round(IFNULL((sum(a.sls)/sum(b.sls)) * 100, 0)) as growth,round(IFNULL((sum(a.sls)/sum(c.tgt)) * 100, 0)) as performance
          FROM (
            select sum(sls) as sls,0 as tgt,period,year,mrid,productgroup,salesline,mrname
            from `sales.rpt_invoice_trail` a
            where true
            and sourceid = 1 and seq = 1 and buid > 0
            ".$where."
            "
            .$whereyear.
            "
            "
            .$whereperiod.
            "
            "
            .$wheremr.
            "
            "
            .$whereflm.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechannel.
            "
            "
            .$wherebu.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$wheresource.
            "
            group by period,year,mrid,productgroup,salesline,mrname
            ) a
          left join (
            select sum(sls) as sls,0 as tgt,period,year,mrid,productgroup,salesline,mrname
            from `sales.rpt_invoice_trail` a
            where true
            and sourceid = 1 and seq = 1 and buid > 0
            ".$where."
            "
            .$whereyear2.
            "
            "
            .$whereperiod.
            "
            "
            .$wheremr.
            "
            "
            .$whereflm.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechannel.
            "
            "
            .$wherebu.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$wheresource.
            "
            group by period,year,mrid,productgroup,salesline,mrname
            ) b on a.mrid = b.mrid and a.period = b.period and a.productgroup = b.productgroup
          left join (
            select 0 as sls,sum(tgt) as tgt,period,year".$selectmr.",productgroup".$selectmr2."
            from ".$targettablename." a
            where true
            ".$where."
            "
            .$whereyeartgt.
            "
            "
            .$whereperiod.
            "
            "
            .$wheremrtgt.
            "
            "
            .$whereflmtgt.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechanneltgt.
            "
            "
            .$wherebu.
            "
            group by period,year".$groupmr.",productgroup".$groupmr2."
            ) c on ".$joinonmr." a.year = c.year and a.period = c.period and a.productgroup = c.productgroup
         where true
         group by  a.productgroup,a.salesline,a.mrname
         order by a.mrname,a.productgroup
         ;"
      ));

       return response()->json($data);
    }


        public function getdashboard6(Request $data)
        {
          if(Auth::user()->territorytypeid==0){
              $where = "and 1=1";
            }elseif(Auth::user()->territorytypeid==1){
              $where = "and nsmid = ".Auth::user()->territoryid;
            }elseif(Auth::user()->territorytypeid==2){
              $where = "and flmid = ".Auth::user()->territoryid;
            }elseif(Auth::user()->territorytypeid==3){
              $where = "and mrid = ".Auth::user()->territoryid;
            }

            if(Auth::user()->territorytypeid==0){
              $targettablename = "`sales.view_comp_target_dtl`";
            }else{
              $targettablename = "`sales.rpt_target_trail`";
            }

            $data['lyyear'] = $data['year']-1;
            if($data['year']!=""){
              $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
              $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
              if(Auth::user()->territorytypeid==0){
                $whereyeartgt = "and a.year in ( ".$data['year'].")";
              }else{
                $whereyeartgt = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
              }
            }else{
              $whereyear = "and 1=1";
              $whereyear2 = "and 1=1";
              $whereyeartgt = "and 1=1";
            }
            if($data['period']!=""){
              $whereperiod = "and a.period in ( ".$data['period'].")";
              $whereperiod2 = "and a.period <= ".$data['period']."";
            }else{
              $whereperiod = "and 1=1";
              $whereperiod2 = "and 1=1";
            }





            if($data['mrid']!=""){
              $wheremr = "and a.mrid in ( ".$data['mrid'].")";
            }else{
              $wheremr = "and 1=1";
            }
            if(Auth::user()->territorytypeid==0){
              $wheremrtgt = "and 1=1";
              $selectmr = ",0 as mrid";
              $selectmr2 = ",null as salesline,null as mrname";
              $groupmr = "";
              $groupmr2 = "";
              $joinonmr = "";
            }else{
              if($data['mrid']!=""){
                $wheremrtgt = "and a.mrid in ( ".$data['mrid'].")";
              }else{
                $wheremrtgt = "and 1=1";
              }
              $selectmr = ",mrid";
              $selectmr2 = ",salesline,mrname";
              $groupmr = ",mrid";
              $groupmr2 = ",salesline,mrname";
              $joinonmr = "a.mrid = b.mrid and ";
            }
            if($data['flmid']!=""){
              $whereflm = "and a.flmid in ( ".$data['flmid'].")";
            }else{
              $whereflm = "and 1=1";
            }
            if(Auth::user()->territorytypeid==0){
              $whereflmtgt = "and 1=1";
              $selectflm = "";
            }else{
              if($data['flmid']!=""){
                $whereflmtgt = "and a.flmid in ( ".$data['flmid'].")";
              }else{
                $whereflmtgt = "and 1=1";
              }
              $selectflm = ",flmid";
            }

           if($data['productgroupid']!=""){
             $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
           }else{
             $whereproductgroup = "and 1=1";
           }

          if($data['channelid']!=""){
            $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
            if(Auth::user()->territorytypeid==0){
              $wherechanneltgt = "and a.channelid in ( ".$data['channelid'].")";
            }else{
              $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
            }
          }else{
            $wherechannel = "and 1=1";
            $wherechanneltgt = "and 1=1";
          }
          if($data['buid']!=""){
            $wherebu = "and a.buid in ( ".$data['buid'].")";
          }else{
            $wherebu = "and 1=1";
          }
          if($data['subchannel2id']!=""){
            $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
          }else{
            $wheresubchannel2 = "and 1=1";
          }
          if($data['sourceid']!=""){
            $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
          }else{
            $wheresource = "and 1=1";
          }

          $data['table'] = DB::select(DB::raw("
              select mrname, productgroup, sum(qty) as qty, sum(sls) as sls,concat(mrname,'_',productgroup) as recid from `sales.rpt_invoice_trail` a
                left join `sales.purchased_records` b on a.customerid=b.customerid and a.productgroupid=b.productgroupid
                where true
                and sourceid = 1 and seq = 1 and buid > 0

                ".$where."
                "
                .$whereyear.
                "
                "
                .$whereperiod.
                "
                "
                .$wheremr.
                "
                "
                .$whereflm.
                "
                "
                .$whereproductgroup.
                "
                "
                .$wherechannel.
                "
                "
                .$wherebu.
                "
                "
                .$wheresubchannel2.
                "
                "
                .$wheresource.
                "
                and b.customerid is null


                group by mrname, productgroup
                order by mrname, productgroup;
             ;"
          ));

           return response()->json($data);
        }


    public function getdashboard7(Request $data)
    {
      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==1){
          $where = "and nsmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and flmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==3){
          $where = "and mrid = ".Auth::user()->territoryid;
        }

        if(Auth::user()->territorytypeid==0){
          $targettablename = "`sales.view_comp_target_dtl`";
        }else{
          $targettablename = "`sales.rpt_target_trail`";
        }

        $data['lyyear'] = $data['year']-1;
        if($data['year']!=""){
          $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
          $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$data['year'].")";
          if(Auth::user()->territorytypeid==0){
            $whereyeartgt = "and a.year in ( ".$data['year'].")";
          }else{
            $whereyeartgt = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$data['year'].")";
          }
        }else{
          $whereyear = "and 1=1";
          $whereyear2 = "and 1=1";
          $whereyeartgt = "and 1=1";
        }
        if($data['period']!=""){
          $whereperiod = "and a.period in ( ".$data['period'].")";
          $whereperiod2 = "and a.period <= ".$data['period']."";
        }else{
          $whereperiod = "and 1=1";
          $whereperiod2 = "and 1=1";
        }





        if($data['mrid']!=""){
          $wheremr = "and a.mrid in ( ".$data['mrid'].")";
        }else{
          $wheremr = "and 1=1";
        }
        if(Auth::user()->territorytypeid==0){
          $wheremrtgt = "and 1=1";
          $selectmr = ",0 as mrid";
          $selectmr2 = ",null as salesline,null as mrname";
          $groupmr = "";
          $groupmr2 = "";
          $joinonmr = "";
        }else{
          if($data['mrid']!=""){
            $wheremrtgt = "and a.mrid in ( ".$data['mrid'].")";
          }else{
            $wheremrtgt = "and 1=1";
          }
          $selectmr = ",mrid";
          $selectmr2 = ",salesline,mrname";
          $groupmr = ",mrid";
          $groupmr2 = ",salesline,mrname";
          $joinonmr = "a.mrid = b.mrid and ";
        }
        if($data['flmid']!=""){
          $whereflm = "and a.flmid in ( ".$data['flmid'].")";
        }else{
          $whereflm = "and 1=1";
        }
        if(Auth::user()->territorytypeid==0){
          $whereflmtgt = "and 1=1";
          $selectflm = "";
        }else{
          if($data['flmid']!=""){
            $whereflmtgt = "and a.flmid in ( ".$data['flmid'].")";
          }else{
            $whereflmtgt = "and 1=1";
          }
          $selectflm = ",flmid";
        }

       if($data['productgroupid']!=""){
         $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
       }else{
         $whereproductgroup = "and 1=1";
       }

      if($data['channelid']!=""){
        $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        if(Auth::user()->territorytypeid==0){
          $wherechanneltgt = "and a.channelid in ( ".$data['channelid'].")";
        }else{
          $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
        }
      }else{
        $wherechannel = "and 1=1";
        $wherechanneltgt = "and 1=1";
      }
      if($data['buid']!=""){
        $wherebu = "and a.buid in ( ".$data['buid'].")";
      }else{
        $wherebu = "and 1=1";
      }
      if($data['subchannel2id']!=""){
        $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
      }else{
        $wheresubchannel2 = "and 1=1";
      }
      if($data['sourceid']!=""){
        $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
      }else{
        $wheresource = "and 1=1";
      }


      $query = DB::select(DB::raw("
         SELECT sum(a.sls) as sls,ifnull(channel,'null') as channel,b.sls as total
          FROM `sales.rpt_invoice_trail` a
          , (
            SELECT sum(a.sls) as sls
             FROM `sales.rpt_invoice_trail` a
            where true
            and sourceid = 1 and seq = 1 and buid > 0
            ".$where."
            "
            .$whereyear.
            "
            "
            .$whereperiod.
            "
            "
            .$wheremr.
            "
            "
            .$whereflm.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechannel.
            "
            "
            .$wherebu.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$wheresource.
            "
            ) b
         where true
         and sourceid = 1 and seq = 1 and buid > 0
         ".$where."
         "
         .$whereyear.
         "
         "
         .$whereperiod.
         "
         "
         .$wheremr.
         "
         "
         .$whereflm.
         "
         "
         .$whereproductgroup.
         "
         "
         .$wherechannel.
         "
         "
         .$wherebu.
         "
         "
         .$wheresubchannel2.
         "
         "
         .$wheresource.
         "
         group by channel,b.sls
         ;"
      ));
      $counter1 = 0;
      $salesarray = array();
      $labelarray = array();
      $total = 0;
      foreach($query as $key => $val){
          $salesarray[$counter1]=round($val->sls);
          $labelarray[$counter1]=($val->channel);
          $counter1 = $counter1 + 1;
          $total = $val->total;
      }


      $data['sales'] = json_encode($salesarray);
      $data['total'] = json_encode($total);
      $data['label'] = json_encode($labelarray);

       return response()->json($data);
    }

   public function dashboard(Request $data)
   {
     if(Auth::user()->territorytypeid==0){
         $where = "and 1=1";
       }elseif(Auth::user()->territorytypeid==1){
         $where = "and nsmid = ".Auth::user()->territoryid;
       }elseif(Auth::user()->territorytypeid==2){
         $where = "and flmid = ".Auth::user()->territoryid;
       }elseif(Auth::user()->territorytypeid==3){
         $where = "and mrid = ".Auth::user()->territoryid;
       }
       //drop down list
       $yearlist = DB::select(DB::raw("
           SELECT distinct year
           FROM `sales.rpt_invoice_trail`
           where true
           "
           .$where.
           "
           ;"
       ));
       $periodlist = DB::select(DB::raw("
           SELECT distinct period
           FROM `sales.rpt_invoice_trail`
           where true
           "
           .$where.
           "
           ;"
       ));
       $mrcodelist = DB::select(DB::raw("
           SELECT distinct mrid,mrcode,mrname
           FROM `sales.rpt_invoice_trail`
           where true
           "
           .$where.
           "
           order by mrcode,mrname
           ;"
       ));

       $flmcodelist = DB::select(DB::raw("
           SELECT distinct flmid,flmcode,flmname
           FROM `sales.rpt_invoice_trail`
           where true
           "
           .$where.
           "
           order by flmcode,flmname
           ;"
       ));
       $productgrouplist = DB::select(DB::raw("
           SELECT distinct productgroupid,productgroup
           FROM `sales.rpt_invoice_trail`
           where true
           "
           .$where.
           "
           order by productgroup
           ;"
       ));

       $channellist = DB::select(DB::raw("
           SELECT distinct channelid,channel
           FROM `sales.rpt_invoice_trail`
           where true
           "
           .$where.
           "
           ;"
       ));
      $bulist = DB::select(DB::raw("
          SELECT distinct buid,bu
          FROM `sales.rpt_invoice_trail`
          where true
          "
          .$where.
          "
          ;"
      ));
     $subchannel2list = DB::select(DB::raw("
         SELECT distinct subchannel2id,subchannel2
         FROM `sales.rpt_invoice_trail`
         where true
         "
         .$where.
         "
         ;"
     ));
    $sourcelist = DB::select(DB::raw("
        SELECT distinct sourceid,datasource
        FROM `sales.rpt_invoice_trail`
        where true
        "
        .$where.
        "
        ;"
    ));

      return view('dashboard', ["yearlist"=>$yearlist,"periodlist"=>$periodlist,"bulist"=>$bulist,"subchannel2list"=>$subchannel2list,"sourcelist"=>$sourcelist,"mrcodelist"=>$mrcodelist,"flmcodelist"=>$flmcodelist,"productgrouplist"=>$productgrouplist,"channellist"=>$channellist]);
   }

}
