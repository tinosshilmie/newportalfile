<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use Auth;
use DB;
class DashboardHQController extends Controller
{

  /**
   * Create a new controller instance.
   *
   * @return void
   */
  public function __construct()
  {
      $this->middleware('auth');
  }

  /**
   * Show the application dashboardhq.
   *
   * @return \Illuminate\Contracts\Support\Renderable
   */

   public function updatelog($type) {
   $query = DB::select(DB::raw("
     insert into `master.accesslog`
     values (null,'".Auth::user()->id."',now(),'".$type."')
     ;"
   ));
   }
  public function getdashboardhq(Request $data)
  {
    $this->updatelog('View dashboard hq');
    if(Auth::user()->territorytypeid==0){
      $where = "and 1=1";
    }elseif(Auth::user()->territorytypeid==1){
      if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
        $where = "and nsmid in (1,2)";
      }else{
        $where = "and nsmid = ".Auth::user()->territoryid;
      }
    }

    $data['lyyear'] = $data['year']-1;
    $currentYear = date('Y');

    // if($data['year']!=""){
    //   $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$currentYear.")";
    //   $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$currentYear.")";
    // }else{
    //   $whereyear = "and 1=1";
    //   $whereyear2 = "and 1=1";
    //   $whereyear3 = "and 1=1";
    // }
    $whereyear = " AND year in ( ".$data['lyyear'].", ".($data['lyyear']+1)." ) ";
    $whereyear2 = "and a.year in ( ".$data['year'].") ";
    $whereffyear = " AND ffyear=".$currentYear;

    $periodlist;
    if($data['period']!=""){
      $periodlist = explode(" ", $data['period']);
    }else{
      $periodlist = array(date('n'));
    }
    //$whereperiod = "AND a.period IN ( ".end($periodlist)." ) ";
    $whereperiod = "AND a.period IN ( ".$data['period']." ) ";
    $whereperiod2 = "and a.period <= ".end($periodlist)."";

    if($data['productgroupid']!=""){
      $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
    }else{
      $whereproductgroup = "and 1=1";
    }

    if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
    }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
    }

    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }

    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }

    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }

    if ($data['searchsell']=="sellin") {
      $wheresell = "and a.sourceid = 1 and a.buid > 0 and a.seq = 1";
    } else { //sellout
    	$wheresell = "and a.adminacc = 0 and a.buid > 0 and a.seq = 1";
    }

    //$mtd = "SUM(IF(year=".$data['year']." and period=".end($periodlist).", sls, 0)) as 'mtd'";
    //$lymtd = "SUM(IF(year=".$data['lyyear']." and period=".end($periodlist).", sls, 0)) as 'lymtd'";
    $mtd = "SUM(IF(year=".$data['year']." and period in (".$data['period']."), sls, 0)) as 'mtd'";
    $lymtd = "SUM(IF(year=".$data['lyyear']." and period in (".$data['period']."), sls, 0)) as 'lymtd'";
    $cytd = "SUM(IF(year=".$data['year']." and period<=".end($periodlist).", sls, 0)) as 'cytd'";
    $lytd = "SUM(IF(year=".$data['lyyear']." and period<=".end($periodlist).", sls, 0)) as 'lytd'";

    $query =
    "SELECT
    ".$mtd.",
    ".$lymtd.",
    ".$cytd.",
    ".$lytd."
    FROM `sales.portal_invoice_trail` a
    WHERE true
    ".$where."
    ".$whereyear."
    ".$whereproductgroup."
    ".$wherechannel."
    ".$wherebu."
    ".$wheresubchannel2."
    ".$wheresource."
    ".$whereperiod2."
    ".$whereffyear."
    ".$wheresell."
    ;";
    // echo json_encode($query); exit();
    $result =  DB::select(DB::raw($query));
    // $data['query'] = $query;

    $data['mtdtarget'] = DB::select(DB::raw("
       SELECT round(sum(tgt)) as tgt
       FROM `sales.comp_target_dtl` a
       where true
       "./*$where.*/"
       "
       .$whereyear2."
       "
       .$whereperiod."
       "
       .$whereproductgroup.
       "
       ;"
    ));
    $data['ytdtarget'] = DB::select(DB::raw("
       SELECT round(sum(tgt)) as tgt
       FROM `sales.comp_target_dtl` a
       where true
       "./*$where.*/"
       "
       .$whereyear2.
       "
       "
       .$whereperiod2.
       "
       "
       .$whereproductgroup.
       "
       ;"
    ));

    $data['mtdsales'] = round($result[0]->mtd);
    $data['lymtdsales'] = round($result[0]->lymtd);
    $data['cytdsales'] = round($result[0]->cytd);
    $data['lytdsales'] = round($result[0]->lytd);

    if((int)$data['mtdtarget'][0]->tgt != 0){
      $data['perf'] = round(($data['mtdsales']/$data['mtdtarget'][0]->tgt) * 100);
    }else{
      $data['perf'] = 100;
    }
    if((int)$data['ytdtarget'][0]->tgt != 0){
      $data['perf2'] = round(($data['cytdsales']/$data['ytdtarget'][0]->tgt) * 100);
    }else{
      $data['perf2'] = 100;
    }

    if((int)$data['lymtdsales'] != 0){
      $data['growth'] = round(($data['mtdsales']/$data['lymtdsales']) * 100);
    }else{
      $data['growth'] = 100;
    }
    if((int)$data['lytdsales'] != 0){
      $data['growth2'] = round(($data['cytdsales']/$data['lytdsales']) * 100);
    }else{
      $data['growth2'] = 100;
    }
    // echo json_encode($data); exit();
    return response()->json($data);

      /*
      $data['mtdsales'] = DB::select(DB::raw("
         SELECT round(sum(sls)) as sls
         FROM `sales.portal_invoice_trail` a
         where true

         ".$where."
         "
         .$whereyear.
         "
         "
         .$whereperiod.
         "
         "
         .$whereproductgroup.
         "
         "
         .$wherechannel.
         "
         "
         .$wherebu.
         "
         "
         .$wheresubchannel2.
         "
         "
         .$wheresource.
         "
         "
         .$wheresell.
         "
         ;"
      ));
      $data['lymtdsales'] = DB::select(DB::raw("
         SELECT round(sum(sls)) as sls
         FROM `sales.portal_invoice_trail` a
         where true

         ".$where."
         "
         .$whereyear2.
         "
         "
         .$whereperiod.
         "
         "
         .$whereproductgroup.
         "
         "
         .$wherechannel.
         "
         "
         .$wherebu.
         "
         "
         .$wheresubchannel2.
         "
         "
         .$wheresource.
         "
         "
         .$wheresell.
         "
         ;"
      ));
      $data['ytdsales'] = DB::select(DB::raw("
         SELECT round(sum(sls)) as sls
         FROM `sales.portal_invoice_trail` a
         where true

         ".$where."
         "
         .$whereyear.
         "
         "
         .$whereperiod2.
         "
         "
         .$whereproductgroup.
         "
         "
         .$wherechannel.
         "
         "
         .$wherebu.
         "
         "
         .$wheresubchannel2.
         "
         "
         .$wheresource.
         "
         "
         .$wheresell.
         "
         ;"
      ));
      $data['lyytdsales'] = DB::select(DB::raw("
         SELECT round(sum(sls)) as sls
         FROM `sales.portal_invoice_trail` a
         where true

         ".$where."
         "
         .$whereyear2.
         "
         "
         .$whereperiod2.
         "
         "
         .$whereproductgroup.
         "
         "
         .$wherechannel.
         "
         "
         .$wherebu.
         "
         "
         .$wheresubchannel2.
         "
         "
         .$wheresource.
         "
         "
         .$wheresell.
         "
         ;"
      ));
      $data['mtdtarget'] = DB::select(DB::raw("
         SELECT round(sum(tgt)) as tgt
         FROM `sales.comp_target_dtl` a
         where true
         ".$where."
         "
         .$whereyear3.
         "
         "
         .$whereperiod.
         "
         "
         .$whereproductgroup.
         "
         ;"
      ));
      $data['ytdtarget'] = DB::select(DB::raw("
         SELECT round(sum(tgt)) as tgt
         FROM `sales.comp_target_dtl` a
         where true
         ".$where."
         "
         .$whereyear3.
         "
         "
         .$whereperiod2.
         "
         "
         .$whereproductgroup.
         "
         ;"
      ));
      if((int)$data['mtdtarget'][0]->tgt != 0){
        $data['perf'] = round(($data['mtdsales'][0]->sls/$data['mtdtarget'][0]->tgt) * 100);
      }else{
        $data['perf'] = 100;
      }
      if((int)$data['ytdtarget'][0]->tgt != 0){
        $data['perf2'] = round(($data['ytdsales'][0]->sls/$data['ytdtarget'][0]->tgt) * 100);
      }else{
        $data['perf2'] = 100;
      }

      if((int)$data['lymtdsales'][0]->sls != 0){
        $data['growth'] = round(($data['mtdsales'][0]->sls/$data['lymtdsales'][0]->sls) * 100);
      }else{
        $data['growth'] = 100;
      }
      if((int)$data['lyytdsales'][0]->sls != 0){
        $data['growth2'] = round(($data['ytdsales'][0]->sls/$data['lyytdsales'][0]->sls) * 100);
      }else{
        $data['growth2'] = 100;
      }

      return response()->json($data);

      */
   }

  public function getdashboardhq2(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
      $where = "and 1=1";
    }elseif(Auth::user()->territorytypeid==1){
      if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
        $where = "and nsmid in (1,2)";
      }else{
        $where = "and nsmid = ".Auth::user()->territoryid;
      }
    }

    $data['lyyear'] = $data['year']-1;
    $currentYear = date('Y');

    $whereyear = " AND year in ( ".$data['lyyear'].", ".($data['lyyear']+1)." ) ";
    $whereyear2 = "and a.year in ( ".$data['year'].") ";
    $whereffyear = " AND ffyear=".$currentYear;

    $periodlist;
    if($data['period']!=""){
      $periodlist = explode(" ", $data['period']);
    }else{
      $periodlist = array(date('n'));
    }
    $whereperiod = "AND a.period IN ( ".end($periodlist)." ) ";
    $whereperiod2 = "and a.period <= ".end($periodlist)."";

    // $data['lyyear'] = $data['year']-1;
    // $currentYear = date('Y');
    // if($data['year']!=""){
    //   $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$currentYear.")";
    //   $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$currentYear.")";
    //   $whereyear3 = "and a.year in ( ".$data['year'].") ";
    // }else{
    //   $whereyear = "and 1=1";
    //   $whereyear2 = "and 1=1";
    //   $whereyear3 = "and 1=1";
    // }
    // if($data['period']!=""){
    //   $whereperiod = "and a.period in ( ".$data['period'].")";
    //   $whereperiod2 = "and a.period <= ".$data['period']."";
    // }else{
    //   $whereperiod = "and 1=1";
    //   $whereperiod2 = "and 1=1";
    // }

    if($data['productgroupid']!=""){
      $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
    }else{
      $whereproductgroup = "and 1=1";
    }

    if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
    }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
    }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
  	if ($data['searchsell']=="sellin") {
  	  $wheresell = "and a.sourceid = 1 and a.buid > 0 and a.seq = 1";
  	} else { //sellout
  	  $wheresell = "and a.adminacc = 0 and a.buid > 0 and a.seq = 1";
  	}

    $sls = "SUM(IF(year=".$data['year'].", sls, 0)) as 'sls'";
    $lysls = "SUM(IF(year=".$data['lyyear'].", sls, 0)) as 'lysls'";

    $query = DB::select(DB::raw("
      SELECT sum(a.sls) as sls,sum(b.tgt) as tgt ,(sum(sls)/sum(tgt)) * 100 as perf ,(sum(a.sls)/sum(a.lysls)) * 100 as growth
      FROM (
        SELECT $sls, $lysls, period, year
        FROM `sales.portal_invoice_trail` a
        WHERE true
        ".$where."
        ".$whereyear."
        ".$whereffyear."
        ".$whereperiod2."
        ".$whereproductgroup."
        ".$wherechannel."
        ".$wherebu."
        ".$wheresubchannel2."
        ".$wheresource."
        ".$wheresell."
        GROUP BY period,year
      ) a
      LEFT JOIN (
        select sum(tgt) as tgt,period,year
        from `sales.comp_target_dtl` a
        WHERE true
        "./*$where.*/"
        ".$whereyear2."
        ".$whereproductgroup."
        ".$wherechannel."
        GROUP BY period,year
      ) b ON a.year = b.year and a.period = b.period
      WHERE TRUE
      GROUP BY a.period
      ORDER BY a.period
    ;"));

	  // echo json_encode(value); exit();
    /*
    $query = DB::select(DB::raw("
        SELECT sum(a.sls) as sls,sum(b.tgt) as tgt ,(sum(sls)/sum(tgt)) * 100 as perf ,(sum(a.sls)/sum(c.lysls)) * 100 as growth
         FROM (
           select sum(sls) as sls,period,year
           from `sales.portal_invoice_trail` a
           where true
           ".$where."
           "
           .$whereyear.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           "
           .$wheresell.
           "
           group by period,year
           ) a
         left join (
           select sum(tgt) as tgt,period,year
           from `sales.comp_target_dtl` a
           where true
           ".$where."
           "
           .$whereyear3.
           "
           "
           .$wherechannel.
           "
           "
           .$whereproductgroup.
           "
           group by period,year
           ) b on a.year = b.year and a.period = b.period
         left join (
           select sum(sls) as lysls,period,year
           from `sales.portal_invoice_trail` a
           where true
           ".$where."
           "
           .$whereyear2.
           "
           "
           .$whereproductgroup.
           "
           "
           .$wherechannel.
           "
           "
           .$wherebu.
           "
           "
           .$wheresubchannel2.
           "
           "
           .$wheresource.
           "
           "
           .$wheresell.
           "
           group by period,year
           ) c on a.period = c.period
        where true
        group by a.period
        order by a.period
        ;"
     ));
     */
     $counter1 = 0;
     // echo json_encode($query); exit();
     $salesarray = array();
     $targetarray = array();
     $perfarray = array();
     $growtharray = array();
     foreach($query as $key => $val){
         $salesarray[$counter1]=round($val->sls);
         $targetarray[$counter1]=round($val->tgt);
         $perfarray[$counter1]=round($val->perf);
         $growtharray[$counter1]=round($val->growth);
         $counter1 = $counter1 + 1;
     }
     $data['sales'] = json_encode($salesarray);
     $data['target'] = json_encode($targetarray);
     $data['perf'] = json_encode($perfarray);
     $data['growth'] = json_encode($growtharray);
     return response()->json($data);
  }


  public function getdashboardhq3(Request $data)
  {
    if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }

      $data['lyyear'] = $data['year']-1;
      $currentYear = date('Y');
      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$currentYear.")";
        $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$currentYear.")";
      }else{
        $whereyear = "and 1=1";
        $whereyear2 = "and 1=1";
      }
      if($data['period']!=""){
        $whereperiod = "and a.period in ( ".$data['period'].")";
        $whereperiod2 = "and a.period <= ".$data['period']."";
      }else{
        $whereperiod = "and 1=1";
        $whereperiod2 = "and 1=1";
      }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }


     if($data['channelid']!=""){
      $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
      $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
     }else{
      $wherechannel = "and 1=1";
      $wherechanneltgt = "and 1=1";
     }
    if($data['buid']!=""){
      $wherebu = "and a.buid in ( ".$data['buid'].")";
    }else{
      $wherebu = "and 1=1";
    }
    if($data['subchannel2id']!=""){
      $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
    }else{
      $wheresubchannel2 = "and 1=1";
    }
    if($data['sourceid']!=""){
      $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
    }else{
      $wheresource = "and 1=1";
    }
    if ($data['searchsell']=="sellin") {
      $wheresell = "and a.sourceid = 1 and a.buid > 0 and a.seq = 1";
    } else { //sellout
    	$wheresell = "and a.adminacc = 0 and a.buid > 0 and a.seq = 1";
    }



    $query = DB::select(DB::raw("
       SELECT sum(a.sls) as sls,productgroup
        FROM `sales.portal_invoice_trail` a
       where true
       ".$where."
       "
       .$whereyear.
       "
       "
       .$whereperiod.
       "
       "
       .$whereproductgroup.
       "
       "
       .$wherechannel.
       "
       "
       .$wherebu.
       "
       "
       .$wheresubchannel2.
       "
       "
       .$wheresource.
       "
       "
       .$wheresell.
       "
       group by productgroup
       ;"
    ));
    $counter1 = 0;
    $salesarray = array();
    $labelarray = array();
    $total = 0;

    foreach($query as $key => $val){
        $salesarray[$counter1]=round($val->sls);
        $labelarray[$counter1]=($val->productgroup);
        $counter1 = $counter1 + 1;
        $total += $val->sls;
    }

    $data['sales'] = json_encode($salesarray);
    $data['total'] = json_encode($total);
    $data['label'] = json_encode($labelarray);

     return response()->json($data);
  }


    public function getdashboardhq4(Request $data)
    {
      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==1){
          if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
            $where = "and nsmid in (1,2)";
          }else{
            $where = "and nsmid = ".Auth::user()->territoryid;
          }
        }

        $data['lyyear'] = $data['year']-1;
        $currentYear = date('Y');
        if($data['year']!=""){
          $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$currentYear.")";
          $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$currentYear.")";
        }else{
          $whereyear = "and 1=1";
          $whereyear2 = "and 1=1";
        }
        if($data['period']!=""){
          $whereperiod = "and a.period in ( ".$data['period'].")";
          $whereperiod2 = "and a.period <= ".$data['period']."";
        }else{
          $whereperiod = "and 1=1";
          $whereperiod2 = "and 1=1";
        }

       if($data['productgroupid']!=""){
         $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
       }else{
         $whereproductgroup = "and 1=1";
       }


       if($data['channelid']!=""){
        $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
       }else{
        $wherechannel = "and 1=1";
        $wherechanneltgt = "and 1=1";
       }
      if($data['buid']!=""){
        $wherebu = "and a.buid in ( ".$data['buid'].")";
      }else{
        $wherebu = "and 1=1";
      }
      if($data['subchannel2id']!=""){
        $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
      }else{
        $wheresubchannel2 = "and 1=1";
      }
      if($data['sourceid']!=""){
        $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
      }else{
        $wheresource = "and 1=1";
      }
      if ($data['searchsell']=="sellin") {
        $wheresell = "and a.sourceid = 1 and a.buid > 0 and a.seq = 1";
      } else { //sellout
      	$wheresell = "and a.adminacc = 0 and a.buid > 0 and a.seq = 1";
      }


      $query = DB::select(DB::raw("
      SELECT shiptoname, sum(sls) as totalsls FROM `sales.portal_invoice_trail` a
      where true
      ".$where."
      "
      .$whereyear.
      "
      "
      .$whereperiod.
      "
      "
      .$whereproductgroup.
      "
      "
      .$wherechannel.
      "
      "
      .$wherebu.
      "
      "
      .$wheresubchannel2.
      "
      "
      .$wheresource.
      "
      "
      .$wheresell.
      "
      GROUP BY shiptoname
      ORDER BY totalsls DESC limit 20;"

      ));
      $counter1 = 0;
      $salesarray = array();
      $labelarray = array();
      foreach($query as $key => $val){
          $salesarray[$counter1]=round($val->totalsls);
          $array = explode( "\n", wordwrap( $val->shiptoname, 40));
          $labelarray[$counter1]=($array);
          $counter1 = $counter1 + 1;
      }
      $data['sales'] = json_encode($salesarray);
      $data['label'] = json_encode($labelarray);

       return response()->json($data);
    }


    public function getdashboardhq5(Request $data)
    {
      if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }

      $data['lyyear'] = $data['year']-1;
      $currentYear = date('Y');

      $whereyear = " AND year in ( ".$data['lyyear'].", ".($data['lyyear']+1)." ) ";
      $whereyear2 = "and a.year in ( ".$data['year'].") ";
      $whereffyear = " AND ffyear=".$currentYear;

      $periodlist;
      if($data['period']!=""){
        $periodlist = explode(" ", $data['period']);
      }else{
        $periodlist = array(date('n'));
      }
      $whereperiod = "AND a.period IN ( ".end($periodlist)." ) ";
      $whereperiod2 = "and a.period <= ".end($periodlist)."";

      /*
      $data['lyyear'] = $data['year']-1;
      $currentYear = date('Y');
      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$currentYear.")";
        $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$currentYear.")";
        $whereyear3 = "and a.year in ( ".$data['year'].")";
      }else{
        $whereyear = "and 1=1";
        $whereyear2 = "and 1=1";
        $whereyear3 = "and 1=1";
      }
      if($data['period']!=""){
        $whereperiod = "and a.period in ( ".$data['period'].")";
        $whereperiod2 = "and a.period <= ".$data['period']."";
      }else{
        $whereperiod = "and 1=1";
        $whereperiod2 = "and 1=1";
      }
      */

      if($data['productgroupid']!=""){
        $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
      }else{
        $whereproductgroup = "and 1=1";
      }


      if($data['channelid']!=""){
        $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
      }else{
        $wherechannel = "and 1=1";
        $wherechanneltgt = "and 1=1";
      }
      if($data['buid']!=""){
        $wherebu = "and a.buid in ( ".$data['buid'].")";
      }else{
        $wherebu = "and 1=1";
      }
      if($data['subchannel2id']!=""){
        $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
      }else{
        $wheresubchannel2 = "and 1=1";
      }
      if($data['sourceid']!=""){
        $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
      }else{
        $wheresource = "and 1=1";
      }
      if ($data['searchsell']=="sellin") {
        $wheresell = "and a.sourceid = 1 and a.buid > 0 and a.seq = 1";
      } else { //sellout
      	$wheresell = "and a.adminacc = 0 and a.buid > 0 and a.seq = 1";
      }

      $sls = "SUM(IF(year=".$data['year'].", sls, 0)) as 'sls'";
      $lysls = "SUM(IF(year=".$data['lyyear'].", sls, 0)) as 'lysls'";
      $tgt = "SUM(IF(year=".$data['year'].", tgt, 0)) as 'tgt'";

      $data['table'] = DB::select(DB::raw("
         SELECT a.productgroup,a.product,sum(IFNULL(a.sls, 0)) as sls,sum(IFNULL(a.lysls, 0)) as lysls ,round(IFNULL((sum(a.sls)/sum(a.lysls)) * 100, 0)) as growth,round(IFNULL((sum(a.sls)/sum(c.tgt)) * 100, 0)) as performance
          FROM (
            SELECT $sls, $lysls, 0 as tgt, period, year, productgroup, productgroupid, product
            from `sales.portal_invoice_trail` a
            where true
            ".$where."
            ".$whereyear."
            ".$whereffyear."
            ".$whereperiod."
            ".$whereproductgroup."
            ".$wherechannel."
            ".$wherebu."
            ".$wheresubchannel2."
            ".$wheresource."
            ".$wheresell."
            group by period, year, productgroup, productgroupid, product
            ) a
          left join (
            select 0 as sls, $tgt, period, year, productgroupid
            from `sales.comp_target_dtl` a
            where true
            "./*$where.*/"
            ".$whereyear2."
            ".$whereperiod."
            ".$whereproductgroup."
            group by period, year, productgroupid
            ) c on a.year = c.year and a.period = c.period and a.productgroupid = c.productgroupid
         where true
         group by a.productgroup, a.product
         order by a.productgroup, a.product
         ;"
      ));
      /*
      $data['table'] = DB::select(DB::raw("
         SELECT a.productgroup,a.product,sum(IFNULL(a.sls, 0)) as sls,sum(IFNULL(b.sls, 0)) as lysls ,round(IFNULL((sum(a.sls)/sum(b.sls)) * 100, 0)) as growth,round(IFNULL((sum(a.sls)/sum(c.tgt)) * 100, 0)) as performance
          FROM (
            select sum(sls) as sls,0 as tgt,period,year,productgroup,productgroupid,product
            from `sales.portal_invoice_trail` a
            where true

            ".$where."
            "
            .$whereyear.
            "
            "
            .$whereperiod.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechannel.
            "
            "
            .$wherebu.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$wheresource.
            "
            "
            .$wheresell.
            "
            group by period,year,productgroup,productgroupid,product
            ) a
          left join (
            select sum(sls) as sls,0 as tgtperiod,period,year,productgroup,productgroupid,product
            from `sales.portal_invoice_trail` a
            where true

            ".$where."
            "
            .$whereyear2.
            "
            "
            .$whereperiod.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechannel.
            "
            "
            .$wherebu.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$wheresource.
            "
            "
            .$wheresell.
            "
            group by period,year,productgroup,productgroupid,product
            ) b on a.period = b.period and a.productgroup = b.productgroup and a.product = b.product and a.productgroupid = b.productgroupid
          left join (
            select 0 as sls,sum(tgt) as tgt,period,year,productgroupid
            from `sales.comp_target_dtl` a
            where true
            ".$where."
            "
            .$whereyear3.
            "
            "
            .$whereperiod.
            "
            "
            .$whereproductgroup.
            "
            group by period,year,productgroupid
            ) c on a.year = c.year and a.period = c.period and a.productgroupid = c.productgroupid
         where true
         group by a.productgroup, a.product
         order by a.productgroup, a.product
         ;"
      ));
      */

       return response()->json($data);
    }


    public function getdashboardhq6(Request $data)
    {
      if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }

      $data['lyyear'] = $data['year']-1;
      $currentYear = date('Y');

      $whereyear = " AND year in ( ".$data['lyyear'].", ".($data['lyyear']+1)." ) ";
      $whereyear2 = "and a.year in ( ".$data['year'].") ";
      $whereffyear = " AND ffyear=".$currentYear;

      $periodlist;
      if($data['period']!=""){
        $periodlist = explode(" ", $data['period']);
      }else{
        $periodlist = array(date('n'));
      }
      $whereperiod = "AND a.period IN ( ".end($periodlist)." ) ";
      $whereperiod2 = "and a.period <= ".end($periodlist)."";

      /*
      $data['lyyear'] = $data['year']-1;
      $currentYear = date('Y');
      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$currentYear.")";
        $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$currentYear.")";
        $whereyear3 = "and a.year in ( ".$data['year'].")";
      }else{
        $whereyear = "and 1=1";
        $whereyear2 = "and 1=1";
        $whereyear3 = "and 1=1";
      }
      if($data['period']!=""){
        $whereperiod = "and a.period in ( ".$data['period'].")";
        $whereperiod2 = "and a.period <= ".$data['period']."";
      }else{
        $whereperiod = "and 1=1";
        $whereperiod2 = "and 1=1";
      }
      */

      if($data['productgroupid']!=""){
        $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
      }else{
        $whereproductgroup = "and 1=1";
      }

      if($data['channelid']!=""){
        $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
      }else{
        $wherechannel = "and 1=1";
        $wherechanneltgt = "and 1=1";
      }
      if($data['buid']!=""){
        $wherebu = "and a.buid in ( ".$data['buid'].")";
      }else{
        $wherebu = "and 1=1";
      }
      if($data['subchannel2id']!=""){
        $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
      }else{
        $wheresubchannel2 = "and 1=1";
      }
      if($data['sourceid']!=""){
        $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
      }else{
        $wheresource = "and 1=1";
      }
      if ($data['searchsell']=="sellin") {
        $wheresell = "and a.sourceid = 1 and a.buid > 0 and a.seq = 1";
      } else { //sellout
      	$wheresell = "and a.adminacc = 0 and a.buid > 0 and a.seq = 1";
      }

      $sls = "SUM(IF(year=".$data['year'].", sls, 0)) as 'sls'";
      $lysls = "SUM(IF(year=".$data['lyyear'].", sls, 0)) as 'lysls'";
      $tgt = "SUM(IF(year=".$data['year'].", tgt, 0)) as 'tgt'";

      $data['table'] = DB::select(DB::raw("
         SELECT a.channel,sum(IFNULL(a.sls, 0)) as sls,sum(IFNULL(a.lysls, 0)) as lysls ,round(IFNULL((sum(a.sls)/sum(a.lysls)) * 100, 0)) as growth,round(IFNULL((sum(a.sls)/sum(c.tgt)) * 100, 0)) as performance
          FROM (
            SELECT $sls, $lysls, 0 as tgt, period, year, channel, channelid
            from `sales.portal_invoice_trail` a
            where true
            ".$where."
            ".$whereyear."
            ".$whereffyear."
            ".$whereperiod."
            ".$whereproductgroup."
            ".$wherechannel."
            ".$wherebu."
            ".$wheresubchannel2."
            ".$wheresource."
            ".$wheresell."
            group by period, year, channel, channelid
            ) a
          left join (
            select 0 as sls, $tgt, period, year, channelid
            from `sales.comp_target_dtl` a
            where true
            "./*$where.*/"
            ".$whereyear2."
            ".$whereperiod."
            ".$whereproductgroup."
            group by period, year, channelid
            ) c on a.year = c.year and a.period = c.period and a.channelid = c.channelid
         where true
         group by a.channel
         order by a.channel
         ;"
      ));

      /*
      $data['table'] = DB::select(DB::raw("
         SELECT a.channel,sum(IFNULL(a.sls, 0)) as sls,sum(IFNULL(b.sls, 0)) as lysls ,round(IFNULL((sum(a.sls)/sum(b.sls)) * 100, 0)) as growth,round(IFNULL((sum(a.sls)/sum(c.tgt)) * 100, 0)) as performance
          FROM (
            select sum(sls) as sls,0 as tgt,period,year,channel,channelid
            from `sales.portal_invoice_trail` a
            where true

            ".$where."
            "
            .$whereyear.
            "
            "
            .$whereperiod.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechannel.
            "
            "
            .$wherebu.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$wheresource.
            "
            "
            .$wheresell.
            "
            group by period,year,channel,channelid
            ) a
          left join (
            select sum(sls) as sls,0 as tgtperiod,period,year,channel
            from `sales.portal_invoice_trail` a
            where true

            ".$where."
            "
            .$whereyear2.
            "
            "
            .$whereperiod.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherechannel.
            "
            "
            .$wherebu.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$wheresource.
            "
            "
            .$wheresell.
            "
            group by period,year,channel
            ) b on a.period = b.period and a.channel = b.channel
          left join (
            select 0 as sls,sum(tgt) as tgt,period,year,channelid
            from `sales.comp_target_dtl` a
            where true
            ".$where."
            "
            .$whereyear3.
            "
            "
            .$whereperiod.
            "
            "
            .$whereproductgroup.
            "
            group by period,year,channelid
            ) c on a.year = c.year and a.period = c.period and a.channelid = c.channelid
         where true
         group by a.channel
         order by a.channel
         ;"
      ));
      */
     return response()->json($data);
    }


    public function getdashboardhq7(Request $data)
    {
      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==1){
          if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
            $where = "and nsmid in (1,2)";
          }else{
            $where = "and nsmid = ".Auth::user()->territoryid;
          }
        }

        $data['lyyear'] = $data['year']-1;
        $currentYear = date('Y');
        if($data['year']!=""){
          $whereyear = "and a.year in ( ".$data['year'].") and a.ffyear in ( ".$currentYear.")";
          $whereyear2 = "and a.year in ( ".$data['lyyear'].") and a.ffyear in ( ".$currentYear.")";
        }else{
          $whereyear = "and 1=1";
          $whereyear2 = "and 1=1";
        }
        if($data['period']!=""){
          $whereperiod = "and a.period in ( ".$data['period'].")";
          $whereperiod2 = "and a.period <= ".$data['period']."";
        }else{
          $whereperiod = "and 1=1";
          $whereperiod2 = "and 1=1";
        }

       if($data['productgroupid']!=""){
         $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
       }else{
         $whereproductgroup = "and 1=1";
       }


       if($data['channelid']!=""){
        $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        $wherechanneltgt = "and a.chnnelid in ( ".$data['channelid'].")";
       }else{
        $wherechannel = "and 1=1";
        $wherechanneltgt = "and 1=1";
       }
      if($data['buid']!=""){
        $wherebu = "and a.buid in ( ".$data['buid'].")";
      }else{
        $wherebu = "and 1=1";
      }
      if($data['subchannel2id']!=""){
        $wheresubchannel2 = "and a.subchannel2id in ( ".$data['subchannel2id'].")";
      }else{
        $wheresubchannel2 = "and 1=1";
      }
      if($data['sourceid']!=""){
        $wheresource = "and a.sourceid in ( ".$data['sourceid'].")";
      }else{
        $wheresource = "and 1=1";
      }
      if ($data['searchsell']=="sellin") {
        $wheresell = "and a.sourceid = 1 and a.buid > 0 and a.seq = 1";
      } else { //sellout
      	$wheresell = "and a.adminacc = 0 and a.buid > 0 and a.seq = 1";
      }



      $query = DB::select(DB::raw("
         SELECT sum(a.sls) as sls,ifnull(channel,'null') as channel
          FROM `sales.portal_invoice_trail` a
         where true
         ".$where."
         "
         .$whereyear.
         "
         "
         .$whereperiod.
         "
         "
         .$whereproductgroup.
         "
         "
         .$wherechannel.
         "
         "
         .$wherebu.
         "
         "
         .$wheresubchannel2.
         "
         "
         .$wheresource.
         "
         "
         .$wheresell.
         "
         group by channel
         ;"
      ));
      $counter1 = 0;
      $salesarray = array();
      $labelarray = array();
      $total = 0;

      foreach($query as $key => $val){
          $salesarray[$counter1]=round($val->sls);
          $labelarray[$counter1]=($val->channel);
          $counter1 = $counter1 + 1;
          $total += $val->sls;
      }


      $data['sales'] = json_encode($salesarray);
      $data['total'] = json_encode($total);
      $data['label'] = json_encode($labelarray);

       return response()->json($data);
    }

  public function dashboardhq(Request $data)
  {
    /*if (!empty(Auth::user())) {
      $query = DB::select(DB::raw("
        update `master.user`
        set last_login = now()
        where id = '".Auth::user()->id."'
        ;"
      ));
    }*/
    if(Auth::user()->territorytypeid==0){
      $where = "and 1=1";
    }elseif(Auth::user()->territorytypeid==1){
      if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
        $where = "and nsmid in (1,2)";
      }else{
        $where = "and nsmid = ".Auth::user()->territoryid;
      }
    }

    //drop down list
    /*
    $yearlist = DB::select(DB::raw("
        SELECT distinct year
        FROM `sales.portal_invoice_trail`
        where true
        "
        .$where.
        "
        ;"
    ));
    $periodlist = DB::select(DB::raw("
        SELECT distinct period
        FROM `sales.portal_invoice_trail`
        where true
        "
        .$where.
        "
        ;"
    ));
    $mrcodelist = DB::select(DB::raw("
        SELECT mrid,mrcode,mrname
        FROM `master.view_territory`
        where true
        and shared = 0
        "
        .$where.
        "
        order by mrcode,mrname
        ;"
    ));*/

    /*$flmcodelist = DB::select(DB::raw("
        SELECT distinct flmid,flmcode,flmname
        FROM `master.view_territory`
        where true
        and shared = 0
        "
        .$where.
        "
        order by flmcode,flmname
        ;"
    ));*/


    $yearlist = array();
    $periodlist = array();

    $year = date('Y')-2;
    for($i=0; $i<3; $i++) {
      $yearlist[$i] = (object) array('year' => $year);
      $year++;
    }

    for($i=0; $i<12; $i++) {
      $periodlist[$i] = (object) array('period' => $i+1);
    }

    $productgrouplist = DB::select(DB::raw("
      SELECT id as productgroupid, productgroup
      FROM `master.product_group`
      WHERE id in (
        SELECT productgroupid
        FROM `sales.portal_invoice_trail`
        WHERE true
        AND year >= year(DATE_ADD(now(), INTERVAL -1 MONTH))
        ".$where."
      )
      ORDER BY productgroup
      ;"
    ));

    /*
    $productgrouplist = DB::select(DB::raw("
        SELECT distinct productgroupid,productgroup
        FROM `sales.portal_invoice_trail`
        where true
        and year >= year(DATE_ADD(now(), INTERVAL -1 MONTH))
        "
        .$where.
        "
        order by productgroup
        ;"
    ));
    */

    $channellist = DB::select(DB::raw("
        SELECT id as channelid,channel
        FROM `master.channel`
        where true
        ;"
    ));
    $bulist = DB::select(DB::raw("
        SELECT id as  buid,bu
        FROM `master.bu`
        where true
        ;"
    ));
    $subchannel2list = DB::select(DB::raw("
        SELECT id as subchannel2id,subchannel2
        FROM `master.subchannel2`
        where true
        ;"
    ));
    $sourcelist = DB::select(DB::raw("
        SELECT id as sourceid,datasource
        FROM `master.datasource`
        where true
        ;"
    ));

    return view('dashboard_hq', ["yearlist"=>$yearlist,"periodlist"=>$periodlist,"bulist"=>$bulist,"subchannel2list"=>$subchannel2list,"sourcelist"=>$sourcelist,"productgrouplist"=>$productgrouplist,"channellist"=>$channellist]);
   }

}
