<?php

namespace App\Http\Controllers\Auth;

use DB;
use Auth;
use Session;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Saml2Auth;


class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

   public function redirectToProvider()
   {

   }

   public function handleProviderCallback()
   {
       return redirect()->intended();
   }

   public function logout()
   {
       return redirect('/');
   }


    public function username(){
      return 'email';
    }
    protected function credentials(Request $request)
    {
       return ['email' => $request->{$this->username()}, 'password' => $request->password, 'status' => 1];
    }
    protected function authenticated(Request $request,$user){
      if (!empty(Auth::user())) {
        $query = DB::select(DB::raw("
          update `master_user`
          set last_login = now()
          where id = '".Auth::user()->id."'
          ;"
        ));
        $query = DB::select(DB::raw("
          insert into `master.accesslog`
          values (null,'".Auth::user()->id."',now(),'Login')
          ;"
        ));
        $accesslist = DB::select(DB::raw("
        SELECT
            `b`.`userid` AS `userid`,
                SUM(IF((`b`.`accessid` = 1), 1, 0)) AS `access1`,
                SUM(IF((`b`.`accessid` = 2), 1, 0)) AS `access2`,
                SUM(IF((`b`.`accessid` = 3), 1, 0)) AS `access3`,
                SUM(IF((`b`.`accessid` = 4), 1, 0)) AS `access4`,
                SUM(IF((`b`.`accessid` = 5), 1, 0)) AS `access5`,
                SUM(IF((`b`.`accessid` = 6), 1, 0)) AS `access6`,
                SUM(IF((`b`.`accessid` = 7), 1, 0)) AS `access7`,
                SUM(IF((`b`.`accessid` = 8), 1, 0)) AS `access8`,
                SUM(IF((`b`.`accessid` = 9), 1, 0)) AS `access9`,
                SUM(IF((`b`.`accessid` = 10), 1, 0)) AS `access10`,
                SUM(IF((`b`.`accessid` = 11), 1, 0)) AS `access11`,
                SUM(IF((`b`.`accessid` = 12), 1, 0)) AS `access12`,
                SUM(IF((`b`.`accessid` = 13), 1, 0)) AS `access13`,
                SUM(IF((`b`.`accessid` = 14), 1, 0)) AS `access14`,
                SUM(IF((`b`.`accessid` = 15), 1, 0)) AS `access15`,
                SUM(IF((`b`.`accessid` = 16), 1, 0)) AS `access16`
        FROM
            (`master.portal_access` `a`
        LEFT JOIN `master.portal_access_mapping` `b` ON ((`a`.`id` = `b`.`accessid`)))
        WHERE
            `b`.`userid` = '".Auth::user()->id."'
        GROUP BY `b`.`userid`
          ;"
        ));
        if(count($accesslist)>0){
          Session::put('access1', $accesslist[0]->access1);
          Session::put('access2', $accesslist[0]->access2);
          Session::put('access3', $accesslist[0]->access3);
          Session::put('access4', $accesslist[0]->access4);
          Session::put('access5', $accesslist[0]->access5);
          Session::put('access6', $accesslist[0]->access6);
          Session::put('access7', $accesslist[0]->access7);
          Session::put('access8', $accesslist[0]->access8);
          Session::put('access9', $accesslist[0]->access9);
          Session::put('access10', $accesslist[0]->access10);
          Session::put('access11', $accesslist[0]->access11);
          Session::put('access12', $accesslist[0]->access12);
          Session::put('access13', $accesslist[0]->access13);
          Session::put('access14', $accesslist[0]->access14);
          Session::put('access15', $accesslist[0]->access15);
          Session::put('access16', $accesslist[0]->access16);
        }else{
          Session::put('access1', 0);
          Session::put('access2', 0);
          Session::put('access3', 0);
          Session::put('access4', 0);
          Session::put('access5', 0);
          Session::put('access6', 0);
          Session::put('access7', 0);
          Session::put('access8', 0);
          Session::put('access9', 0);
          Session::put('access10', 0);
          Session::put('access11', 0);
          Session::put('access12', 0);
          Session::put('access13', 0);
          Session::put('access14', 0);
          Session::put('access15', 0);
          Session::put('access16', 0);
        }
        

        if(Auth::user()->territorytypeid== 3)
        {
          $query = DB::select(DB::raw("
            select * from `master.territory_mr`
            where id = '".Auth::user()->territoryid."'
            ;"
          ));
          Session::put('ka', $query[0]->ka);
        }else{
          Session::put('ka', 1);
        }
	if(Auth::user()->principalid!= "")
        {
          if(Auth::user()->principalid > 0)
          {
            $query = DB::select(DB::raw("
              select * from `master.principal`
              where id = '".Auth::user()->principalid."'
              ;"
            ));
            Session::put('principalname', $query[0]->principalname);
          }
          else{
            Session::put('principalname', '');
          }
        }else{
          Session::put('principalname', '');
        }
      }
    }
}
