<?php

namespace App\Http\Controllers;

use App\Exports\CustomerExport;
use App\Imports\CustomerImport;
use App\Exports\DoctorExport;
use App\Imports\DoctorImport;
use App\Exports\UserExport;
use App\Exports\ForecastExport;
use App\Imports\ForecastImport;
use App\Exports\TargetExport;
use App\Imports\TargetImport;
use App\Exports\Target2Export;
use App\Imports\Target2Import;
use App\Exports\CompTargetExport;
use App\Imports\CompTargetImport;
use App\Exports\KATargetExport;
use App\Imports\KATargetImport;
use App\Exports\TaggingExport;
use App\Imports\TaggingImport;
use App\Exports\RetaggingExport;
use App\Imports\RetaggingImport;
use App\Exports\FCAccuracyExport;
use App\Exports\DailyInvoiceExport;
use Rap2hpoutre\FastExcel\FastExcel;
use App\Exports\SampleOrderExport;
use App\Exports\SampleOrderExport2;
use Illuminate\Support\Facades\Mail;
use App\Mail\SampleOrderMail;
use App\Mail\ApproveSampleOrderMail;
use App\Mail\ApproveSampleOrderMailRespond;
use App\Mail\RejectSampleOrderMail;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use DateTime;
use Auth;
use DB;
use Session;
class MenuController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

    public function updatelastlogin() {
      /*if (!empty(Auth::user())) {
        $query = DB::select(DB::raw("
          update `master_user`
          set last_login = now()
          where id = '".Auth::user()->id."'
          ;"
        ));
      }*/
    }

    public function updatelog($type) {
      $query = DB::select(DB::raw("
        insert into `master.accesslog`
        values (null,'".Auth::user()->id."',now(),'".$type."')
        ;"
      ));
    }


    public function verifylogin()
    {
    	// echo "<pre>"; print_r(Auth::user()); die();
      $this->updatelastlogin();
      if(Auth::user()->lastupdatepassword == NULL){
        $from = 'new';
        $email = Auth::user()->email;
        return view('verifypassword', ["from"=>$from,"email"=>$email]);
      }elseif(Auth::user()->lastupdatepassword < date("Y-m-d",strtotime("-3 month"))){
        $from = 'expired';
        $email = Auth::user()->email;
        return view('verifypassword', ["from"=>$from,"email"=>$email]);
      }else{
        return redirect()->route('sampleorder');
      }
    }
    public function changepassword()
    {
      $from = 'portal';
      $email = Auth::user()->email;
      return view('verifypassword', ["from"=>$from,"email"=>$email]);
    }

    public function updatepassword(Request $data)
    {
      $error = 0;

      if (!preg_match('/[\'~!^£$%&*()}{@#~?><>,|=_+¬-]/', $data['newpassword'])){
        $error = $error + 1;
        $error1msg = '<p>At least one special character (~!^£$%&*()}{@#~?>...).</p>';
      }else{
        $error1msg = '';
      }
      if ($data['newpassword']!=$data['confirmpassword']) {
        $error = $error + 1;
        $error2msg = '<p>Confirm password not match.</p>';
      }else{
        $error2msg = '';
      }


      if (strlen($data['newpassword']) >= 6){
        $error3msg = '';
      }else{
        $error = $error + 1;
        $error3msg = '<p>At least 6 characters long.</p>';
      }

      if(preg_match("/[A-Z]/", $data['newpassword'])){
       $error4msg = '';
      }else{
        $error = $error + 1;
        $error4msg = '<p>At least one upper case letter.</p>';
      }

      if (preg_match('~[0-9]~', $data['newpassword'])) {
        $error5msg = '';
      }else{
        $error = $error + 1;
        $error5msg = '<p>At least one number.</p>';
      }

      $this->updatelog('Changed password');

      if($error > 0){
        return Response()->json([
          'success' => false,
          'error1msg' => $error1msg,
          'error2msg' => $error2msg,
          'error3msg' => $error3msg,
          'error4msg' => $error4msg,
          'error5msg' => $error5msg
        ]);
      }else{
        $query = DB::select(DB::raw("
          update `master_user`
          set password = '".Hash::make($data['newpassword'])."',
          lastupdatepassword = now()
          where id = '".Auth::user()->id."'
          ;"
        ));
        return Response()->json([
          'success' => true,
          'error1msg' => '',
          'error2msg' => '',
          'error3msg' => '',
          'error4msg' => '',
          'error5msg' => ''
        ]);
      }

    }


    
  public function importdata(Request $data)
  {
    return view('importdata');
  }

  public function savesamplemy(Request $data)
   {
       
      $query = DB::select(DB::raw("
         delete from `sales.invoice_my_r_data`;"
      ));
	
      foreach ($data['data'] as $item) {
	//var_dump($item);
        $query = DB::select(DB::raw("
         insert into `sales.invoice_my_r_data` values 
         ('".$item['id']."','".$item['principal_code']."','".$item['plant']."','".$item['sales_office']."','".$item['transaction_type']."',
         '".$item['transcation_type_description']."','".$item['order_no']."','".$item['doc_no']."','".$item['doc_date']."','".$item['doc_item_line']."',
         '".$item['ppa_additional_item_comment']."','".$item['sold_to_customer_code']."','".$item['old_customer_number']."','".$item['client_customer_code']."',
         '".str_replace("'", "''",$item['sold_to_customer_name_1'])."','".str_replace("'", "''",$item['sold_to_customer_name_2'])."','".$item['sold_to_customer_name_3']."',
         '".$item['sold_to_customer_name_4']."','".$item['shipto_customer_code']."','".str_replace("'", "\'",$item['shipto_customer_name_1'])."',
         '".str_replace("'", "''",$item['shipto_customer_name_2'])."','".$item['shipto_customer_name_3']."','".$item['shipto_customer_name_4']."',
         '".str_replace("'", "''",$item['dlv_addr_ln1'])."','".str_replace("'", "''",$item['dlv_addr_ln2'])."','".str_replace("'", "''",$item['dlv_addr_ln3'])."',
         '".$item['state']."','".$item['cust_group']."','".$item['sap_material']."','".$item['vendor_material_code']."','".$item['old_item_number']."',
         '".str_replace("'", "''",$item['item_description'])."','".$item['sap_batch']."','".$item['vendor_batch']."','".$item['serial_number']."','".$item['expiry_date']."',
         '".$item['qty']."','".$item['unit_sellingprice']."','".$item['b_bonus']."','".$item['sales_value']."','".$item['gst_amount']."','".$item['net_sales_value_after_gst']."',
         '".$item['item_category']."','".$item['business_div_1']."','".str_replace("'", "''",$item['business_div_1_description'])."',
         '".$item['business_div_2']."','".str_replace("'", "''",$item['business_div_2_description'])."','".$item['business_div_3_']."',
         '".str_replace("'", "''",$item['business_div_3_description'])."','".$item['customer_po_no']."','".$item['sales_type']."','".$item['sales_type_desc']."',
         '".$item['sb_partnership']."','".$item['order_reason']."',
         '".$item['order_reason_desc']."','".$item['eapproval_number']."','".$item['so_rcn']."','".$item['usage_indicator']."','".$item['usage_indicator_description']."',
         '".$item['xinvoice_number_of_credit_note']."','".$item['xref_qty']."','".$item['xinvoice_date']."','".$item['rcn_date']."',
         '".str_replace("'", "''",$item['special_instruction1'])."','".str_replace("'", "''",$item['special_instruction2'])."',
         '".$item['doctor_name']."','".$item['patient_name']."','".$item['mrn']."','".$item['date_of_surgery']."','".$item['salesrep']."','".$item['cm_tax']."',
         '".$item['trans_tax']."','".$item['im_tax']."','".$item['purchase_order_type']."','".$item['po_type_description']."','".$item['whs_storage_condition']."',
         '".$item['storage_cond_desc']."','".$item['life_saving']."','".$item['additional_info1']."','".$item['cust_sa_group']."',
         '".str_replace("'", "''",$item['cust_sa_group_desc'])."','".$item['dateimported']."')
         ;"
       ));
      }
      return Response()->json([
        'success' => true
      ]);

  }
  public function savesamplesg(Request $data)
   {
       
      $query = DB::select(DB::raw("
         delete from `sales.invoice_sg_r_data`;"
      ));
      foreach ($data['data'] as $item) {
        $query = DB::select(DB::raw("
         insert into `sales.invoice_sg_r_data` values 
         ('".$item['id']."','".$item['principal_code']."','".$item['plant']."','".$item['sales_office']."','".$item['transaction_type']."',
         '".$item['transcation_type_description']."','".$item['order_no']."','".$item['doc_no']."','".$item['doc_date']."','".$item['doc_item_line']."',
         '".$item['ppa_additional_item_comment']."','".$item['sold_to_customer_code']."','".$item['old_customer_number']."','".$item['client_customer_code']."',
         '".str_replace("'", "''",$item['sold_to_customer_name_1'])."','".str_replace("'", "''",$item['sold_to_customer_name_2'])."','".$item['sold_to_customer_name_3']."',
         '".$item['sold_to_customer_name_4']."','".$item['shipto_customer_code']."','".str_replace("'", "\'",$item['shipto_customer_name_1'])."',
         '".str_replace("'", "''",$item['shipto_customer_name_2'])."','".$item['shipto_customer_name_3']."','".$item['shipto_customer_name_4']."',
         '".str_replace("'", "''",$item['dlv_addr_ln1'])."','".str_replace("'", "''",$item['dlv_addr_ln2'])."','".str_replace("'", "''",$item['dlv_addr_ln3'])."',
         '".$item['state']."','".$item['cust_group']."','".$item['sap_material']."','".$item['vendor_material_code']."','".$item['old_item_number']."',
         '".str_replace("'", "''",$item['item_description'])."','".$item['sap_batch']."','".$item['vendor_batch']."','".$item['serial_number']."','".$item['expiry_date']."',
         '".$item['qty']."','".$item['unit_sellingprice']."','".$item['b_bonus']."','".$item['sales_value']."','".$item['gst_amount']."','".$item['net_sales_value_after_gst']."',
         '".$item['item_category']."','".$item['business_div_1']."','".str_replace("'", "''",$item['business_div_1_description'])."',
         '".$item['business_div_2']."','".str_replace("'", "''",$item['business_div_2_description'])."','".$item['business_div_3_']."',
         '".str_replace("'", "''",$item['business_div_3_description'])."','".$item['customer_po_no']."','".$item['sales_type']."','".$item['sales_type_desc']."',
         '".$item['sb_partnership']."','".$item['order_reason']."',
         '".$item['order_reason_desc']."','".$item['eapproval_number']."','".$item['so_rcn']."','".$item['usage_indicator']."','".$item['usage_indicator_description']."',
         '".$item['xinvoice_number_of_credit_note']."','".$item['xref_qty']."','".$item['xinvoice_date']."','".$item['rcn_date']."',
         '".str_replace("'", "''",$item['special_instruction1'])."','".str_replace("'", "''",$item['special_instruction2'])."',
         '".$item['doctor_name']."','".$item['patient_name']."','".$item['mrn']."','".$item['date_of_surgery']."','".$item['salesrep']."','".$item['cm_tax']."',
         '".$item['trans_tax']."','".$item['im_tax']."','".$item['purchase_order_type']."','".$item['po_type_description']."','".$item['whs_storage_condition']."',
         '".$item['storage_cond_desc']."','".$item['life_saving']."','".$item['additional_info1']."','".$item['cust_sa_group']."','".$item['dateimported']."')
         ;"
       ));
      }
      return Response()->json([
        'success' => true
      ]);

  }
public function savesamplestatus(Request $data)
   {
       
      $query = DB::select(DB::raw("
         delete from `sample_status`;"
      ));
      foreach ($data['data'] as $item) {
        $zp_message_1 = str_replace("'", "''", $item['zp_message_1']);
        $zp_message_2 = str_replace("'", "''", $item['zp_message_2']);
        $query = DB::select(DB::raw("
          insert into `sample_status`
          values 
          ('".$item['transaction_date']."','".$item['country']."','".$item['sender']."','".$item['order_no']."','".$item['status_code']."','".$item['status']."','".$zp_message_1."','".$zp_message_2."','".$item['last_update']."');"
       ));
      }
      return Response()->json([
        'success' => true
      ]);

  }
    public function forecast()
    {
      $this->updatelastlogin();
      $this->updatelog('View forecast');

      if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        #$where = "and nsmuserid = ".Auth::user()->id;
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmuserid = ".Auth::user()->id;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mruserid = ".Auth::user()->id;
      }
      /*
      $query = $yearlist = DB::select(DB::raw("
          SELECT year, period, mrid, mrcode, mrname, productgroupid, productgroup
          FROM `sales.view_forecast_dtl`
          where true and 1=1 group by year, period, mrid, mrcode, mrname, productgroupid, productgroup
          limit 10
          ;"
      ));
      $query = json_decode(json_encode($query), true);
      $yearlist = array();
      $periodlist = array();
      foreach($query as $result) {
        if (!(in_array($result['year'], $yearlist))) {
          array_push($yearlist, $result['year']);
        }
        if (!(in_array($result['period'], $periodlist))) {
          array_push($periodlist, $result['period']);
        }
      }
      echo "<pre>"; print_r($yearlist); echo "********<hr>*******<br>"; print_r($periodlist); die();
      */
      //drop down list
      $query = $yearlist = DB::select(DB::raw("
          SELECT year, period
          FROM `sales.view_target_dtl`
          where true and 1=1 group by year, period
          ;"
      ));
      $query = json_decode(json_encode($query), true);
      $yTemp = array();
      $pTemp = array();
      $yearlist = array();
      $periodlist = array();
      foreach($query as $result) {
        if (!(in_array($result['year'], $yTemp))) {
          array_push($yearlist, (object)array('year' => $result['year']));
          array_push($yTemp, $result['year']);
        }
        if (!(in_array($result['period'], $pTemp))) {
          array_push($periodlist, (object)array('period' => $result['period']));
          array_push($pTemp, $result['period']);
        }
      }
      /*
      $yearlist = DB::select(DB::raw("
          SELECT distinct year
          FROM `sales.view_forecast_dtl`
          where true
          "
          .$where.
          "
          ;"
      ));
      $periodlist = DB::select(DB::raw("
          SELECT distinct period
          FROM `sales.view_forecast_dtl`
          where true
          "
          .$where.
          "
          ;"
      ));
      */
      $mrcodelist = DB::select(DB::raw("
          SELECT distinct mrid,mrcode,mrname
          FROM `master.view_map_approver`
          where true
          "
          .$where.
          "
          order by mrcode,mrname
          ;"
      ));
      $productgrouplist = DB::select(DB::raw("
          SELECT distinct productgroupid,productgroup
          FROM `sales.view_target_dtl`
          where true
          "
          .$where.
          "
          order by productgroup
          ;"
      ));

      $currentfc = DB::select(DB::raw("
          select year,period from `sales.forecast_dtl` where lockstatus = 0 order by year,period limit 1
      ;"
      ));

        return view('forecast', ["forecastlist"=>[],"yearlist"=>$yearlist,"periodlist"=>$periodlist,"mrcodelist"=>$mrcodelist,"productgrouplist"=>$productgrouplist,"currentfc"=>$currentfc]);
    }


   public function getforecast(Request $data)
   {

     if(Auth::user()->territorytypeid==0){
       $where = "and 1=1";
     }elseif(Auth::user()->territorytypeid==1){
       #$where = "and nsmuserid = ".Auth::user()->id;
       if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
         $where = "and nsmid in (1,2)";
       }else{
         $where = "and nsmid = ".Auth::user()->territoryid;
       }
     }elseif(Auth::user()->territorytypeid==2){
       $where = "and flmuserid = ".Auth::user()->id;
     }elseif(Auth::user()->territorytypeid==3){
       $where = "and mruserid = ".Auth::user()->id;
     }

     if($data['year']!=""){
       $whereyear = "and year in ( ".$data['year'].")";
     }else{
       $whereyear = "and 1=1";
     }

     if($data['period']!=""){
       $whereperiod = "and period in ( ".$data['period'].")";
     }else{
       $whereperiod = "and 1=1";
     }

     if($data['mrid']!=""){
       $wheremr = "and mrid in ( ".$data['mrid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }
     $forecastlist = DB::select(DB::raw("
      select * From (
         SELECT a.*,a.targetdtlid as recid,IFNULL(b.fc, 0) as lastfc,if(a.year=c.year and a.period = c.period,a.fc_temp,a.fc) as fc_temp2
         FROM `sales.view_forecast_dtl` a
         left join `sales.forecast_dtl` b on a.mrid = b.mrid and a.productgroupid = b.productgroupid
          and year(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = year(DATE(CONCAT_WS('-', b.year, b.period, 1)))
          and month(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = month(DATE(CONCAT_WS('-', b.year, b.period, 1)))
          ,
          (select year,period from `sales.forecast_dtl` where lockstatus = 0 order by year,period limit 1) c
          ) aaa
         where true
         "
         .$where.
         "
         "
         .$whereyear.
         "
         "
         .$whereperiod.
         "
         "
         .$wheremr.
         "
         "
         .$whereproductgroup.
         "
         order by year,period,mrcode,productgroup
         ;"
     ));
     return response()->json($forecastlist);
   }

   public function saveforecast(Request $data)
   {
     $maxrow = count($data['changes']);

     $this->updatelog('Update forecast');

     for($u = 0; $u<$maxrow; $u++){
        $recid = $data['changes'][$u]['recid'];
        $fc = $data['changes'][$u]['fc_temp'];
        $query = DB::select(DB::raw("
          update `sales.forecast_dtl`
          set fc_temp = '".(int)$fc."'
          ,fc = '".(int)$fc."'
          where id = '".$recid."'
          ;"
        ));
     }
     return response()->json('success');

   }

  public function lockforecast(Request $data)
  {
    $this->updatelog('Lock forecast');

    $currentfc = DB::select(DB::raw("
        select year,period from `sales.forecast_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    $query = DB::select(DB::raw("
      update `sales.forecast_dtl`
      set fc = fc_temp,
      lockstatus = 1,
      lockdate = now(),
      lockby = '".Auth::user()->id."'
      where year = '".$currentfc[0]->year."'
      and period = '".$currentfc[0]->period."'
      ;"
    ));

    $currentfc = DB::select(DB::raw("
        select year,period from `sales.forecast_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    $monthNum  = $currentfc[0]->period;
    $dateObj   = DateTime::createFromFormat('!m', $monthNum);
    $monthName = $dateObj->format('F');
    $nextfc = DB::select(DB::raw("
        select year,period,'".$monthName."' as monthname from `sales.forecast_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    return response()->json($nextfc);

  }



   public function exportforecast(Request $data)
   {
     $this->updatelog('Export forecast');

     $fileName = 'Forecast_'.time().'.xlsx';
      Excel::store(new ForecastExport($data['year'],$data['period'],$data['mrid'],$data['productgroupid']), $fileName, 'public_download');
      $file_path = '/download/'.$fileName;
      $download_link = url($file_path);

      return Response()->json([
          "success" => true,
          "file" => $download_link
      ]);
    }


  public function importforecast (Request $data) {
      //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');

      $this->updatelog('Import forecast');
      $excel = Excel::toArray(new ForecastImport, $data['file'], 'public_upload');
      $sheet1 = $excel[0];

      if($sheet1[0][1]!='Product Group'){
        return Response()->json([
            "success" => false,
            'errors' => 'Wrong file.'
        ]);
      }elseif(count($excel) < 2){
        return Response()->json([
            "success" => false,
            'errors' => 'Wrong file.'
        ]);
      }else{
        $sheet2 = $excel[1];
        $currentfc = DB::select(DB::raw("
            select year,period from `sales.forecast_dtl` where lockstatus = 0 order by year,period limit 1
        ;"));
        if($currentfc[0]->period == $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] && Auth::user()->id == $sheet2[1][2]){
          foreach ($sheet1 as $row)
          {
            if($row[0]!="id"){
                if($row[0]!=""){
                  $query = DB::select(DB::raw("
                      update `sales.forecast_dtl`
                      set fc_temp = ".(float)$row[4]."
                      ,fc = ".(float)$row[4]."
                      where id = ".$row[0]."
                      ;"
                  ));
                }else{
                    $product = DB::select(DB::raw("
                        select * From `master.product_group`
                        where upper(productgroup) = upper('".trim($row[1])."')
                        ;"
                    ));
                    $mr = DB::select(DB::raw("
                        select * From `master.territory_mr`
                        where mrcode = '".trim($row[2])."'
                        ;"
                    ));
                    if(count($product)==1 && count($mr)==1){
                      $checkfc2 = DB::select(DB::raw("
                          select * from `sales.forecast_dtl`
                          where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and mrid = '".$mr[0]->id."' and productgroupid = '".$product[0]->id."'
                          ;"
                      ));
                      if(count($checkfc2)==0){
                        $query = DB::select(DB::raw("
                            insert into `sales.forecast_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                             '".$mr[0]->id."', 0, '".$product[0]->id."', '".(float)$row[4]."', 0, now(), now(),'".Auth::user()->id."',
                              '".Auth::user()->id."', 1, '".(float)$row[4]."', 0, null, null)
                            ;"
                        ));
                      }else{
                        $query = DB::select(DB::raw("
                            update `sales.forecast_dtl`
                            set fc_temp = ".(float)$row[4]."
                            ,fc = ".(float)$row[4]."
                            where id = ".$checkfc2[0]->id."
                            ;"
                        ));
                      }
                    }
              }
            }
          }

          return Response()->json([
              "success" => true
          ]);
        }elseif(($currentfc[0]->period > $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] || $currentfc[0]->year < $sheet2[1][0]) && Auth::user()->id == $sheet2[1][2]){
          foreach ($sheet1 as $row)
          {
            if($row[0]!="id"){
              if($row[0]!=""){
                $query = DB::select(DB::raw("
                    update `sales.forecast_dtl`
                    set fc_temp = ".(float)$row[4].",fc = ".(float)$row[4]."
                    where id = ".$row[0]."
                    ;"
                ));
              }else{
                  $product = DB::select(DB::raw("
                      select * From `master.product_group`
                      where upper(productgroup) = upper('".trim($row[1])."')
                      ;"
                  ));
                  $mr = DB::select(DB::raw("
                      select * From `master.territory_mr`
                      where mrcode = '".trim($row[2])."'
                      ;"
                  ));
                  if(count($product)==1 && count($mr)==1){
                    $checkfc = DB::select(DB::raw("
                        select * from `sales.forecast_dtl`
                        where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."'
                        ;"
                    ));
                    $checkfc2 = DB::select(DB::raw("
                        select * from `sales.forecast_dtl`
                        where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and mrid = '".$mr[0]->id."' and productgroupid = '".$product[0]->id."'
                        ;"
                    ));
                    if(count($checkfc2)==0){
                      $query = DB::select(DB::raw("
                          insert into `sales.forecast_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                           '".$mr[0]->id."', 0, '".$product[0]->id."', '".(float)$row[4]."', 0, now(), now(),'".Auth::user()->id."',
                            '".Auth::user()->id."', 1, '".(float)$row[4]."', '".$checkfc[0]->lockstatus."', '".$checkfc[0]->lockdate."', '".$checkfc[0]->lockby."')
                          ;"
                      ));
                    }else{
                      $query = DB::select(DB::raw("
                          update `sales.forecast_dtl`
                          set fc_temp = ".(float)$row[4].",fc = ".(float)$row[4]."
                          where id = ".$checkfc2[0]->id."
                          ;"
                      ));
                    }

                  }
                }
              }
            }

          return Response()->json([
              "success" => true
          ]);
          /*return Response()->json([
              "success" => false,
              'errors' => 'Please use the latest file.'
          ]);*/
        }else{
          return Response()->json([
              "success" => false,
              'errors' => 'Please use the latest file.'
          ]);
        }
        /*if($currentfc[0]->period == $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] && Auth::user()->id == $sheet2[1][2]){
          foreach ($sheet1 as $row)
          {
            $query = DB::select(DB::raw("
                update `sales.forecast_dtl`
                set fc_temp = ".(float)$row[4]."
                where id = ".$row[0]."
                ;"
            ));
          }

          return Response()->json([
              "success" => true
          ]);
        }else{

          return Response()->json([
              "success" => false,
              'errors' => 'Please use the latest file.'
          ]);
        }*/
      }

   }

  public function target()
    {
      $this->updatelastlogin();
      $this->updatelog('View target');

      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and teamid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==1){
          $where = "and territoryid = ".Auth::user()->territoryid;
        }
      //drop down list
      $yearlist = DB::select(DB::raw("
          SELECT distinct year
          FROM `sales.view_target_dtl`
          where true
          ;"
      ));
      $periodlist = DB::select(DB::raw("
          SELECT distinct period
          FROM `sales.view_target_dtl_bymonth`
          where true
          ;"
      ));
      $mrcodelist = DB::select(DB::raw("
          SELECT distinct territoryid as mrid,territorycode as mrcode,salesrep as mrname
          FROM `sales.view_target_dtl`
          where true
          "
          .$where.
          "
          order by territorycode,mrname
          ;"
      ));
      $productgrouplist = DB::select(DB::raw("
          SELECT distinct productgroupid,productgroup
          FROM `sales.view_target_dtl`
          where true
          "
          .$where.
          "
          order by productgroup
          ;"
      ));

      $currenttgt = DB::select(DB::raw("
          select max(year) as year,max(period) as period from `sales.target2_dtl` order by year,period limit 1
      ;"
      ));
        return view('target', ["targetlist"=>[],"yearlist"=>$yearlist,"periodlist"=>$periodlist,"mrcodelist"=>$mrcodelist,"productgrouplist"=>$productgrouplist,"currenttgt"=>$currenttgt]);
    }


   public function gettarget(Request $data)
   {

      if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and teamid = ".Auth::user()->territoryid;
      }elseif(Auth::user()->territorytypeid==1){
        $where = "and territoryid = ".Auth::user()->territoryid;
      }

     if($data['year']!=""){
       $whereyear = "and year in ( ".$data['year'].")";
     }else{
       $whereyear = "and 1=1";
     }

     if($data['period']!=""){
       $whereperiod = "and period in ( ".$data['period'].")";
     }else{
       $whereperiod = "and 1=1";
     }

     if($data['mrid']!=""){
       $wheremr = "and territoryid in ( ".$data['mrid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }

     $targetlist = DB::select(DB::raw("
      select * From (
         SELECT a.*,a.targetdtlid as recid,if(a.year=c.year and a.period = c.period,a.tgt_temp,a.salestarget) as tgt_temp2
         FROM `sales.view_target_dtl_bymonth` a
          ,
          (select max(year) as year,max(period) as period from `sales.target2_dtl`  order by year,period limit 1) c
          ) aaa
         where true
         "
         .$where.
         "
         "
         .$whereyear.
         "
         "
         .$whereperiod.
         "
         "
         .$wheremr.
         "
         "
         .$whereproductgroup.
         "
         order by year,period,territorycode,productgroup
         ;"
     ));
     return response()->json($targetlist);
   }

   public function savetarget(Request $data)
   {

     $this->updatelog('Update target');
     $maxrow = count($data['changes']);
     for($u = 0; $u<$maxrow; $u++){
        $recid = $data['changes'][$u]['recid'];
        $tgt = $data['changes'][$u]['tgt_temp2'];
        $query = DB::select(DB::raw("
          update `sales.target2_dtl`
          set tgt_temp = '".(int)$tgt."'
          ,tgt = '".(int)$tgt."'
          where id = '".$recid."'
          ;"
        ));
     }
     return response()->json('success');

   }

  public function locktarget(Request $data)
  {

    $this->updatelog('Lock target');

    $currenttgt = DB::select(DB::raw("
        select year,period from `sales.target2_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    $query = DB::select(DB::raw("
      update `sales.target2_dtl`
      set tgt = tgt_temp,
      lockstatus = 1,
      lockdate = now(),
      lockby = '".Auth::user()->id."'
      where year = '".$currenttgt[0]->year."'
      and period = '".$currenttgt[0]->period."'
      ;"
    ));

    $currenttgt = DB::select(DB::raw("
        select year,period from `sales.target_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    $monthNum  = $currenttgt[0]->period;
    $dateObj   = DateTime::createFromFormat('!m', $monthNum);
    $monthName = $dateObj->format('F');
    $nexttgt = DB::select(DB::raw("
        select year,period,'".$monthName."' as monthname from `sales.target_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    return response()->json($nexttgt);

  }
  public function exporttarget(Request $data)
  {
    $this->updatelog('Export target');

    $fileName = 'Target_'.time().'.xlsx';
     Excel::store(new TargetExport($data['year'],$data['period'],$data['mrid'],$data['productgroupid']), $fileName, 'public_download');
     $file_path = '/download/'.$fileName;
     $download_link = url($file_path);

     return Response()->json([
         "success" => true,
         "file" => $download_link
     ]);
   }

   public function importtarget (Request $data) {

     $this->updatelog('Import target');

     //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
     $excel = Excel::toArray(new TargetImport, $data['file'], 'public_upload');
     $sheet1 = $excel[0];

     if($sheet1[0][1]!='Country'){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }elseif(count($excel) < 2){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }else{
       $sheet2 = $excel[1];
       $currentfc = DB::select(DB::raw("
           select year,period from `sales.target2_dtl` where lockstatus = 0 order by year,period limit 1
       ;"));
       if($currentfc[0]->period <= $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] && Auth::user()->id == $sheet2[1][2]){
         foreach ($sheet1 as $row)
         {
           if($row[0]!="id"){
                if($row[0]!=""){
                  $query = DB::select(DB::raw("
                      update `sales.target2_dtl`
                      set tgt_temp = ".(float)$row[9]."
                      ,tgt = ".(float)$row[9]."
                      where id = ".$row[0]."
                      ;"
                  ));
                }else{
                    $country = DB::select(DB::raw("
                        select * From `master.country`
                        where upper(country) = upper('".trim($row[1])."')
                        ;"
                    ));
                    $product = DB::select(DB::raw("
                        select * From `master.product_group`
                        where upper(productgroup) = upper('".trim($row[2])."')
                        ;"
                    ));
                    $sku = DB::select(DB::raw("
                        select * From `master.product`
                        where upper(productcode) = upper('".trim($row[3])."')
                        ;"
                    ));
                    $channel = DB::select(DB::raw("
                        select * From `master.channel`
                        where upper(channel) = upper('".trim($row[5])."')
                        ;"
                    ));
                    $subchannel = DB::select(DB::raw("
                        select * From `master.subchannel`
                        where upper(subchannel) = upper('".trim($row[6])."')
                        ;"
                    ));
                    $mr = DB::select(DB::raw("
                        select * From `master.territory_mr`
                        where mrcode = '".trim($row[7])."'
                        ;"
                    ));
                    if(count($product)==1 && count($mr)==1){
                      $checkfc2 = DB::select(DB::raw("
                          select * from `sales.target2_dtl`
                          where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and mrid = '".$mr[0]->id."' and productgroupid = '".$product[0]->id."'
                          ;"
                      ));
                      if(count($checkfc2)==0){
                        $query = DB::select(DB::raw("
                            insert into `sales.target2_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                             '".$country[0]->id."','".$mr[0]->id."','".$product[0]->id."','".$sku[0]->id."','".$subchannel[0]->id."',0, '".(float)$row[9]."', 0, 0,now(), now(),'".Auth::user()->id."','".Auth::user()->id."', 1,0,null,null, '".(float)$row[9]."')
                            ;"
                        ));
                      }else{
                        $query = DB::select(DB::raw("
                            update `sales.target2_dtl`
                            set tgt_temp = ".(float)$row[9]."
                            ,tgt = ".(float)$row[9]."
                            where id = ".$checkfc2[0]->id."
                            ;"
                        ));
                      }
                    }
              }
            }
         }

         return Response()->json([
             "success" => true
         ]);
       }elseif(($currentfc[0]->period > $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] || $currentfc[0]->year < $sheet2[1][0]) && Auth::user()->id == $sheet2[1][2]){
         foreach ($sheet1 as $row)
         {
           if($row[0]!="id"){
              if($row[0]!=""){
                $query = DB::select(DB::raw("
                    update `sales.target2_dtl`
                    set tgt_temp = ".(float)$row[9].",tgt = ".(float)$row[9]."
                    where id = ".$row[0]."
                    ;"
                ));
              }else{

                    $country = DB::select(DB::raw("
                        select * From `master.country`
                        where upper(country) = upper('".trim($row[1])."')
                        ;"
                    ));
                    $product = DB::select(DB::raw("
                        select * From `master.product_group`
                        where upper(productgroup) = upper('".trim($row[2])."')
                        ;"
                    ));
                    $sku = DB::select(DB::raw("
                        select * From `master.product`
                        where upper(productcode) = upper('".trim($row[3])."')
                        ;"
                    ));
                    $channel = DB::select(DB::raw("
                        select * From `master.channel`
                        where upper(channel) = upper('".trim($row[5])."')
                        ;"
                    ));
                    $subchannel = DB::select(DB::raw("
                        select * From `master.subchannel`
                        where upper(subchannel) = upper('".trim($row[6])."')
                        ;"
                    ));
                    $mr = DB::select(DB::raw("
                        select * From `master.territory_mr`
                        where mrcode = '".trim($row[7])."'
                        ;"
                    ));
                  if(count($product)==1 && count($mr)==1){
                    $checkfc = DB::select(DB::raw("
                        select * from `sales.target2_dtl`
                        where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."'
                        ;"
                    ));
                    $checkfc2 = DB::select(DB::raw("
                        select * from `sales.target2_dtl`
                        where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and mrid = '".$mr[0]->id."' and productgroupid = '".$product[0]->id."'
                        ;"
                    ));
                    if(count($checkfc2)==0){
                      $query = DB::select(DB::raw("
                          insert into `sales.target2_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                           '".$country[0]->id."','".$mr[0]->id."',  '".$product[0]->id."','".$sku[0]->id."','".$subchannel[0]->id."',0 '".(float)$row[9]."', 0,0, now(), now(),'".Auth::user()->id."','".Auth::user()->id."', 1, '".$checkfc[0]->lockstatus."', '".$checkfc[0]->lockdate."','".$checkfc[0]->lockby."', '".(float)$row[9]."')
                          ;"
                      ));
                    }else{
                      $query = DB::select(DB::raw("
                          update `sales.target2_dtl`
                          set tgt_temp = ".(float)$row[9].",tgt = ".(float)$row[9]."
                          where id = ".$checkfc2[0]->id."
                          ;"
                      ));
                    }

                  }
                }
              }
         }

         return Response()->json([
             "success" => true
         ]);
         /*return Response()->json([
             "success" => false,
             'errors' => 'Please use the latest file.'
         ]);*/
       }else{
         return Response()->json([
             "success" => false,
             'errors' => 'Please use the latest file.'
         ]);
       }
       /*if($currentfc[0]->period == $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] && Auth::user()->id == $sheet2[1][2]){
         foreach ($sheet1 as $row)
         {
           $query = DB::select(DB::raw("
               update `sales.target_dtl`
               set tgt_temp = ".(float)$row[4]."
               where id = ".$row[0]."
               ;"
           ));
         }

         return Response()->json([
             "success" => true
         ]);
       }else{

         return Response()->json([
             "success" => false,
             'errors' => 'Please use the latest file.'
         ]);
       }*/
     }

  }




  public function comp_target()
    {
      $this->updatelastlogin();
      $this->updatelog('View company target');

      if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        #$where = "and nsmuserid = ".Auth::user()->id;
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmuserid = ".Auth::user()->id;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mruserid = ".Auth::user()->id;
      }
      //drop down list
      $yearlist = DB::select(DB::raw("
          SELECT distinct year
          FROM `sales.view_comp_target_dtl`
          where true
          "
          .$where.
          "
          ;"
      ));
      $periodlist = DB::select(DB::raw("
          SELECT distinct period
          FROM `sales.view_comp_target_dtl`
          where true
          "
          .$where.
          "
          ;"
      ));
      $mrcodelist = DB::select(DB::raw("
          SELECT distinct channelid,channel
          FROM `sales.view_comp_target_dtl`
          where true
          "
          .$where.
          "
          order by channel
          ;"
      ));
      $productgrouplist = DB::select(DB::raw("
          SELECT distinct productgroupid,productgroup
          FROM `sales.view_comp_target_dtl`
          where true
          "
          .$where.
          "
          order by productgroup
          ;"
      ));

      $currenttgt = DB::select(DB::raw("
          select year,period from `sales.comp_target_dtl` where lockstatus = 0 order by year,period limit 1
      ;"
      ));
        return view('comp_target', ["comp_targetlist"=>[],"yearlist"=>$yearlist,"periodlist"=>$periodlist,"mrcodelist"=>$mrcodelist,"productgrouplist"=>$productgrouplist,"currenttgt"=>$currenttgt]);
    }


   public function getcomp_target(Request $data)
   {

     if(Auth::user()->territorytypeid==0){
       $where = "and 1=1";
     }elseif(Auth::user()->territorytypeid==1){
       #$where = "and nsmuserid = ".Auth::user()->id;
       if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
         $where = "and nsmid in (1,2)";
       }else{
         $where = "and nsmid = ".Auth::user()->territoryid;
       }
     }elseif(Auth::user()->territorytypeid==2){
       $where = "and flmuserid = ".Auth::user()->id;
     }elseif(Auth::user()->territorytypeid==3){
       $where = "and mruserid = ".Auth::user()->id;
     }

     if($data['year']!=""){
       $whereyear = "and year in ( ".$data['year'].")";
     }else{
       $whereyear = "and 1=1";
     }

     if($data['period']!=""){
       $whereperiod = "and period in ( ".$data['period'].")";
     }else{
       $whereperiod = "and 1=1";
     }

     if($data['channelid']!=""){
       $wheremr = "and channelid in ( ".$data['channelid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }
     $comp_targetlist = DB::select(DB::raw("
      select * From (
         SELECT a.*,a.comptargetdtlid as recid,IFNULL(b.tgt, 0) as lasttgt,if(a.year=c.year and a.period = c.period,a.tgt_temp,a.tgt) as tgt_temp2
         FROM `sales.view_comp_target_dtl` a
         left join `sales.comp_target_dtl` b on a.channelid = b.channelid and a.productgroupid = b.productgroupid
          and year(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = year(DATE(CONCAT_WS('-', b.year, b.period, 1)))
          and month(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = month(DATE(CONCAT_WS('-', b.year, b.period, 1)))
          ,
          (select year,period from `sales.comp_target_dtl` where lockstatus = 0 order by year,period limit 1) c
          ) aaa
         where true
         "
         .$where.
         "
         "
         .$whereyear.
         "
         "
         .$whereperiod.
         "
         "
         .$wheremr.
         "
         "
         .$whereproductgroup.
         "
         order by year,period,channel,productgroup
         ;"
     ));
     return response()->json($comp_targetlist);
   }

   public function savecomp_target(Request $data)
   {
     $this->updatelog('Update company target');

     $maxrow = count($data['changes']);
     for($u = 0; $u<$maxrow; $u++){
        $recid = $data['changes'][$u]['recid'];
        $tgt = $data['changes'][$u]['tgt_temp'];
        $query = DB::select(DB::raw("
          update `sales.comp_target_dtl`
          set tgt_temp = '".(int)$tgt."'
          ,tgt = '".(int)$tgt."'
          where id = '".$recid."'
          ;"
        ));
     }
     return response()->json('success');

   }

  public function lockcomp_target(Request $data)
  {

    $this->updatelog('Lock company target');

    $currenttgt = DB::select(DB::raw("
        select year,period from `sales.comp_target_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    $query = DB::select(DB::raw("
      update `sales.comp_target_dtl`
      set tgt = tgt_temp,
      lockstatus = 1,
      lockdate = now(),
      lockby = '".Auth::user()->id."'
      where year = '".$currenttgt[0]->year."'
      and period = '".$currenttgt[0]->period."'
      ;"
    ));

    $currenttgt = DB::select(DB::raw("
        select year,period from `sales.comp_target_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    $monthNum  = $currenttgt[0]->period;
    $dateObj   = DateTime::createFromFormat('!m', $monthNum);
    $monthName = $dateObj->format('F');
    $nexttgt = DB::select(DB::raw("
        select year,period,'".$monthName."' as monthname from `sales.comp_target_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    return response()->json($nexttgt);

  }
  public function exportcomptarget(Request $data)
  {
    $this->updatelog('Export company target');

    $fileName = 'CompTarget_'.time().'.xlsx';
     Excel::store(new CompTargetExport($data['year'],$data['period'],$data['channelid'],$data['productgroupid']), $fileName, 'public_download');
     $file_path = '/download/'.$fileName;
     $download_link = url($file_path);

     return Response()->json([
         "success" => true,
         "file" => $download_link
     ]);
   }

   public function importcomptarget (Request $data) {

     $this->updatelog('Import company target');
     //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
     $excel = Excel::toArray(new CompTargetImport, $data['file'], 'public_upload');
     $sheet1 = $excel[0];
     if($sheet1[0][1]!='Product Group'){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }elseif(count($excel) < 2){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }else{
       $sheet2 = $excel[1];
       $currentfc = DB::select(DB::raw("
           select year,period from `sales.comp_target_dtl` where lockstatus = 0 order by year,period limit 1
       ;"));
       if($currentfc[0]->period == $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] && Auth::user()->id == $sheet2[1][2]){
         /*foreach ($sheet1 as $row)
         {
           if($row[0]!="id"){

             $query = DB::select(DB::raw("
                 update `sales.comp_target_dtl`
                 set  = ".(float)$row[3]."
                 where id = ".$row[0]."
                 ;"
             ));
           }
         }*/
          foreach ($sheet1 as $row)
          {
            if($row[0]!="id"){
                if($row[0]!=""){
                  $query = DB::select(DB::raw("
                      update `sales.comp_target_dtl`
                      set tgt_temp = ".(float)$row[3]."
                      ,tgt = ".(float)$row[3]."
                      where id = ".$row[0]."
                      ;"
                  ));
                }else{
                    $product = DB::select(DB::raw("
                        select * From `master.product_group`
                        where upper(productgroup) = upper('".trim($row[1])."')
                        ;"
                    ));
                    $channel = DB::select(DB::raw("
                        select * From `master.channel`
                        where upper(channel) = upper('".trim($row[2])."')
                        ;"
                    ));
                    if(count($product)==1 && count($channel)==1){
                      $checkfc2 = DB::select(DB::raw("
                          select * from `sales.comp_target_dtl`
                          where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and channelid = '".$channel[0]->id."' and productgroupid = '".$product[0]->id."'
                          ;"
                      ));
                      if(count($checkfc2)==0){
                        $query = DB::select(DB::raw("
                            insert into `sales.comp_target_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                             '".$channel[0]->id."', '".$product[0]->id."',  '".(float)$row[3]."',now(), now(),'".Auth::user()->id."',
                              '".Auth::user()->id."', 1, '".(float)$row[3]."', 0, null, null)
                            ;"
                        ));
                      }else{
                        $query = DB::select(DB::raw("
                            update `sales.comp_target_dtl`
                            set tgt_temp = ".(float)$row[3]."
                            ,tgt = ".(float)$row[3]."
                            where id = ".$checkfc2[0]->id."
                            ;"
                        ));
                      }
                    }
              }
            }
          }
          return Response()->json([
             "success" => true
          ]);
       }elseif(($currentfc[0]->period > $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] || $currentfc[0]->year < $sheet2[1][0]) && Auth::user()->id == $sheet2[1][2]){
         /*foreach ($sheet1 as $row)
         {
           if($row[0]!="id"){
             $query = DB::select(DB::raw("
                 update `sales.comp_target_dtl` a
                 left join `master.product_group` b on a.productgroupid = b.id
                 set a.tgt = ".(float)$row[3].",a.tgt_temp = ".(float)$row[3]."
                 where a.id = ".$row[0]."
                 and b.mkt = 1
                 ;"
             ));
           }
         }*/
          foreach ($sheet1 as $row)
          {
            if($row[0]!="id"){
              if($row[0]!=""){
                $query = DB::select(DB::raw("
                    update `sales.comp_target_dtl` a
                    left join `master.product_group` b on a.productgroupid = b.id
                    set a.tgt = ".(float)$row[3].",a.tgt_temp = ".(float)$row[3]."
                    where a.id = ".$row[0]."
                    and b.mkt = 1
                    "
                ));
              }else{
                  $product = DB::select(DB::raw("
                      select * From `master.product_group`
                      where upper(productgroup) = upper('".trim($row[1])."')
                      ;"
                  ));
                  $channel = DB::select(DB::raw("
                      select * From `master.channel`
                      where upper(channel) = upper('".trim($row[2])."')
                      ;"
                  ));
                  if(count($product)==1 && count($channel)==1){
                    $checkfc = DB::select(DB::raw("
                        select * from `sales.comp_target_dtl`
                        where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."'
                        ;"
                    ));
                    $checkfc2 = DB::select(DB::raw("
                        select * from `sales.comp_target_dtl`
                        where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and channelid = '".$channel[0]->id."' and productgroupid = '".$product[0]->id."'
                        ;"
                    ));
                    if(count($checkfc2)==0){
                      $query = DB::select(DB::raw("
                          insert into `sales.comp_target_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                           '".$channel[0]->id."', '".$product[0]->id."', '".(float)$row[3]."',now(), now(),'".Auth::user()->id."',
                            '".Auth::user()->id."', 1, '".(float)$row[3]."', '".$checkfc[0]->lockstatus."', '".$checkfc[0]->lockdate."', '".$checkfc[0]->lockby."')
                          ;"
                      ));
                    }else{
                      $query = DB::select(DB::raw("
                          update `sales.comp_target_dtl`
                          set tgt_temp = ".(float)$row[3].",tgt = ".(float)$row[3]."
                          where id = ".$checkfc2[0]->id."
                          ;"
                      ));
                    }

                  }
                }
              }
            }
         return Response()->json([
             "success" => true
         ]);
         /*return Response()->json([
             "success" => false,
             'errors' => 'Please use the latest file.'
         ]);*/
       }else{
         return Response()->json([
             "success" => false,
             'errors' => 'Please use the latest file.'
         ]);
       }
     }

  }




  public function ka_target()
    {
      $this->updatelastlogin();

      $this->updatelog('View ka target');

      if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        #$where = "and nsmuserid = ".Auth::user()->id;
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmuserid = ".Auth::user()->id;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mruserid = ".Auth::user()->id;
      }
      //drop down list
      $yearlist = DB::select(DB::raw("
          SELECT distinct year
          FROM `sales.view_ka_target_dtl`
          where true
          "
          .$where.
          "
          ;"
      ));
      $periodlist = DB::select(DB::raw("
          SELECT distinct period
          FROM `sales.view_ka_target_dtl`
          where true
          "
          .$where.
          "
          ;"
      ));
      $mrcodelist = DB::select(DB::raw("
          SELECT distinct subchannelid,subchannel
          FROM `sales.view_ka_target_dtl`
          where true
          "
          .$where.
          "
          order by subchannel
          ;"
      ));
      $productgrouplist = DB::select(DB::raw("
          SELECT distinct productgroupid,productgroup
          FROM `sales.view_ka_target_dtl`
          where true
          "
          .$where.
          "
          order by productgroup
          ;"
      ));
      $typelist = DB::select(DB::raw("
          SELECT *
          FROM `master.ka_type`
          where true
          "
          .$where.
          "
          order by katype
          ;"
      ));

      $currenttgt = DB::select(DB::raw("
          select year,period from `sales.ka_target_dtl` where lockstatus = 0 order by year,period limit 1
      ;"
      ));
        return view('ka_target', ["ka_targetlist"=>[],"yearlist"=>$yearlist,"periodlist"=>$periodlist,"mrcodelist"=>$mrcodelist,"productgrouplist"=>$productgrouplist,"typelist"=>$typelist,"currenttgt"=>$currenttgt]);
    }


   public function getka_target(Request $data)
   {

     if(Auth::user()->territorytypeid==0){
       $where = "and 1=1";
     }elseif(Auth::user()->territorytypeid==1){
       #$where = "and nsmuserid = ".Auth::user()->id;
       if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
         $where = "and nsmid in (1,2)";
       }else{
         $where = "and nsmid = ".Auth::user()->territoryid;
       }
     }elseif(Auth::user()->territorytypeid==2){
       $where = "and flmuserid = ".Auth::user()->id;
     }elseif(Auth::user()->territorytypeid==3){
       $where = "and mruserid = ".Auth::user()->id;
     }

     if($data['year']!=""){
       $whereyear = "and year in ( ".$data['year'].")";
     }else{
       $whereyear = "and 1=1";
     }

     if($data['period']!=""){
       $whereperiod = "and period in ( ".$data['period'].")";
     }else{
       $whereperiod = "and 1=1";
     }

     if($data['subchannelid']!=""){
       $wheremr = "and subchannelid in ( ".$data['subchannelid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }

     if($data['katypeid']!=""){
       $wherekatype = "and katypeid in ( ".$data['katypeid'].")";
     }else{
       $wherekatype = "and 1=1";
     }
     $ka_targetlist = DB::select(DB::raw("
      select * From (
         SELECT a.*,a.katargetdtlid as recid,IFNULL(b.tgt, 0) as lasttgt,if(a.year=c.year and a.period = c.period,a.tgt_temp,a.tgt) as tgt_temp2
         FROM `sales.view_ka_target_dtl` a
         left join `sales.ka_target_dtl` b on a.subchannelid = b.subchannelid and a.productgroupid = b.productgroupid and a.katypeid = b.katypeid
          and year(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = year(DATE(CONCAT_WS('-', b.year, b.period, 1)))
          and month(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = month(DATE(CONCAT_WS('-', b.year, b.period, 1)))
          ,
          (select year,period from `sales.ka_target_dtl` where lockstatus = 0 order by year,period limit 1) c
          ) aaa
         where true
         "
         .$where.
         "
         "
         .$whereyear.
         "
         "
         .$whereperiod.
         "
         "
         .$wheremr.
         "
         "
         .$whereproductgroup.
         "
         "
         .$wherekatype.
         "
         order by year,period,subchannel,productgroup
         ;"
     ));
     return response()->json($ka_targetlist);
   }

   public function saveka_target(Request $data)
   {
     $this->updatelog('Update ka target');

     $maxrow = count($data['changes']);
     for($u = 0; $u<$maxrow; $u++){
        $recid = $data['changes'][$u]['recid'];
        $tgt = $data['changes'][$u]['tgt_temp'];
        $query = DB::select(DB::raw("
          update `sales.ka_target_dtl`
          set tgt_temp = '".(int)$tgt."'
          ,tgt= '".(int)$tgt."'
          where id = '".$recid."'
          ;"
        ));
     }
     return response()->json('success');

   }

  public function lockka_target(Request $data)
  {
    $this->updatelog('Lock ka target');

    $currenttgt = DB::select(DB::raw("
        select year,period from `sales.ka_target_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    $query = DB::select(DB::raw("
      update `sales.ka_target_dtl`
      set tgt = tgt_temp,
      lockstatus = 1,
      lockdate = now(),
      lockby = '".Auth::user()->id."'
      where year = '".$currenttgt[0]->year."'
      and period = '".$currenttgt[0]->period."'
      ;"
    ));

    $currenttgt = DB::select(DB::raw("
        select year,period from `sales.ka_target_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    $monthNum  = $currenttgt[0]->period;
    $dateObj   = DateTime::createFromFormat('!m', $monthNum);
    $monthName = $dateObj->format('F');
    $nexttgt = DB::select(DB::raw("
        select year,period,'".$monthName."' as monthname from `sales.ka_target_dtl` where lockstatus = 0 order by year,period limit 1
    ;"));

    return response()->json($nexttgt);

  }
  public function exportkatarget(Request $data)
  {
    $this->updatelog('Export ka target');

    $fileName = 'KATarget_'.time().'.xlsx';
     Excel::store(new KATargetExport($data['year'],$data['period'],$data['subchannelid'],$data['productgroupid'],$data['katypeid']), $fileName, 'public_download');
     $file_path = '/download/'.$fileName;
     $download_link = url($file_path);

     return Response()->json([
         "success" => true,
         "file" => $download_link
     ]);
   }

   public function importkatarget (Request $data) {
     $this->updatelog('Import ka target');
     //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
     $excel = Excel::toArray(new KATargetImport, $data['file'], 'public_upload');
     $sheet1 = $excel[0];
     if($sheet1[0][1]!='Product Group'){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }elseif(count($excel) < 2){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }else{
       $sheet2 = $excel[1];
       $currentfc = DB::select(DB::raw("
           select year,period from `sales.ka_target_dtl` where lockstatus = 0 order by year,period limit 1
       ;"));
       if($currentfc[0]->period == $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] && Auth::user()->id == $sheet2[1][2]){
         /*foreach ($sheet1 as $row)
         {
           if($row[0]!="id"){
             $query = DB::select(DB::raw("
                 update `sales.ka_target_dtl`
                 set tgt_temp = ".(float)$row[4]."
                 where id = ".$row[0]."
                 ;"
             ));
           }
         }*/
         foreach ($sheet1 as $row)
          {
            if($row[0]!="id"){
                if($row[0]!=""){
                  $query = DB::select(DB::raw("
                      update `sales.ka_target_dtl`
                      set tgt_temp = ".(float)$row[4]."
                      ,tgt = ".(float)$row[4]."
                      where id = ".$row[0]."
                      ;"
                  ));
                }else{
                    $product = DB::select(DB::raw("
                        select * From `master.product_group`
                        where upper(productgroup) = upper('".trim($row[1])."')
                        ;"
                    ));
                    if($row[3]=='LKA'){
                      $katypeid = 1;
                      $subchannel = DB::select(DB::raw("
                        select * From `master.subchannel2`
                        where upper(subchannel2) = upper('".trim($row[2])."')
                        ;"
                      ));
                    }elseif($row[3]=='KA'){
                      $katypeid = 2;
                      $subchannel = DB::select(DB::raw("
                        select * From `master.subchannel3`
                        where upper(subchannel3) = upper('".trim($row[2])."')
                        ;"
                      ));
                    }
                    if(count($product)==1 && count($subchannel)==1){
                      $checkfc2 = DB::select(DB::raw("
                          select * from `sales.ka_target_dtl`
                          where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and subchannelid = '".$subchannel[0]->id."' and productgroupid = '".$product[0]->id."' and katypeid = '".$katypeid."'
                          ;"
                      ));
                      if(count($checkfc2)==0){
                        $query = DB::select(DB::raw("
                            insert into `sales.ka_target_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                             '".$subchannel[0]->id."', '".$product[0]->id."', '".(float)$row[4]."', 0,now(), now(),'".Auth::user()->id."',
                              '".Auth::user()->id."', 1,'".$katypeid."', '".(float)$row[4]."', 0, null, null)
                            ;"
                        ));
                      }else{
                        $query = DB::select(DB::raw("
                            update `sales.ka_target_dtl`
                            set tgt_temp = ".(float)$row[4]."
                            ,tgt = ".(float)$row[4]."
                            where id = ".$checkfc2[0]->id."
                            ;"
                        ));
                      }
                    }
              }
            }
          }
         return Response()->json([
             "success" => true
         ]);
       }elseif(($currentfc[0]->period > $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] || $currentfc[0]->year < $sheet2[1][0]) && Auth::user()->id == $sheet2[1][2]){

         /*foreach ($sheet1 as $row)
         {
           if($row[0]!="id"){
             $query = DB::select(DB::raw("
                 update `sales.ka_target_dtl`
                 set tgt = ".(float)$row[4].",tgt_temp = ".(float)$row[4]."
                 where id = ".$row[0]."
                 ;"
             ));
           }
         }*/
          foreach ($sheet1 as $row)
          {
            if($row[0]!="id"){
              if($row[0]!=""){
                $query = DB::select(DB::raw("
                    update `sales.ka_target_dtl`
                    set tgt = ".(float)$row[4].",tgt_temp = ".(float)$row[4]."
                    where id = ".$row[0]."
                    "
                ));
              }else{
                  $product = DB::select(DB::raw("
                      select * From `master.product_group`
                      where upper(productgroup) = upper('".trim($row[1])."')
                      ;"
                  ));
                  if($row[3]=='LKA'){
                    $katypeid = 1;
                    $subchannel = DB::select(DB::raw("
                      select * From `master.subchannel2`
                      where upper(subchannel2) = upper('".trim($row[2])."')
                      ;"
                    ));
                  }elseif($row[3]=='KA'){
                    $katypeid = 2;
                    $subchannel = DB::select(DB::raw("
                      select * From `master.subchannel3`
                      where upper(subchannel3) = upper('".trim($row[2])."')
                      ;"
                    ));
                  }
                  if(count($product)==1 && count($subchannel)==1){
                    $checkfc = DB::select(DB::raw("
                        select * from `sales.ka_target_dtl`
                        where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."'
                        ;"
                    ));
                    $checkfc2 = DB::select(DB::raw("
                        select * from `sales.ka_target_dtl`
                        where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and subchannelid = '".$subchannel[0]->id."' and productgroupid = '".$product[0]->id."' and katypeid = '".$katypeid."'
                        ;"
                    ));
                    if(count($checkfc2)==0){

                      $query = DB::select(DB::raw("
                          insert into `sales.ka_target_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                           '".$subchannel[0]->id."', '".$product[0]->id."', '".(float)$row[4]."', 0,now(), now(),'".Auth::user()->id."',
                            '".Auth::user()->id."', 1,'".$katypeid."', '".(float)$row[4]."', '".$checkfc[0]->lockstatus."', '".$checkfc[0]->lockdate."', '".$checkfc[0]->lockby."')
                          ;"
                      ));
                    }else{
                      $query = DB::select(DB::raw("
                          update `sales.ka_target_dtl`
                          set tgt_temp = ".(float)$row[4].",tgt = ".(float)$row[4]."
                          where id = ".$checkfc2[0]->id."
                          ;"
                      ));
                    }

                  }
                }
              }
            }
         return Response()->json([
             "success" => true
         ]);
         /*
         return Response()->json([
             "success" => false,
             'errors' => 'Please use the  file.'
         ]);*/
       }else{

         return Response()->json([
             "success" => false,
             'errors' => 'Please use the latest file.'
         ]);
       }
     }

  }




  public function tagging()
    {
      $this->updatelog('View sales mapping');

      $productgrouplist = DB::select(DB::raw("
          SELECT id as productgroupid,`Desc` as productgroup
          FROM `master.product_group`
          where true
          order by productgroup
          ;"
      ));
      $statelist = DB::select(DB::raw("
          SELECT distinct state
          FROM `master.view_customer`
          where true
          ;"
      ));

        return view('tagging', ["productgrouplist"=>$productgrouplist,"statelist"=>$statelist]);
    }

    public function getterritory(Request $data)
    {

      $territorylist = DB::select(DB::raw("
        SELECT *,mrid as recid FROM `master.view_map_approver` where true  order by mrcode,mrname
          ;"
      ));

      return response()->json($territorylist);
    }

   public function gettagging(Request $data)
   {

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }
     if($data['shiptocode']!=""){
       $whereshiptocode = "and a.shiptocode like '%".$data['shiptocode']."%'";
     }else{
       $whereshiptocode = "and 1=1";
     }
     if($data['state']!=""){
       $wherestate = "and a.state in ( ".$data['state'].")";
     }else{
       $wherestate = "and 1=1";
     }

     if($data['shiptoname']!=""){
       $whereshiptoname = "and a.shiptoname like '%".$data['shiptoname']."%'";
     }else{
       $whereshiptoname = "and 1=1";
     }
     /*and a.invoicedate >= STR_TO_DATE(CONCAT(year(DATE_ADD(now(), INTERVAL -5 MONTH)),'-',LPAD(month(DATE_ADD(now(), INTERVAL -5 MONTH)),2,'00'),'-',LPAD(1,2,'00')), '%Y-%m-%d')*/
    $forecastlist = DB::select(DB::raw("
      select distinct a.productgroupid,a.customerid,a.shiptocode,a.shiptoname,a.address1,a.address2,a.address3,a.postalcode,a.state,a.productgroup,a.channel,
      a.imsgroup1,a.imsgroup2,concat(a.productgroupid,'_',a.customerid) as recid from
      `sales.view_invoice_dtl` `a`
      where true
      and (a.TerritoryID is null)
      and a.productgroupid is not null
      and a.customerid is not null
      and invoicedate >=  now()-interval 3 month
       "
       .$whereproductgroup.
       "
       "
       .$whereshiptocode.
       "
       "
       .$wherestate.
       "
       "
       .$whereshiptoname.
       "
       ;"
    ));

     return response()->json($forecastlist);
   }

    public function savetagging(Request $data)
    {

     $this->updatelog('Update sales mapping');
     $editedidarray = explode(',', $data['editedid']) ;
     $editedmridarray = explode(',', $data['editedmrid']);

     for($u = 0; $u<count($editedidarray); $u++){
       $editedid = explode('_', $editedidarray[$u]) ;
       $productgroupid = $editedid[0];
       $customerid = $editedid[1];
       $query = DB::select(DB::raw("
       insert into `master.map_territory_customer_product`  values (null,".$editedmridarray[$u].",".$customerid.",".$productgroupid.",".Auth::user()->id.",".Auth::user()->id.",now(),now(),null,1);"
       ));
      }
      return response()->json('success');

    }


  public function exporttagging(Request $data)
  {

    $this->updatelog('Export sales mapping');

    $fileName = 'Tagging_'.time().'.xlsx';
     Excel::store(new TaggingExport($data['state'],$data['shiptocode'],$data['productgroupid']), $fileName, 'public_download');
     $file_path = '/download/'.$fileName;
     $download_link = url($file_path);

     return Response()->json([
         "success" => true,
         "file" => $download_link
     ]);
   }

   public function importtagging (Request $data) {
     $this->updatelog('Import sales mapping');

     //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
     $excel = Excel::toArray(new TaggingImport, $data['file'], 'public_upload');

     $sheet1 = $excel[0];
     if($sheet1[0][0]!='productgroupid'){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }elseif(count($excel) < 2){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }else{
       $sheet2 = $excel[1];
       foreach ($sheet1 as $row)
       {
         if($row[2]!=""){
           $query = DB::select(DB::raw("
               SELECT * FROM `master.territory`
               where Code = '".trim($row[2])."'
               ;"
           ));
           if(count($query)!=0){
             DB::select(DB::raw("
             insert into `master.map_territory_customer_product`
             values
             (null,".$query[0]->ID.",".$row[1].",".$row[0].",".Auth::user()->id.",".Auth::user()->id.",now(),now(),0,1)
              on duplicate key update OldTerritoryID=TerritoryID, TerritoryID=".$query[0]->ID.", DateModified=now(),ModifiedBy=".Auth::user()->id.";

                 ;"
             ));
           }
          }
       }
        return Response()->json([
          "success" => true
        ]);
     }

  }

public function importtagging2 (Request $data) {
     $this->updatelog('Import sales mapping');

     //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
     $excel = Excel::toArray(new TaggingImport, $data['file'], 'public_upload');

     $sheet1 = $excel[0];    
     if($sheet1[0][0]!='Requisition Form For Customer Mapping Update'){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }elseif(count($excel) < 2){
       return Response()->json([
           "success" => false,
           'errors' => 'Wrong file.'
       ]);
     }else{

       unset($sheet1[5]);
       unset($sheet1[4]);
       unset($sheet1[3]);
       unset($sheet1[2]);
       unset($sheet1[1]);
       unset($sheet1[0]); 
       $sheet2 = $excel[1];
       foreach ($sheet1 as $row)
       {
         if($row[2]!="" and $row[3]!="" and $row[5]!=""){
           $query = DB::select(DB::raw("
               SELECT * FROM `master.customer`
               where shiptocode = '".trim($row[2])."'
               ;"
           ));
           $query2 = DB::select(DB::raw("
               SELECT * FROM `master.product_group`
               where `Desc` = '".trim($row[3])."'
               ;"
           ));
           $query3 = DB::select(DB::raw("
               SELECT * FROM `master.territory`
               where Code = '".trim($row[5])."'
               ;"
           ));
           if(count($query)!=0 and count($query2)!=0 and count($query3)!=0){
             DB::select(DB::raw("
             insert into `master.map_territory_customer_product2`
             values
             (null,".$query3[0]->ID.",".$query[0]->id.",".$query2[0]->ID.",".Auth::user()->id.",".Auth::user()->id.",now(),now(),0,1)
              on duplicate key update OldTerritoryID=TerritoryID, TerritoryID=".$query3[0]->ID.", DateModified=now(),ModifiedBy=".Auth::user()->id."
             ;"
             ));
           }
          }
       }
        return Response()->json([
          "success" => true
        ]);
     }

  }


    public function customer()
    {
      $this->updatelog('View customer');

      $this->updatelastlogin();
      //drop down list
      $countrylist = DB::select(DB::raw("
          SELECT distinct country
          FROM `master.view_customer`
          where true
          ;"
      ));
      $channellist = DB::select(DB::raw("
          SELECT *,id as channelid,channel as text
          FROM `master.channel`
          where true
          ;"
      ));
      $channeloptionlist = DB::select(DB::raw("
          SELECT id ,channel as text
          FROM `master.channel`
          where true
          ;"
      ));
      $subchanneloptionlist = DB::select(DB::raw("
          SELECT id ,subchannel as text
          FROM `master.subchannel`
          where true
          ;"
      ));
      $stateoptionlist = DB::select(DB::raw("
          SELECT distinct state as id,state as text
          FROM `master.view_customer`
          where true
          ;"
      ));
      $countryoptionlist = DB::select(DB::raw("
          SELECT distinct id,country as text
          FROM `master.country`
          where true
          ;"
      ));

        return view('customer', ["customerlist"=>[],"channellist"=>$channellist,"countrylist"=>$countrylist,"channeloptionlist"=>json_encode($channeloptionlist),"subchanneloptionlist"=>json_encode($subchanneloptionlist),"stateoptionlist"=>json_encode($stateoptionlist),"countryoptionlist"=>json_encode($countryoptionlist)]);
    }



public function getcustomer(Request $data)
{

 if($data['shiptocode']!=""){
   $whereshiptocode = "and shiptocode like '%".$data['shiptocode']."%'";
 }else{
   $whereshiptocode = "and 1=1";
 }

 if($data['shiptoname']!=""){
  $whereshiptoname = "and shiptoname like '%".$data['shiptoname']."%'";
}else{
  $whereshiptoname = "and 1=1";
}
if($data['country']!=""){
 $wherecountry = "and country in ( ".$data['country'].")";
}else{
 $wherecountry = "and 1=1";
}


$customerlist = DB::select(DB::raw("
  select a.*,a.id as recid,b.country From `master.customer` a
  left join `master.country` b on a.countryid = b.id
  where true
  "
  .$whereshiptocode.
  "
  "
  .$whereshiptoname.
  "
  "
  .$wherecountry.
  "
  ;"
));
return response()->json($customerlist);
}



public function exportcustomer(Request $data)
{
	set_time_limit(300);      
	$this->updatelog('Export customer');
  $fileName = 'Customer_'.time().'.xlsx';
  Excel::store(new CustomerExport($data['shiptocode'],$data['shiptoname'],$data['country'],$data['channel']), $fileName, 'public_download');
  $file_path = '/download/'.$fileName;
  $download_link = url($file_path);

  return Response()->json([
   "success" => true,
   "file" => $download_link
 ]);
}

public function importcustomer (Request $data) {
 $this->updatelog('Import customer');
       //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
 $excel = Excel::toArray(new CustomerImport, $data['file'], 'public_upload');

 $sheet1 = $excel[0];
 if($sheet1[0][0]!='SAP Code'){
   return Response()->json([
     "success" => false,
     'errors' => 'Wrong file.'
   ]);
 }elseif(count($excel[0]) < 2){
   return Response()->json([
     "success" => false,
     'errors' => 'Wrong file.'
   ]);
 }else{
   foreach ($sheet1 as $row)
   {
     if($row[2]!=""){
       $query = DB::select(DB::raw("
         SELECT * FROM `master.customer`
         where sapcode = '".trim($row[0])."'
         ;"
       ));
       if(count($query)>0){
         $customerid = $query[0]->id;
       }else{
         $customerid = 0;
       }

       $country = DB::select(DB::raw("
         SELECT * FROM `master.country`
         where country = '".trim($row[3])."'
         ;"
       ));
       if(count($country)>0){
         $countryid = $country[0]->id;
       }else{
         $countryid = 0;
       }
       if(count($query)>0){
         DB::select(DB::raw("
           update `master.customer`
           set sapcode = '".$row[0]."',
           customercode = '".$row[0]."',
           soldtocode = '".$row[0]."',
           shiptocode = '".$row[1]."',
           shiptoname = '".str_replace("'", "\'", $row[2])."',
           countryid = '".(int)$countryid."'
           where id = '".$customerid."'
           ;"));
       }else{
         if($row[0]!= 'SAP Code'){
           DB::select(DB::raw("
             insert into `master.customer`
             (sapcode,customercode,soldtocode,
             shiptocode,
             shiptoname,
             countryid,datecreated, datemodified, createdby, modifiedby, sample, status)
             values
             (
             '".$row[0]."',
             '".$row[0]."',
             '".$row[0]."',

             '".$row[1]."',
             '".$row[2]."',
             '".(int)$countryid."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1,1)
             ;"));
         }
       }
     }
   }
   return Response()->json([
    "success" => true
  ]);
 }

}
public function savecustomer(Request $data)
{
 $this->updatelog('Update customer');
 if($data['customerid']!=""){
   $query = DB::select(DB::raw("
     update `master.customer`
     set sapcode = '".$data['sapcode']."',
     customercode = '".$data['sapcode']."',
     soldtocode = '".$data['sapcode']."',
     shiptocode = '".$data['shiptocode']."',
     shiptoname = '".str_replace("'", "\'", $data['shiptoname'])."',
     countryid = '".$data['country']."'
     where id = '".$data['customerid']."'
     ;"
   ));
 }else{
   $query = DB::select(DB::raw("
    insert into `master.customer`
    (id, countryid, sapcode,customercode,soldtocode, shiptocode, shiptoname,datecreated, datemodified, createdby, modifiedby, sample, status)
    VALUES
    (null,'".$data['country']."','".$data['sapcode']."','".$data['sapcode']."','".$data['sapcode']."','".$data['shiptocode']."','".str_replace("'", "\'", $data['shiptoname'])."',
    now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1,1)
    ;"
  ));
 }

 return response()->json('success');

}

   public function product()
   {
     $this->updatelastlogin();
     $this->updatelog('View product');
     //drop down list
     $sampleoptionlist = DB::select(DB::raw("
         SELECT 1 id ,'Yes' as text 
         union all 
         SELECT 0 id ,'No' as text
         ;"
     ));
     $sourceoptionlist = DB::select(DB::raw("
         SELECT distinct source as id ,source as text
         FROM `master.product`
         where true
         ;"
     ));
     $productgroupoptionlist = DB::select(DB::raw("
         SELECT id ,`productgroup` as text
         FROM `master.product_group`
	 where true
	order by productgroup
         ;"
     ));
     $buoptionlist = DB::select(DB::raw("
         SELECT id ,bu as text
         FROM `master.bu`
         where true
         ;"
     ));
     
      $countryoptionlist = DB::select(DB::raw("
          SELECT distinct id,country as text
          FROM `master.country`
          where true
          ;"
      ));
	 $principaloptionlist = DB::select(DB::raw("
  SELECT distinct id,principalcode as text
  FROM `master.principal`
  where true
  ;"
));
     return view('product', ["productlist"=>[],"countryoptionlist"=>json_encode($countryoptionlist),"principaloptionlist"=>json_encode($principaloptionlist),"sourceoptionlist"=>json_encode($sourceoptionlist),"sampleoptionlist"=>json_encode($sampleoptionlist),"productgroupoptionlist"=>json_encode($productgroupoptionlist),"productgroupoptionlist2"=>$productgroupoptionlist,"buoptionlist"=>$buoptionlist]);
   }


  public function getproduct(Request $data)
  {
	DB::enableQueryLog();
    if($data['productgroup']!=""){
      $whereproductgroup = "and productgroupid in (".$data['productgroup'].")";
    }else{
      $whereproductgroup = "and 1=1";
    }

   if($data['code']!=""){
     $wherecode = "and productcode like '%".$data['code']."%'";
   }else{
     $wherecode = "and 1=1";
   }
    if($data['product']!=""){
      $whereproduct = "and productdesc like '%".$data['product']."%'";
    }else{
      $whereproduct = "and 1=1";
    }


    if($data['bu']!=""){
      $wherebu = "and buid in (".$data['bu'].")";
    }else{
      $wherebu = "and 1=1";
    }
    $productlist = DB::select(DB::raw("
     select *,id as recid From `master.view_product`
	where true
        "
        .$wherecode.
        "
        "
        .$whereproduct.
        "
        "
        .$whereproductgroup.
        "
        "
        .$wherebu.
        "
        ;"
    ));
//	dd(DB::getQueryLog());
    return response()->json($productlist);
  }

  public function saveproduct(Request $data)
  {
    $this->updatelog('Update product');
    if($data['productid']!=""){
      $query = DB::select(DB::raw("
       update `master.product`
       set code = '".$data['code']."',
	productcode = '".$data['code']."',
	sapcode = '".$data['sapcode']."',
       `Desc` = '".str_replace("'", "\'", $data['product'])."',
       ProductGroupID = '".(int)$data['productgroup']."',
       countryid = '".(int)$data['country']."',
       principalid = '".(int)$data['principalcode']."',

	source = '".$data['source']."',
       sampletype = '".$data['sampletype']."',
       modifiedby = '".Auth::user()->id."',
       datemodified = now()
       where id = '".$data['productid']."'
       ;"
      ));
    }else{
      $query = DB::select(DB::raw("
   			insert into `master.product`
   			VALUES
   			(null, '".$data['productgroup']."', '".$data['code']."', '".$data['code']."','".$data['sapcode']."','".$data['product']."',null, 0, 1, '".$data['source']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),0, '".$data['sampletype']."','".(int)$data['country']."','".(int)$data['principalcode']."')
   		;"
   		));
    }
    return response()->json('success');
  }



   public function user()
   {
     //drop down list
     $this->updatelog('View user');
     $rptoptionlist = DB::select(DB::raw("
         SELECT id ,description as text
         FROM `master.report_permission`
         where true
         ;"
     ));
     $accessmodulelist = DB::select(DB::raw("
         SELECT *
         FROM `master.portal_access`
         where true
         and status = 1
         ;"
     ));
     $territorytypeidoptionlist = DB::select(DB::raw("
         SELECT distinct territorytypeid as id ,
         CASE territorytypeid
            when '1' then 'SR'
            when '2' then 'SM'
            when '0' then 'Admin'
         END as text
         FROM `master_user`
         where true
         ;"
     ));
     $territoryidoptionlist = DB::select(DB::raw("
         SELECT id,code as text
         FROM `master.territory`
         ;"
     ));
     /*$teamterritoryidoptionlist = DB::select(DB::raw("
         SELECT id,code as text
         FROM `master.team_territory`
         ;"
     ));*/

 $teamidoptionlist = DB::select(DB::raw("
   SELECT id,code as text
   FROM `master.team_territory`
   ;"
 ));
     $approveridoptionlist = DB::select(DB::raw("
	
    select id ,username as text from master_user where status = 1 and territorytypeid = 2 order by username ;
   ;"
 ));

    $statuslist = array();
    $statuslist[0] = (object) array( 'id' => 0, 'text' => 'Inactive' );
    $statuslist[1] = (object) array( 'id' => 1, 'text' => 'Active' );

    // echo "<pre>"; print_r($rptoptionlist); print_r($accesslevellist); die();

    return view('user', ["userlist"=>[],"rptoptionlist"=>json_encode($rptoptionlist),"accessmodulelist"=>$accessmodulelist,"statuslist"=>json_encode($statuslist),"territorytypeidoptionlist"=>json_encode($territorytypeidoptionlist),"territoryidoptionlist"=>json_encode($territoryidoptionlist),"teamidoptionlist"=>json_encode($teamidoptionlist),"approveridoptionlist"=>json_encode($approveridoptionlist)]);
   }


  public function getuser(Request $data)
  {


   if($data['username']!=""){
     $whereusername = "and a.username like '%".$data['username']."%'";
   }else{
     $whereusername = "and 1=1";
   }
    if($data['territorytypeid']!=""){
      $whereterritorytypeid = "and a.territorytypeid in ( ".$data['territorytypeid'].")";
    }else{
      $whereterritorytypeid = "and 1=1";
    }

    $userlist = DB::select(DB::raw("
     select a.*,a.id as recid, CASE a.status when '1' then 'Active' when '0' then 'Inactive' END as status, a.status as statusid,b.description as rptpermission,datejoined,dateresigned,
     CASE a.territorytypeid
        when '1' then 'SR'
        when '2' then 'SM'
        when '0' then 'Admin'
     END as territorytype,
     c.accessmodule
     From `master_user` a
     left join `master.report_permission` b on a.rptpermissionid = b.id
     left join (
        SELECT userid,GROUP_CONCAT(accessid SEPARATOR ',') as accessmodule
        FROM `master.portal_access_mapping`
        where status = 1
        GROUP BY userid
      ) c on a.id = c.userid
        where true
        "
        .$whereusername.
        "
        "
        .$whereterritorytypeid.
        "
        ;"
    ));
    return response()->json($userlist);
  }

  public function saveuser(Request $data)
  {
    $this->updatelog('Update user');
    $datejoined = ($data['datejoined'] == null) ? "null" : "'".$data['datejoined']."'";
    $dateresigned = ($data['dateresigned'] == null) ? "null" : "'".$data['dateresigned']."'";
  $datestart = ($data['datestart'] == null) ? "null" : "'".$data['datestart']."'";
  $dateend = ($data['dateend'] == null) ? "null" : "'".$data['dateend']."'";

    $query = DB::select(DB::raw("
      update `master_user`
      set username = '".$data['username']."',
      territorytypeid = '".(int)$data['territorytypeid']."',
      staffid = '".$data['staffid']."',
      email = '".$data['email']."',
      rptpermissionid = '".(int)$data['rptpermissionid']."',
      datejoined = ".$datejoined.",
      dateresigned = ".$dateresigned.",
    approverid = '".(int)$data['approverid']."',
    datestart = ".$datestart.",
    dateend = ".$dateend.",
      status = ".(int)$data['status']."
      where id = '".$data['id']."'
      ;"
    ));

    $querymodule = DB::select(DB::raw("
      select * from `master.portal_access`
      ;"
    ));
    $checkquery = DB::select(DB::raw("
      delete from `master.portal_access_mapping`
      where userid = '".$data['id']."'
      ;"
    ));
    foreach ($querymodule as $row){
      $thisdata = $data['module'.$row->id];
      if (!empty($thisdata)) {
        if($thisdata==1 || $thisdata=="true"){
          $query = DB::select(DB::raw("
            insert into `master.portal_access_mapping` values (null,'".$data['id']."','".$row->id."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1)
            ;"
          ));
        }
      }
    }

    return response()->json('success');

  }

  public function exportuser(Request $data)
  {
    $this->updatelog('Export user');
    $fileName = 'User_'.time().'.xlsx';
     Excel::store(new UserExport($data['username'],$data['territorytypeid']), $fileName, 'public_download');
     $file_path = '/download/'.$fileName;
     $download_link = url($file_path);

     return Response()->json([
         "success" => true,
         "file" => $download_link
     ]);
   }

  public function checkstaffidexist(Request $data) {
    $result = DB::select(DB::raw(
      "select * from `master_user` where staffid = '".(int)$data['staffid']."';"
    ));

    return response()->json($result);
  }

  public function checkuserterritory(Request $data) {
    $result = DB::select(DB::raw(
      "select * from `master_user` where territorytypeid = '".(int)$data['territorytypeid']."' AND territoryid = '".(int)$data['territoryid']."' AND status = '1';"
    ));

    return response()->json($result);
  }

	public function adduser(Request $data)
	{
    $this->updatelog('Update user');
    if ($data['replace'] === "1") {
      $query = DB::select(DB::raw(
        "
        update `master_user`
        set status = '0'
        where territorytypeid = '".(int)$data['territorytypeid']."' AND territoryid = '".(int)$data['territoryid']."' AND status = '1'
        ;"
      ));
    }
		$datejoined = ($data['datejoined'] == null) ? "null" : "'".$data['datejoined']."'";
		$dateresigned = ($data['dateresigned'] == null) ? "null" : "'".$data['dateresigned']."'";

		$query = DB::select(DB::raw("
			insert into `master_user`
			(id,  username, territorytypeid, territoryid, staffid, email, rptpermissionid, datejoined, dateresigned, sendpassword, status,sendemail,approverid,datestart,dateend)

			VALUES
			(null, '".$data['username']."', '".(int)$data['territorytypeid']."', '".(int)$data['territoryid']."', '".$data['staffid']."', '".$data['email']."',
      '".(int)$data['rptpermissionid']."',  ".$datejoined.", ".$dateresigned.", '1', '1','1', '".(int)$data['approverid']."', ".$datestart.", ".$dateend.")
		;"
		));


		return response()->json('success');

	}





     public function report_permission()
     {
       //drop down list
        $this->updatelog('View report permission');
         return view('report_permission');
     }


    public function getreport_permission(Request $data)
    {

      $report_permissionlist = DB::select(DB::raw("
       select *,id as recid from
       `master.report_permission`
        ;"
      ));
      return response()->json($report_permissionlist);
    }

    public function getreport_permissiondetail(Request $data)
    {

      $report_permissiondetaillist = DB::select(DB::raw("
      SELECT a.*,a.id as recid ,b.rptid,
      CASE
        WHEN b.rptid IS NULL THEN '0'
        ELSE '1'
      END
      as checkbox
      FROM `master.report_list` a
      left join `master.report_permission_mapping` b on a.id = b.rptid and b.rptpermissionid = '".$data['reportpermissionid']."';
        ;"
      ));
      foreach ($report_permissiondetaillist as $key => $index) {
          $report_permissiondetaillist[$key]->checkbox = (bool)$index->checkbox;
        //  $report_permissiondetaillist->$key->var1[]['checkbox'] = (bool)$index['checkbox'];
      }
      return response()->json($report_permissiondetaillist);
    }

    public function savereport_permission(Request $data)
    {
      $this->updatelog('Update report permission');
      if($data['reportpermissionid']!=""){
        $query = DB::select(DB::raw("
          update `master.report_permission`
          set description = '".$data['description']."'
          where id = '".$data['reportpermissionid']."'
          ;"
        ));
      }else{
        $nextid = DB::select(DB::raw("
          select max(id)+1 as id from `master.report_permission`
          ;"
        ));
        $query = DB::select(DB::raw("
          insert into `master.report_permission` values ('".$nextid[0]->id."','".$data['description']."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1)
          ;"
        ));
        $data['reportpermissionid'] = $nextid[0]->id;
      }

      $maxrow = count($data['changes']);
      for($u = 0; $u<$maxrow; $u++){
         $rptid = $data['changes'][$u]['recid'];
         $checkbox = $data['changes'][$u]['checkbox'];
         $check = DB::select(DB::raw("
           select * from `master.report_permission_mapping`
           where rptpermissionid = '".$data['reportpermissionid']."'
           and rptid = ".$rptid."
           ;"
         ));
         if(count($check)> 0){
           if($checkbox=="true"){
             $query = DB::select(DB::raw("
               update `master.report_permission_mapping`
               set rptid = '".$rptid."',modifiedby='".Auth::user()->id."',datemodified=now()
               where id = '".$check[0]->id."'
               ;"
             ));

           }else{
             $query = DB::select(DB::raw("
               delete from `master.report_permission_mapping`
               where id = '".$check[0]->id."'
               ;"
             ));
           }
         }else{
           if($checkbox==true){
             $query = DB::select(DB::raw("
               insert into  `master.report_permission_mapping`
               values (null,".$data['reportpermissionid'].",".$rptid.",now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1)
               ;"
             ));
           }
         }

         /*if($checkbox==true){
           $query = DB::select(DB::raw("
             update `master.report_permission_mapping`
             set rptid = '".(int)$fc."'
             where rptpermissionid = '".$data['reportpermissionid']."'
             ;"
           ));
         }else{

         }*/
      }
      return response()->json('success');

    }




    public function retagging()
      {

        $this->updatelog('View retag sales mapping');
        $productgrouplist = DB::select(DB::raw("
            SELECT id as productgroupid,`Desc` as productgroup
            FROM `master.product_group`
            where true
            order by productgroup
            ;"
        ));
        $statelist = DB::select(DB::raw("
            SELECT distinct state
            FROM `master.view_customer`
            where true
            ;"
        ));

        $mrcodelist = DB::select(DB::raw("
            SELECT id ,Code as mrcode
            FROM `master.territory`
            where true
            order by Code
            ;"
        ));
          return view('retagging', ["productgrouplist"=>$productgrouplist,"statelist"=>$statelist,"mrcodelist"=>$mrcodelist]);
      }


     public function getretagging(Request $data)
     {


        if($data['productgroupid']!=""){
          $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
        }else{
          $whereproductgroup = "and 1=1";
        }
        if($data['shiptocode']!=""){
          $whereshiptocode = "and b.shiptocode like '%".$data['shiptocode']."%'";
        }else{
          $whereshiptocode = "and 1=1";
        }
        if($data['state']!=""){
          $wherestate = "and b.state in ( ".$data['state'].")";
        }else{
          $wherestate = "and 1=1";
        }
        if($data['shiptoname']!=""){
          $whereshiptoname = "and b.shiptoname like '%".$data['shiptoname']."%'";
        }else{
          $whereshiptoname = "and 1=1";
        }
        if($data['mrcode']!=""){
          $wheremrcode = "and c.mrid in ( ".$data['mrcode'].")";
        }else{
          $wheremrcode = "and 1=1";
        }
       $forecastlist = DB::select(DB::raw("
          select *,d.`Desc` as productgroup,a.id as recid from `master.map_territory_customer_product` a
          left join `master.view_customer` b on a.customerid = b.id
          left join `master.view_map_approver` c on a.territoryid = c.mrid
          left join `master.product_group` d on a.productgroupid = d.id
          where true
          "
          .$whereproductgroup.
          "
          "
          .$whereshiptocode.
          "
          "
          .$wherestate.
          "
          "
          .$whereshiptoname.
          "
          "
          .$wheremrcode.
          "
          ;"
       ));
       return response()->json($forecastlist);
     }

      public function saveretagging(Request $data)
      {

          $this->updatelog('Update retag sales mapping');
           $editedidarray = explode(',', $data['editedid']) ;
           $editedmridarray = explode(',', $data['editedmrid']);

           for($u = 0; $u<count($editedidarray); $u++){
             $query = DB::select(DB::raw("
             update `master.map_territory_customer_product`
             set OldTerritoryID = TerritoryID
             ,TerritoryID = ".$editedmridarray[$u]."
             ,DateModified=now(),ModifiedBy=".Auth::user()->id."
             where id = ".$editedidarray[$u].";"
             ));
        }
        return response()->json('success');

      }


    public function exportretagging(Request $data)
    {
      $this->updatelog('Export retag sales mapping');
      $fileName = 'Retagging_'.time().'.xlsx';
       Excel::store(new RetaggingExport($data['state'],$data['shiptocode'],$data['productgroupid'],$data['mrcode']), $fileName, 'public_download');
       $file_path = '/download/'.$fileName;
       $download_link = url($file_path);

       return Response()->json([
           "success" => true,
           "file" => $download_link
       ]);
     }

     public function importretagging (Request $data) {
       $this->updatelog('Import retag sales mapping');
       //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
       $excel = Excel::toArray(new RetaggingImport, $data['file'], 'public_upload');

       $sheet1 = $excel[0];
       if($sheet1[0][0]!='customerid'){
         return Response()->json([
             "success" => false,
             'errors' => 'Wrong file.'
         ]);
       }elseif(count($excel) < 2){
         return Response()->json([
             "success" => false,
             'errors' => 'Wrong file.'
         ]);
       }else{
         $sheet2 = $excel[1];
         foreach ($sheet1 as $row)
         {
           if($row[2]!=""){
             $query = DB::select(DB::raw("
                 SELECT * FROM `master.territory`
                 where Code = '".trim($row[3])."'
                 ;"
             ));
             if(count($query)!=0){
               DB::select(DB::raw("
               insert into `master.map_territory_customer_product`
               values
               (null,".$query[0]->ID.",".$row[0].",".$row[1].",".Auth::user()->id.",".Auth::user()->id.",now(),now(),0,1)
                on duplicate key update OldTerritoryID=TerritoryID, TerritoryID=".$query[0]->ID.", DateModified=now(),ModifiedBy=".Auth::user()->id.";

                   ;"
               ));
             }
            }
         }
          return Response()->json([
            "success" => true
          ]);
       }

    }



    public function fcaccuracy()
    {
      $this->updatelog('View fc accuracy');
      $this->updatelastlogin();
      if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        #$where = "and nsmuserid = ".Auth::user()->id;
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmuserid = ".Auth::user()->id;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mruserid = ".Auth::user()->id;
      }
      //drop down list
      $yearlist = DB::select(DB::raw("
          SELECT distinct year
          FROM `sales.rpt_invoice_trail`
          where true
          "
          .$where.
          "
          ;"
      ));
      $mrcodelist = DB::select(DB::raw("
          SELECT distinct mrid,mrcode,mrname
          FROM `sales.rpt_invoice_trail`
          where true
          "
          .$where.
          "
          order by mrcode,mrname
          ;"
      ));
      $flmcodelist = DB::select(DB::raw("
          SELECT distinct flmid,flmcode,flmname
          FROM `sales.rpt_invoice_trail`
          where true
          "
          .$where.
          "
          order by flmcode,flmname
          ;"
      ));
      $productgrouplist = DB::select(DB::raw("
          SELECT distinct productgroupid,productgroup
          FROM `sales.rpt_invoice_trail`
          where true
          "
          .$where.
          "
          order by productgroup
          ;"
      ));


      $currentfc = DB::select(DB::raw("
          select year,period from `sales.forecast_dtl` where lockstatus = 0 order by year,period limit 1
      ;"
      ));
        return view('fcaccuracy', ["yearlist"=>$yearlist,"mrcodelist"=>$mrcodelist,"flmcodelist"=>$flmcodelist,"productgrouplist"=>$productgrouplist,"currentfc"=>$currentfc]);
    }


   public function getfcaccuracy(Request $data)
   {

     if(Auth::user()->territorytypeid==0){
       $where = "and 1=1";
     }elseif(Auth::user()->territorytypeid==1){
       #$where = "and nsmuserid = ".Auth::user()->id;
       if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
         $where = "and nsmid in (1,2)";
       }else{
         $where = "and nsmid = ".Auth::user()->territoryid;
       }
     }elseif(Auth::user()->territorytypeid==2){
       $where = "and flmuserid = ".Auth::user()->id;
     }elseif(Auth::user()->territorytypeid==3){
       $where = "and mruserid = ".Auth::user()->id;
     }

     if($data['year']!=""){
       $whereyear = "and a.year in ( ".$data['year'].")";
     }else{
       $whereyear = "and 1=1";
     }

     if($data['mrid']!=""){
       $wheremr = "and a.mrid in ( ".$data['mrid'].")";
     }else{
       $wheremr = "and 1=1";
     }

     if($data['flmid']!=""){
       $whereflm = "and a.flmid in ( ".$data['flmid'].")";
     }else{
       $whereflm = "and 1=1";
     }

     if($data['productgroupid']!=""){
       $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
     }else{
       $whereproductgroup = "and 1=1";
     }

     $forecastlist = DB::select(DB::raw("
     select concat(a.mrid,'_',ifnull(a.productcategory,'')) as recid ,a.flmcode,a.mrcode,a.mrname,a.productcategory,a.mrid,
     sum(b.tgt1) as tgt1,
     sum(b.tgt2) as tgt2,
     sum(b.tgt3) as tgt3,
     sum(b.tgt4) as tgt4,
     sum(b.tgt5) as tgt5,
     sum(b.tgt6) as tgt6,
     sum(b.tgt7) as tgt7,
     sum(b.tgt8) as tgt8,
     sum(b.tgt9) as tgt9,
     sum(b.tgt10) as tgt10,
     sum(b.tgt11) as tgt11,
     sum(b.tgt12) as tgt12,
     sum(a.sls1) as sls1,
     sum(a.sls2) as sls2,
     sum(a.sls3) as sls3,
     sum(a.sls4) as sls4,
     sum(a.sls5) as sls5,
     sum(a.sls6) as sls6,
     sum(a.sls7) as sls7,
     sum(a.sls8) as sls8,
     sum(a.sls9) as sls9,
     sum(a.sls10) as sls10,
     sum(a.sls11) as sls11,
     sum(a.sls12) as sls12,
     (sum(b.tgt1)/sum(a.sls1)-1)*100 as month1,
     (sum(b.tgt2)/sum(a.sls2)-1)*100 as month2,
     (sum(b.tgt3)/sum(a.sls3)-1)*100 as month3,
     ((sum(b.tgt1)/sum(a.sls1)-1)+(sum(b.tgt2)/sum(a.sls2)-1)+(sum(b.tgt3)/sum(a.sls3)-1))/3*100 as fcaccuracy1,
     (sum(b.tgt4)/sum(a.sls4)-1)*100 as month4,
     (sum(b.tgt5)/sum(a.sls5)-1)*100 as month5,
     (sum(b.tgt6)/sum(a.sls6)-1)*100 as month6,
     ((sum(b.tgt4)/sum(a.sls4)-1)+(sum(b.tgt5)/sum(a.sls5)-1)+(sum(b.tgt6)/sum(a.sls6)-1))/3*100 as fcaccuracy2,
     (sum(b.tgt7)/sum(a.sls7)-1)*100 as month7,
     (sum(b.tgt8)/sum(a.sls8)-1)*100 as month8,
     (sum(b.tgt9)/sum(a.sls9)-1)*100 as month9,
     ((sum(b.tgt7)/sum(a.sls7)-1)+(sum(b.tgt8)/sum(a.sls8)-1)+(sum(b.tgt9)/sum(a.sls9)-1))/3*100 as fcaccuracy3,
     (sum(b.tgt10)/sum(a.sls10)-1)*100 as month10,
     (sum(b.tgt11)/sum(a.sls11)-1)*100 as month11,
     (sum(b.tgt12)/sum(a.sls12)-1)*100 as month12,
     ((sum(b.tgt10)/sum(a.sls10)-1)+(sum(b.tgt11)/sum(a.sls11)-1)+(sum(b.tgt12)/sum(a.sls12)-1))/3*100 as fcaccuracy4
     from
     (
        select a.period,a.flmcode,a.mrcode,a.mrname,a.productcategory,a.productgroupid,a.mrid,
        Sum(IF(a.period = '1', a.sls, 0)) AS `sls1`,
        Sum(IF(a.period = '2', a.sls, 0)) AS `sls2`,
        Sum(IF(a.period = '3', a.sls, 0)) AS `sls3`,
        Sum(IF(a.period = '4', a.sls, 0)) AS `sls4`,
        Sum(IF(a.period = '5', a.sls, 0)) AS `sls5`,
        Sum(IF(a.period = '6', a.sls, 0)) AS `sls6`,
        Sum(IF(a.period = '7', a.sls, 0)) AS `sls7`,
        Sum(IF(a.period = '8', a.sls, 0)) AS `sls8`,
        Sum(IF(a.period = '9', a.sls, 0)) AS `sls9`,
        Sum(IF(a.period = '10', a.sls, 0)) AS `sls10`,
        Sum(IF(a.period = '11', a.sls, 0)) AS `sls11`,
        Sum(IF(a.period = '12', a.sls, 0)) AS `sls12`

        from `sales.rpt_invoice_trail` a
        where true
        and a.mrid is not null
        and a.flmid is not null
        "
        .$where.
        "
        "
        .$whereyear.
        "
        "
        .$wheremr.
        "
        "
        .$whereflm.
        "
        "
        .$whereproductgroup.
        "
        group by a.period,a.flmcode,a.mrcode,a.mrname,a.productcategory,a.productgroupid,a.mrid) a
        left join (
          select a.period,flmcode,mrcode,mrname,productgroupid,mrid,
           Sum(IF(a.period = '1', a.tgt, 0)) AS `tgt1`,
           Sum(IF(a.period = '2', a.tgt, 0)) AS `tgt2`,
           Sum(IF(a.period = '3', a.tgt, 0)) AS `tgt3`,
           Sum(IF(a.period = '4', a.tgt, 0)) AS `tgt4`,
           Sum(IF(a.period = '5', a.tgt, 0)) AS `tgt5`,
           Sum(IF(a.period = '6', a.tgt, 0)) AS `tgt6`,
           Sum(IF(a.period = '7', a.tgt, 0)) AS `tgt7`,
           Sum(IF(a.period = '8', a.tgt, 0)) AS `tgt8`,
           Sum(IF(a.period = '9', a.tgt, 0)) AS `tgt9`,
           Sum(IF(a.period = '10', a.tgt, 0)) AS `tgt10`,
           Sum(IF(a.period = '11', a.tgt, 0)) AS `tgt11`,
           Sum(IF(a.period = '12', a.tgt, 0)) AS `tgt12`
          from `sales.rpt_target_trail` a
          where true
          and a.mrid is not null
          and a.flmid is not null
          "
          .$where.
          "
          "
          .$whereyear.
          "
          "
          .$wheremr.
          "
          "
          .$whereflm.
          "
          "
          .$whereproductgroup.
          "
          group by a.period,flmcode,mrcode,mrname,productgroupid,mrid
          ) b on a.mrid = b.mrid and a.productgroupid = b.productgroupid and a.period = b.period

         group by a.flmcode,a.mrcode,a.mrname,a.productcategory,a.mrid
         order by a.flmcode,a.mrcode,a.mrname,a.productcategory
         ;"
     ));
     return response()->json($forecastlist);
   }


    public function getfcaccuracy2(Request $data)
    {

      if(Auth::user()->territorytypeid==0){
        $where = "and 1=1";
      }elseif(Auth::user()->territorytypeid==1){
        #$where = "and nsmuserid = ".Auth::user()->id;
        if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
          $where = "and nsmid in (1,2)";
        }else{
          $where = "and nsmid = ".Auth::user()->territoryid;
        }
      }elseif(Auth::user()->territorytypeid==2){
        $where = "and flmuserid = ".Auth::user()->id;
      }elseif(Auth::user()->territorytypeid==3){
        $where = "and mruserid = ".Auth::user()->id;
      }

      if($data['year']!=""){
        $whereyear = "and a.year in ( ".$data['year'].")";
      }else{
        $whereyear = "and 1=1";
      }

      if($data['mrid']!=""){
        $wheremr = "and a.mrid in ( ".$data['mrid'].")";
      }else{
        $wheremr = "and 1=1";
      }

      if($data['flmid']!=""){
        $whereflm = "and a.flmid in ( ".$data['flmid'].")";
      }else{
        $whereflm = "and 1=1";
      }

      if($data['productgroupid']!=""){
        $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
      }else{
        $whereproductgroup = "and 1=1";
      }

      $forecastlist = DB::select(DB::raw("
      select concat(a.flmid,'_',ifnull(a.productcategory,'')) as recid ,a.flmcode,a.flmname,a.flmid,a.productcategory,
      sum(b.tgt1) as tgt1,
      sum(b.tgt2) as tgt2,
      sum(b.tgt3) as tgt3,
      sum(b.tgt4) as tgt4,
      sum(b.tgt5) as tgt5,
      sum(b.tgt6) as tgt6,
      sum(b.tgt7) as tgt7,
      sum(b.tgt8) as tgt8,
      sum(b.tgt9) as tgt9,
      sum(b.tgt10) as tgt10,
      sum(b.tgt11) as tgt11,
      sum(b.tgt12) as tgt12,
      sum(a.sls1) as sls1,
      sum(a.sls2) as sls2,
      sum(a.sls3) as sls3,
      sum(a.sls4) as sls4,
      sum(a.sls5) as sls5,
      sum(a.sls6) as sls6,
      sum(a.sls7) as sls7,
      sum(a.sls8) as sls8,
      sum(a.sls9) as sls9,
      sum(a.sls10) as sls10,
      sum(a.sls11) as sls11,
      sum(a.sls12) as sls12,
      (sum(b.tgt1)/sum(a.sls1)-1)*100 as month1,
      (sum(b.tgt2)/sum(a.sls2)-1)*100 as month2,
      (sum(b.tgt3)/sum(a.sls3)-1)*100 as month3,
      ((sum(b.tgt1)/sum(a.sls1)-1)+(sum(b.tgt2)/sum(a.sls2)-1)+(sum(b.tgt3)/sum(a.sls3)-1))/3*100 as fcaccuracy1,
      (sum(b.tgt4)/sum(a.sls4)-1)*100 as month4,
      (sum(b.tgt5)/sum(a.sls5)-1)*100 as month5,
      (sum(b.tgt6)/sum(a.sls6)-1)*100 as month6,
      ((sum(b.tgt4)/sum(a.sls4)-1)+(sum(b.tgt5)/sum(a.sls5)-1)+(sum(b.tgt6)/sum(a.sls6)-1))/3*100 as fcaccuracy2,
      (sum(b.tgt7)/sum(a.sls7)-1)*100 as month7,
      (sum(b.tgt8)/sum(a.sls8)-1)*100 as month8,
      (sum(b.tgt9)/sum(a.sls9)-1)*100 as month9,
      ((sum(b.tgt7)/sum(a.sls7)-1)+(sum(b.tgt8)/sum(a.sls8)-1)+(sum(b.tgt9)/sum(a.sls9)-1))/3*100 as fcaccuracy3,
      (sum(b.tgt10)/sum(a.sls10)-1)*100 as month10,
      (sum(b.tgt11)/sum(a.sls11)-1)*100 as month11,
      (sum(b.tgt12)/sum(a.sls12)-1)*100 as month12,
      ((sum(b.tgt10)/sum(a.sls10)-1)+(sum(b.tgt11)/sum(a.sls11)-1)+(sum(b.tgt12)/sum(a.sls12)-1))/3*100 as fcaccuracy4
      from
      (
         select a.period,a.flmcode,a.flmname,a.productgroupid,a.flmid,a.productcategory,
         Sum(IF(a.period = '1', a.sls, 0)) AS `sls1`,
         Sum(IF(a.period = '2', a.sls, 0)) AS `sls2`,
         Sum(IF(a.period = '3', a.sls, 0)) AS `sls3`,
         Sum(IF(a.period = '4', a.sls, 0)) AS `sls4`,
         Sum(IF(a.period = '5', a.sls, 0)) AS `sls5`,
         Sum(IF(a.period = '6', a.sls, 0)) AS `sls6`,
         Sum(IF(a.period = '7', a.sls, 0)) AS `sls7`,
         Sum(IF(a.period = '8', a.sls, 0)) AS `sls8`,
         Sum(IF(a.period = '9', a.sls, 0)) AS `sls9`,
         Sum(IF(a.period = '10', a.sls, 0)) AS `sls10`,
         Sum(IF(a.period = '11', a.sls, 0)) AS `sls11`,
         Sum(IF(a.period = '12', a.sls, 0)) AS `sls12`

         from `sales.rpt_invoice_trail` a
         where true
         and a.flmid is not null
         "
         .$where.
         "
         "
         .$whereyear.
         "
         "
         .$wheremr.
         "
         "
         .$whereflm.
         "
         "
         .$whereproductgroup.
         "
         group by a.period,a.flmcode,a.flmname,a.productgroupid,a.productcategory,a.flmid) a
         left join (
           select a.period,flmcode,flmname,productgroupid,a.flmid,
            Sum(IF(a.period = '1', a.tgt, 0)) AS `tgt1`,
            Sum(IF(a.period = '2', a.tgt, 0)) AS `tgt2`,
            Sum(IF(a.period = '3', a.tgt, 0)) AS `tgt3`,
            Sum(IF(a.period = '4', a.tgt, 0)) AS `tgt4`,
            Sum(IF(a.period = '5', a.tgt, 0)) AS `tgt5`,
            Sum(IF(a.period = '6', a.tgt, 0)) AS `tgt6`,
            Sum(IF(a.period = '7', a.tgt, 0)) AS `tgt7`,
            Sum(IF(a.period = '8', a.tgt, 0)) AS `tgt8`,
            Sum(IF(a.period = '9', a.tgt, 0)) AS `tgt9`,
            Sum(IF(a.period = '10', a.tgt, 0)) AS `tgt10`,
            Sum(IF(a.period = '11', a.tgt, 0)) AS `tgt11`,
            Sum(IF(a.period = '12', a.tgt, 0)) AS `tgt12`
           from `sales.rpt_target_trail` a
           where true
           and a.flmid is not null
           "
           .$where.
           "
           "
           .$whereyear.
           "
           "
           .$wheremr.
           "
           "
           .$whereflm.
           "
           "
           .$whereproductgroup.
           "
           group by a.period,flmcode,flmname,productgroupid,a.flmid
           ) b on a.flmid = b.flmid and a.productgroupid = b.productgroupid and a.period = b.period

          group by a.flmcode,a.flmname,a.flmid,a.productcategory
          order by a.flmcode,a.productcategory
          ;"
      ));
      return response()->json($forecastlist);
    }
   public function getfcaccuracychart(Request $data)
   {

          if(Auth::user()->territorytypeid==0){
            $where = "and 1=1";
          }elseif(Auth::user()->territorytypeid==1){
            #$where = "and nsmuserid = ".Auth::user()->id;
            if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
              $where = "and nsmid in (1,2)";
            }else{
              $where = "and nsmid = ".Auth::user()->territoryid;
            }
          }elseif(Auth::user()->territorytypeid==2){
            $where = "and flmuserid = ".Auth::user()->id;
          }elseif(Auth::user()->territorytypeid==3){
            $where = "and mruserid = ".Auth::user()->id;
          }

          if($data['year']!=""){
            $whereyear = "and a.year in ( ".$data['year'].")";
          }else{
            $whereyear = "and 1=1";
          }

          if($data['mrid']!=""){
            $wheremr = "and a.mrid in ( ".$data['mrid'].")";
          }else{
            $wheremr = "and 1=1";
          }

          if($data['flmid']!=""){
            $whereflm = "and a.flmid in ( ".$data['flmid'].")";
          }else{
            $whereflm = "and 1=1";
          }

          if($data['productgroupid']!=""){
            $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
          }else{
            $whereproductgroup = "and 1=1";
          }

          $query = DB::select(DB::raw("
          select a.flmcode,a.flmid,
          (sum(b.tgt1)/sum(a.sls1)-1)*100 as month1,
          (sum(b.tgt2)/sum(a.sls2)-1)*100 as month2,
          (sum(b.tgt3)/sum(a.sls3)-1)*100 as month3,
          (sum(b.tgt4)/sum(a.sls4)-1)*100 as month4,
          (sum(b.tgt5)/sum(a.sls5)-1)*100 as month5,
          (sum(b.tgt6)/sum(a.sls6)-1)*100 as month6,
          (sum(b.tgt7)/sum(a.sls7)-1)*100 as month7,
          (sum(b.tgt8)/sum(a.sls8)-1)*100 as month8,
          (sum(b.tgt9)/sum(a.sls9)-1)*100 as month9,
          (sum(b.tgt10)/sum(a.sls10)-1)*100 as month10,
          (sum(b.tgt11)/sum(a.sls11)-1)*100 as month11,
          (sum(b.tgt12)/sum(a.sls12)-1)*100 as month12
          from
          (
             select a.period,a.flmcode,a.mrcode,a.mrname,a.productcategory,a.productgroupid,a.mrid,flmid,
             Sum(IF(a.period = '1', a.sls, 0)) AS `sls1`,
             Sum(IF(a.period = '2', a.sls, 0)) AS `sls2`,
             Sum(IF(a.period = '3', a.sls, 0)) AS `sls3`,
             Sum(IF(a.period = '4', a.sls, 0)) AS `sls4`,
             Sum(IF(a.period = '5', a.sls, 0)) AS `sls5`,
             Sum(IF(a.period = '6', a.sls, 0)) AS `sls6`,
             Sum(IF(a.period = '7', a.sls, 0)) AS `sls7`,
             Sum(IF(a.period = '8', a.sls, 0)) AS `sls8`,
             Sum(IF(a.period = '9', a.sls, 0)) AS `sls9`,
             Sum(IF(a.period = '10', a.sls, 0)) AS `sls10`,
             Sum(IF(a.period = '11', a.sls, 0)) AS `sls11`,
             Sum(IF(a.period = '12', a.sls, 0)) AS `sls12`

             from `sales.rpt_invoice_trail` a
             where true
             and a.flmcode is not null
             "
             .$where.
             "
             "
             .$whereyear.
             "
             "
             .$wheremr.
             "
             "
             .$whereflm.
             "
             "
             .$whereproductgroup.
             "
             group by a.period,a.flmcode,a.mrcode,a.mrname,a.productcategory,a.productgroupid,a.mrid,flmid) a
             left join (
               select a.period,flmcode,mrcode,mrname,productgroupid,mrid,flmid,

               Sum(IF(a.period = '1', a.tgt, 0)) AS `tgt1`,
               Sum(IF(a.period = '2', a.tgt, 0)) AS `tgt2`,
               Sum(IF(a.period = '3', a.tgt, 0)) AS `tgt3`,
               Sum(IF(a.period = '4', a.tgt, 0)) AS `tgt4`,
               Sum(IF(a.period = '5', a.tgt, 0)) AS `tgt5`,
               Sum(IF(a.period = '6', a.tgt, 0)) AS `tgt6`,
               Sum(IF(a.period = '7', a.tgt, 0)) AS `tgt7`,
               Sum(IF(a.period = '8', a.tgt, 0)) AS `tgt8`,
               Sum(IF(a.period = '9', a.tgt, 0)) AS `tgt9`,
               Sum(IF(a.period = '10', a.tgt, 0)) AS `tgt10`,
               Sum(IF(a.period = '11', a.tgt, 0)) AS `tgt11`,
               Sum(IF(a.period = '12', a.tgt, 0)) AS `tgt12`
               from `sales.rpt_target_trail` a
               where true
               and a.flmcode is not null
               "
               .$where.
               "
               "
               .$whereyear.
               "
               "
               .$wheremr.
               "
               "
               .$whereflm.
               "
               "
               .$whereproductgroup.
               "
               group by a.period,flmcode,mrcode,mrname,productgroupid,mrid,flmid
               ) b on a.mrid = b.mrid and a.productgroupid = b.productgroupid and a.period = b.period

              group by a.flmcode,a.flmid
              order by a.flmcode
              ;"
          ));
      $counter1 = 0;
      $teamarray = array();
      $fcarray = array();
      $fcarray2 = array();
      foreach($query as $key => $val){
        //var_dump($val);
          $teamarray[$counter1]=$val->flmcode;

          $fcarray[0] = number_format((float)$val->month1, 1, '.', '');
          $fcarray[1] = number_format((float)$val->month2, 1, '.', '');
          $fcarray[2] = number_format((float)$val->month3, 1, '.', '');
          $fcarray[3] = number_format((float)$val->month4, 1, '.', '');
          $fcarray[4] = number_format((float)$val->month5, 1, '.', '');
          $fcarray[5] = number_format((float)$val->month6, 1, '.', '');
          $fcarray[6] = number_format((float)$val->month7, 1, '.', '');
          $fcarray[7] = number_format((float)$val->month8, 1, '.', '');
          $fcarray[8] = number_format((float)$val->month9, 1, '.', '');
          $fcarray[9] = number_format((float)$val->month10, 1, '.', '');
          $fcarray[10] = number_format((float)$val->month11, 1, '.', '');
          $fcarray[11] = number_format((float)$val->month12, 1, '.', '');
          $fcarray2[$counter1] = json_encode($fcarray);

          $counter1 = $counter1 + 1;
      }
      $data2['team'] = $teamarray;
      $data2['fc'] = $fcarray2;
      $data2['counter'] = $counter1;
      return response()->json($data2);
   }

   public function exportfcaccuracy(Request $data)
   {
     $this->updatelog('Export fc accuracy');
     $fileName = 'FC_Accuuracy_'.time().'.xlsx';
      Excel::store(new FCAccuracyExport($data['year']), $fileName, 'public_download');
      $file_path = '/download/'.$fileName;
      $download_link = url($file_path);

      return Response()->json([
          "success" => true,
          "file" => $download_link
      ]);
    }
    /*public function dailyinvoice(Request $data)
    {
      $this->updatelog('View daily invoice');
      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and teamid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==1){
          $where = "and territoryid = ".Auth::user()->territoryid;
        }

        $targettablename = "`sales.rpt_target_trail`";
        //drop down list
        $periodlist = array();

        $year = date('Y')-2;
        for($i=0; $i<3; $i++) {
          $yearlist[$i] = (object) array('year' => $year);
          $year++;
        }

        for($i=0; $i<12; $i++) {
          $periodlist[$i] = (object) array('period' => $i+1);
        }
        $mrcodelist = DB::select(DB::raw("
            SELECT distinct mrid,mrcode,mrname
            FROM `master.view_map_approver`
            where true
            "
            .$where.
            "
            order by mrcode,mrname
            ;"
        ));

        $flmcodelist = DB::select(DB::raw("
            SELECT distinct flmid,flmcode,flmname
            FROM `master.view_map_approver`
            where true
            "
            .$where.
            "
            order by flmcode,flmname
            ;"
        ));
        $productgrouplist = DB::select(DB::raw("
            SELECT id as  productgroupid,`Desc` as productgroup
            FROM `master.product_group`
            where true
            order by `Desc`
            ;"
        ));

        $channellist = DB::select(DB::raw("
            SELECT id as channelid,channel
            FROM `master.channel`
            where true
            ;"
        ));
       $bulist = DB::select(DB::raw("
           SELECT id as  buid,bu
           FROM `master.bu`
           where true
           ;"
       ));
      $sourcelist = DB::select(DB::raw("
         SELECT id as sourceid,Code as datasource
         FROM `master.datasource`
         where true
         ;"
      ));

       return view('dailyinvoice', ["yearlist"=>$yearlist,"periodlist"=>$periodlist,"bulist"=>$bulist,"sourcelist"=>$sourcelist,"mrcodelist"=>$mrcodelist,"flmcodelist"=>$flmcodelist,"productgrouplist"=>$productgrouplist,"channellist"=>$channellist]);
      }

      public function getdailyinvoice(Request $data)
      {

          if(Auth::user()->territorytypeid==0){
              $where = "and 1=1";
            }elseif(Auth::user()->territorytypeid==2){
              $where = "and teamid = ".Auth::user()->territoryid;
            }elseif(Auth::user()->territorytypeid==1){
              if(Auth::user()->territoryid==0 and Auth::user()->teamid==0){
                $where = "and 1=1";
              }else{
                $where = "and territoryid = ".Auth::user()->territoryid;
              }
            }
            $data['lyyear'] = $data['year']-1;
            if($data['year']!=""){
              $whereyear = "and a.year in ( ".$data['year'].")";
              $whereyear2 = "and a.year in ( ".$data['lyyear'].")";
            }else{
              $whereyear = "and 1=1";
              $whereyear2 = "and 1=1";
            }
            if($data['period']!=""){
              $whereperiod = "and a.period in ( ".$data['period'].")";
              $whereperiod2 = "and a.period <= ".$data['period']."";
            }else{
              $whereperiod = "and 1=1";
              $whereperiod2 = "and 1=1";
            }

           if($data['mrid']!=""){
             $wheremr = "and a.territoryid in ( ".$data['mrid'].")";
           }else{
             $wheremr = "and 1=1";
           }

           if($data['flmid']!=""){
             $whereflm = "and a.teamid in ( ".$data['flmid'].")";
           }else{
             $whereflm = "and 1=1";
           }

           if($data['productgroupid']!=""){
             $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
           }else{
             $whereproductgroup = "and 1=1";
           }

          if($data['channelid']!=""){
            $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
          }else{
            $wherechannel = "and 1=1";
          }

          if($data['tagging']==1){
            $invoicelist = DB::select(DB::raw("
             select *,invid as recid From`sales.rpt_invoice_trail` a
                where true
                and a.ffyear in (select max(year) as year from `sales.invoice`)
                ".$where."
                "
                .$whereyear.
                "
                "
                .$whereperiod.
                "
                "
                .$wheremr.
                "
                "
                .$whereflm.
                "
                "
                .$whereproductgroup.
                "
                "
                .$wherechannel.
                "
                order by invoicedate
                ;"
            ));
          }else{
            $invoicelist = DB::select(DB::raw("

             select *,invid as recid 	 From
                     (select * from `sales.view_invoice_dtl` a
                     where true
                     ".$where."
                     "
                     .$whereyear.
                     "
                     "
                     .$whereperiod.
                     "
                     "
                     .$wheremr.
                     "
                     "
                     .$whereflm.
                     "
                     "
                     .$whereproductgroup.
                     "
                     "
                     .$wherechannel.
                     ")
                      a
                where true

                order by invoicedate
            ;"));
          }

        return response()->json($invoicelist);
      }

      public function exportdailyinvoice(Request $data)
      {
        $this->updatelog('Export daily invoice');
        $fileName = 'Daily_Invoice_'.time().'.xlsx';
        if(Auth::user()->territorytypeid==0){
            $where = "and 1=1";
          }elseif(Auth::user()->territorytypeid==2){
            $where = "and teamid = ".Auth::user()->territoryid;
          }elseif(Auth::user()->territorytypeid==1){
            if(Auth::user()->territoryid==0 and Auth::user()->teamid==0){
              $where = "and 1=1";
            }else{
              $where = "and territoryid = ".Auth::user()->territoryid;
            }
          }
          if($data['year']!=""){
            $whereyear = "and a.year in ( ".$data['year'].")";
          }else{
            $whereyear = "and 1=1";
          }
          if($data['period']!=""){
            $whereperiod = "and a.period in ( ".$data['period'].")";
          }else{
            $whereperiod = "and 1=1";
          }

         if($data['mrid']!=""){
           $wheremr = "and a.territoryid in ( ".$data['mrid'].")";
         }else{
           $wheremr = "and 1=1";
         }

         if($data['flmid']!=""){
           $whereflm = "and a.teamid in ( ".$data['flmid'].")";
         }else{
           $whereflm = "and 1=1";
         }

         if($data['productgroupid']!=""){
           $whereproductgroup = "and a.productgroupid in ( ".$data['productgroupid'].")";
         }else{
           $whereproductgroup = "and 1=1";
         }

        if($data['channelid']!=""){
          $wherechannel = "and a.channelid in ( ".$data['channelid'].")";
        }else{
          $wherechannel = "and 1=1";
        }
        if($data['tagging']==1){
          $invoicelist = DB::select(DB::raw("
           select  year	as Year,
                   period	as Period,
                   invoicedate	,
                   invoiceno	,
                   shiptocode	,
                   shiptoname	,
                   address1	,
                   address2	,
                   address3	,
                   state	,
                   postalcode	,
                   imsgroup1	,
                   imsgroup2	,
                   localgroup3	,
                   channel	,
                   productgroup	,
                   productcode	,
                   productdesc	,
                   qty	,
                   foc	,
                   salesvalue	,
                   teamcode	,
                   sm	,
                   territorycode	,
                   salesrep
                   From`sales.rpt_invoice_trail` a
              where true
              and a.ffyear in (select max(year) as year from `sales.invoice`)
              ".$where."
              "
              .$whereyear.
              "
              "
              .$whereperiod.
              "
              "
              .$wheremr.
              "
              "
              .$whereflm.
              "
              "
              .$whereproductgroup.
              "
              "
              .$wherechannel.
              "
              order by invoicedate
          ;"));
        }else{
          $invoicelist = DB::select(DB::raw("
           select
           year	,
                   period	,
                   invoicedate	,
                   invoiceno	,
                   shiptocode	,
                   shiptoname	,
                   address1	,
                   address2	,
                   address3	,
                   state	,
                   postalcode	,
                   imsgroup1	,
                   imsgroup2	,
                   localgroup3	,
                   channel	,
                   productgroup	,
                   productcode	,
                   productdesc	,
                   qty	,
                   foc	,
                   salesvalue	,
                   teamcode	,
                   sm	,
                   territorycode	,
                   salesrep
                   From
                   (select * from `sales.view_invoice_dtl` a
                   where true
                   ".$where."
                   "
                   .$whereyear.
                   "
                   "
                   .$whereperiod.
                   "
                   "
                   .$wheremr.
                   "
                   "
                   .$whereflm.
                   "
                   "
                   .$whereproductgroup.
                   "
                   "
                   .$wherechannel.
                   ")
                    a
              where true

              order by invoicedate
          ;"));
        }
         //Excel::store(new DailyInvoiceExport($data['year'],$data['period'],$data['mrid'],$data['flmid'],$data['productgroupid'],$data['channelid'],$data['buid'],$data['subchannel2id'],$data['sourceid']), $fileName, 'public_download');
         $list = collect($invoicelist);

        (new FastExcel($list))->export($fileName);
         $file_path = $fileName;
         //$file_path = '/download'.$fileName;
         $download_link = url($file_path);

         return Response()->json([
             "success" => true,
             "file" => $download_link
         ]);
      }*/

       public function sharing()
       {
       $this->updatelog('View sharing distribution');
         $data = DB::select(DB::raw("

           select a.id as recid,a.mrcode as mastercode,
           CASE
             WHEN b.type = 1 THEN 'Mirror'
             WHEN b.type = 2 THEN 'Sharing'
             ELSE ''
           END as type
           from
           `master.territory` a
           left join (select distinct masterid,type from `master.map_sharing_distribution`) b on a.id = b.masterid
           where true
           and a.shared = 1
         ;"
         ));

         $mrlist = DB::select(DB::raw("
           SELECT *,mrid as recid
           FROM `master.view_map_approver`
           where true
           ;"
         ));
         return view('sharing', ["jsondata"=>json_encode($data),"jsondata2"=>json_encode($mrlist)]);
       }


      public function getsharing(Request $data)
      {

        if($data['mrid']!=""){
          $wheremrid = "and a.masterid = '".$data['mrid']."'";
        }else{
          $wheremrid = "and 1=1";
        }
        $data = DB::select(DB::raw("
          select a.mrid as recid,b.mrcode,c.mrname,a.distribution,a.seq,a.id as refid from
          `master.map_sharing_distribution` a
          left join `master.territoryr` b on a.mrid = b.id
          left join `master.view_map_approver` c on a.mrid = c.mrid
          where true
          ".$wheremrid."
        ;"
        ));
        return response()->json($data);
      }


      public function deleteshareitem(Request $data)
      {

        $this->updatelog('Delete sharing distribution');
        if($data['id']!=""){
          $whereid = "and id = '".$data['id']."'";
        }else{
          $whereid = "and 1=1";
        }
        $data = DB::select(DB::raw("
          delete from `master.map_sharing_distribution`
          where true
          ".$whereid."
        ;"
        ));
        return response()->json($data);
      }


      public function getsharingmaster()
      {
        $data = DB::select(DB::raw("
          select a.id as recid,a.mrcode as mastercode,
          CASE
            WHEN b.type = 1 THEN 'Mirror'
            WHEN b.type = 2 THEN 'Sharing'
            ELSE ''
          END as type
          from
          `master.territory` a
          left join (select distinct masterid,type from `master.map_sharing_distribution`) b on a.id = b.masterid
          where true
        ;"
        ));
        return response()->json($data);
      }

      public function savesharing(Request $data)
      {
        $this->updatelog('Update sharing distribution');
        $masterid = $data['masterid'];
        $mrid = $data['mrid'];
        $distribution = $data['distribution'];
        $toolbartype = $data['toolbartype'];
        $toolbarseq = $data['toolbarseq'];

        $check = DB::select(DB::raw("
          select * from `master.map_sharing_distribution`
          where  masterid = '".$masterid."'
          and mrid = ".$mrid."
          and type = ".$toolbartype."
          ;"
        ));
        if(count($check)> 0){
          $query = DB::select(DB::raw("
            update `master.map_sharing_distribution`
            set distribution = '".$distribution."',
            seq = '".$toolbarseq."'
            where  masterid = '".$masterid."'
            and mrid = ".$mrid."
            and type = ".$toolbartype."
            ;"
          ));
        }else{
          $query = DB::select(DB::raw("
            insert into `master.map_sharing_distribution` values (null,'".$masterid."','".$mrid."','".$distribution."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1,'".$toolbarseq."','".$toolbartype."')
            ;"
          ));
        }
        return response()->json('success');
      }

      public function savesharingmaster(Request $data)
      {
        $this->updatelog('Update sharing distribution');
        $mastercode = $data['mastercode'];

        $check = DB::select(DB::raw("
          select * from `master.territory_mr`
          where  mrcode = '".$mastercode."'
          ;"
        ));
        $query = DB::select(DB::raw("
          insert into `master.territory_mr`
          values
          (null,0,0,'".$mastercode."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1,1,0,0,0);"
        ));

        return response()->json('success');
      }



       public function productgroup()
       {
         $this->updatelastlogin();
         $this->updatelog('View product group');
         //drop down list
         $therapeuticoptionlist = DB::select(DB::raw("
             SELECT id ,therapeutic as text
             FROM `master.therapeutic`
             where true
             ;"
         ));
         $buoptionlist = DB::select(DB::raw("
             SELECT id ,bu as text
             FROM `master.bu`
             where true
             ;"
         ));
         $productcategoryoptionlist = DB::select(DB::raw("
             SELECT id ,productcategory as text
             FROM `master.product_category`
             where true
             ;"
         ));
         return view('productgroup', ["productlist"=>[],"therapeuticoptionlist"=>$therapeuticoptionlist,"productcategoryoptionlist"=>$productcategoryoptionlist,"buoptionlist"=>$buoptionlist]);
       }


      public function getproductgroup(Request $data)
      {
        if($data['productgroup']!=""){
          $whereproductgroup = "and a.productgroup like '%".$data['productgroup']."%'";
        }else{
          $whereproductgroup = "and 1=1";
        }

        if($data['productcategory']!=""){
          $whereproductcategory = "and a.productcategoryid in (".$data['productcategory'].")";
        }else{
          $whereproductcategory = "and 1=1";
        }

        if($data['therapeutic']!=""){
          $wheretherapeutic = "and a.therapeuticid in (".$data['therapeutic'].")";
        }else{
          $wheretherapeutic = "and 1=1";
        }

        if($data['bu']!=""){
          $wherebu = "and a.buid in (".$data['bu'].")";
        }else{
          $wherebu = "and 1=1";
        }
        if($data['mkt']!=""){
          $wheremkt = "and a.mkt in (".$data['mkt'].")";
        }else{
          $wheremkt = "and 1=1";
        }


        $productlist = DB::select(DB::raw("
          select a.*,a.id as recid,b.productcategory,c.therapeutic,d.bu,if(a.mkt=1,'Yes','No') as mktdesc,a.id as productgroupid from `master.product_group` a
          left join `master.product_category` b on a.productcategoryid = b.id
          left join `master.therapeutic` c on a.therapeuticid = c.id
          left join `master.bu` d on a.buid = d.id
          where true
          "
          .$whereproductgroup.
          "
          "
          .$wherebu.
          "
          "
          .$wheremkt.
          "
          "
          .$wheretherapeutic.
          "
          "
          .$whereproductcategory.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function saveproductgroup(Request $data)
      {
        $this->updatelog('Update product group');
        if($data['productgroupid']!=""){
          $query = DB::select(DB::raw("
            update `master.product_group`
            set productgroup = '".$data['productgroup']."',
            productcategoryid = '".$data['productcategoryid']."',
            therapeuticid = '".$data['therapeuticid']."',
            buid = '".$data['buid']."',
            mkt = '".$data['mkt']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['productgroupid']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.product_group`
       			VALUES
       			(null, '".$data['buid']."', '".$data['therapeuticid']."', '".$data['productcategoryid']."', '".$data['productgroup']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(), '".$data['mkt']."',1)
       		;"
       		));
        }
        return response()->json('success');
      }

       public function salesline()
       {
         $this->updatelastlogin();

         $this->updatelog('View sales line');
         return view('salesline', ["productlist"=>[]]);
       }


      public function getsalesline(Request $data)
      {
        if($data['salesline']!=""){
          $wheresalesline = "and a.salesline like '%".$data['salesline']."%'";
        }else{
          $wheresalesline = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.salesline` a
          where true
          "
          .$wheresalesline.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function savesalesline(Request $data)
      {
        $this->updatelog('Update sales line');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.salesline`
            set salesline = '".$data['salesline']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.salesline`
       			VALUES
       			(null,'".$data['salesline']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1)
       		;"
       		));
        }
        return response()->json('success');
      }



       public function nsm()
       {
         $this->updatelastlogin();

         $this->updatelog('View NSM');
         return view('nsm', ["productlist"=>[]]);
       }


      public function getnsm(Request $data)
      {
        if($data['nsmcode']!=""){
          $wherensm = "and a.nsmcode like '%".$data['nsmcode']."%'";
        }else{
          $wherensm = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.territory_nsm` a
          where true
          "
          .$wherensm.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function savensm(Request $data)
      {
        $this->updatelog('Update NSM');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.territory_nsm`
            set nsmcode = '".$data['nsmcode']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.territory_nsm`
       			VALUES
       			(null,'".$data['nsmcode']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1)
       		;"
       		));
        }
        return response()->json('success');
      }



       public function flm()
       {
         $this->updatelog('View FLM');
         $this->updatelastlogin();

         return view('flm', ["productlist"=>[]]);
       }


      public function getflm(Request $data)
      {
        if($data['flmcode']!=""){
          $whereflm = "and a.flmcode like '%".$data['flmcode']."%'";
        }else{
          $whereflm = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.team_territory` a
          where true
          "
          .$whereflm.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function saveflm(Request $data)
      {
        $this->updatelog('Update FLM');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.team_territory`
            set code = '".$data['flmcode']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.team_territory`
       			VALUES
       			(null,null,0,0,'".$data['flmcode']."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."',null,1,null)
       		;"
       		));
        }
        return response()->json('success');
      }


       public function mr()
       {
         $this->updatelastlogin();

         $this->updatelog('View MR');
         $nsmoptionlist = DB::select(DB::raw("
             SELECT id ,code as text
             FROM `master.team_territory`
             where true
             ;"
         ));
         return view('mr', ["productlist"=>[],"flmoptionlist"=>$nsmoptionlist]);
       }


      public function getmr(Request $data)
      {
        if($data['mrcode']!=""){
          $wheremr = "and a.code like '%".$data['mrcode']."%'";
        }else{
          $wheremr = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.territory` a
          where true
          "
          .$wheremr.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function savemr(Request $data)
      {
        $this->updatelog('Update MR');
        if($data['shared']=="true"){
          $shared = 1;
        }else{
          $shared = 0;
        }
        if($data['ka']=="true"){
          $ka = 1;
        }else{
          $ka = 0;
        }
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.territory`
            set code = '".$data['mrcode']."',
            teamid = '".$data['flmid']."',
            shared = '".$shared."',
            ka = '".$ka."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.territory_mr`
       			VALUES
       			(null,'".$data['flmid']."','".$data['mrcode']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1,'".$shared."',0,'".$ka."')
       		;"
       		));
        }
        return response()->json('success');
      }


       public function therapeutic()
       {
         $this->updatelastlogin();
         $this->updatelog('View therapeutic');

         return view('therapeutic', ["productlist"=>[]]);
       }


      public function gettherapeutic(Request $data)
      {
        if($data['therapeutic']!=""){
          $wheretherapeutic = "and a.therapeutic like '%".$data['therapeutic']."%'";
        }else{
          $wheretherapeutic = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.therapeutic` a
          where true
          "
          .$wheretherapeutic.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function savetherapeutic(Request $data)
      {
        $this->updatelog('Update therapeutic');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.therapeutic`
            set therapeutic = '".$data['therapeutic']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.therapeutic`
       			VALUES
       			(null,'".$data['therapeutic']."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1)
       		;"
       		));
        }
        return response()->json('success');
      }



       public function producttier()
       {
         $this->updatelastlogin();
         $this->updatelog('View product tier');

         return view('producttier', ["productlist"=>[]]);
       }


      public function getproducttier(Request $data)
      {
        if($data['producttier']!=""){
          $whereproducttier = "and a.producttier like '%".$data['producttier']."%'";
        }else{
          $whereproducttier = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.product_tier` a
          where true
          "
          .$whereproducttier.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function saveproducttier(Request $data)
      {
        $this->updatelog('Update product tier');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.product_tier`
            set producttier = '".$data['producttier']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.product_tier`
       			VALUES
       			(null,'".$data['producttier']."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1)
       		;"
       		));
        }
        return response()->json('success');
      }



       public function productcategory()
       {
         $this->updatelastlogin();

         $this->updatelog('View product category');
         return view('productcategory', ["productlist"=>[]]);
       }


      public function getproductcategory(Request $data)
      {
        if($data['productcategory']!=""){
          $whereproductcategory = "and a.productcategory like '%".$data['productcategory']."%'";
        }else{
          $whereproductcategory = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.product_category` a
          where true
          "
          .$whereproductcategory.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function saveproductcategory(Request $data)
      {
        $this->updatelog('Update product category');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.product_category`
            set productcategory = '".$data['productcategory']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.product_category`
       			VALUES
       			(null,'".$data['productcategory']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1)
       		;"
       		));
        }
        return response()->json('success');
      }


       public function mapsaleslineproduct()
       {
         $this->updatelog('View map sales line product');
         $this->updatelastlogin();

        $saleslineoptionlist = DB::select(DB::raw("
            SELECT id ,salesline as text
            FROM `master.salesline`
            where true
            ;"
        ));
        $productgroupoptionlist = DB::select(DB::raw("
            SELECT id ,productgroup as text
            FROM `master.product_group`
            where true
            ;"
        ));
        $productcategoryoptionlist = DB::select(DB::raw("
            SELECT id ,productcategory as text
            FROM `master.product_category`
            where true
            ;"
        ));
         return view('mapsaleslineproduct', ["productlist"=>[],"saleslineoptionlist"=>$saleslineoptionlist,"productgroupoptionlist"=>$productgroupoptionlist,"productcategoryoptionlist"=>$productcategoryoptionlist]);
       }


      public function getmapsaleslineproduct(Request $data)
      {
        if($data['salesline']!=""){
          $wheremapsaleslineproduct = "and a.salesline like '%".$data['salesline']."%'";
        }else{
          $wheremapsaleslineproduct = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.view_map_salesline_product` a
          where true
          "
          .$wheremapsaleslineproduct.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function savemapsaleslineproduct(Request $data)
      {
        $this->updatelog('Update map sales line product');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.map_salesline_product`
            set saleslineid = '".$data['saleslineid']."',
            productcategoryid = '".$data['productcategoryid']."',
            productgroupid = '".$data['productgroupid']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.map_salesline_product`
       			VALUES
       			(null,'".$data['saleslineid']."','".$data['productcategoryid']."','".$data['productgroupid']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1)
       		;"
       		));
        }
        return response()->json('success');
      }

      public function mapproducttier()
       {
         $this->updatelastlogin();

         $this->updatelog('View map product tier');
        $tiergroupoptionlist = DB::select(DB::raw("
            SELECT distinct tiergroup as id,tiergroup as text FROM `master.map_product_tier` order by tiergroup;
            ;"
        ));
        $productgroupoptionlist = DB::select(DB::raw("
            SELECT id ,productgroup as text
            FROM `master.product_group`
            where true
            ;"
        ));
        $producttieroptionlist = DB::select(DB::raw("
            SELECT id ,producttier as text
            FROM `master.product_tier`
            where true
            ;"
        ));
         return view('mapproducttier', ["productlist"=>[],"tiergroupoptionlist"=>$tiergroupoptionlist,"productgroupoptionlist"=>$productgroupoptionlist,"producttieroptionlist"=>$producttieroptionlist]);
       }


      public function getmapproducttier(Request $data)
      {
        if($data['salesline']!=""){
          $wheremapproducttier = "and a.salesline like '%".$data['salesline']."%'";
        }else{
          $wheremapproducttier = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.view_map_product_tier` a
          where true
          "
          .$wheremapproducttier.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function savemapproducttier(Request $data)
      {
        $this->updatelog('Update map product tier');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.map_product_tier`
            set producttierid = '".$data['producttierid']."',
            tiergroup = '".$data['tiergroup']."',
            productgroupid = '".$data['productgroupid']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.map_product_tier`
       			VALUES
       			(null,'".$data['producttierid']."','".$data['tiergroup']."','".$data['productgroupid']."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."',1)
       		;"
       		));
        }
        return response()->json('success');
      }




       public function productpricing()
       {
          $this->updatelastlogin();

          $this->updatelog('View product pricing');
          $datasourceoptionlist = DB::select(DB::raw("
             SELECT id ,datasource as text
             FROM `master.datasource`
             where true
             ;"
          ));
          $productoptionlist = DB::select(DB::raw("
            SELECT id ,concat(code,' - ',product) as text
            FROM `master.product`
            where true
            ;"
          ));
          return view('productpricing', ["productlist"=>[],"datasourceoptionlist"=>$datasourceoptionlist,"productoptionlist"=>$productoptionlist]);
       }


      public function getproductpricing(Request $data)
      {
        if($data['productcode']!=""){
          $whereproductcode = "and a.code like '%".$data['productcode']."%'";
        }else{
          $whereproductcode = "and 1=1";
        }
        if($data['product']!=""){
          $whereproduct = "and a.product like '%".$data['product']."%'";
        }else{
          $whereproduct = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.view_product_pricing` a
          where true
          "
          .$whereproductcode.
          "
          "
          .$whereproduct.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function saveproductpricing(Request $data)
      {

        $this->updatelog('Update product pricing');
        if($data['effectivedate']!=""){
          $effectivedate = date("Y-m-d",strtotime(str_replace('/', '-', $data['effectivedate'])));
        }else{
          $effectivedate = "";
        }
        if($data['expirydate']!=""){
          $expirydate = date("Y-m-d",strtotime(str_replace('/', '-', $data['expirydate'])));
        }else{
          $expirydate = "";
        }

        $check = DB::select(DB::raw("
          SELECT * FROM `master.product_pricing`
          where productid = '".$data['productid']."' and sourceid = '".$data['sourceid']."' and effectivedate <= '".$effectivedate."' and expirydate is null;"
        ));
        if(count($check)>0){
          $expdate = date('Y-m-d', strtotime($effectivedate . ' -1 day'));
          $query = DB::select(DB::raw("
              update `master.product_pricing`
              set expirydate = '".$expdate."'
              where id = '".$check[0]->id."';
              ;"
          ));
        }
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.product_pricing`
            set minqty = '".$data['minqty']."',
            maxqty = '".$data['maxqty']."',
            unitprice = '".$data['unitprice']."',
            productid = '".$data['productid']."',
            sourceid = '".$data['sourceid']."',
            effectivedate = nullif('".$effectivedate."',''),
            expirydate = nullif('".$expirydate."',''),
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
       			insert into `master.product_pricing`
       			VALUES
       			(null,'".$data['productid']."','".$data['sourceid']."','".$data['minqty']."','".$data['maxqty']."','".$data['unitprice']."',nullif('".$effectivedate."',''),nullif('".$expirydate."',''),now(),now(),'".Auth::user()->id."','".Auth::user()->id."')
       		;"
       		));
        }
        return response()->json('success');
      }



      public function accesslog(Request $data)
      {
        $this->updatelog('View access log');

        $userlist = DB::select(DB::raw("
          select * From `master_user` a
          where true
          and status = 1
          order by username
        ;"));

       return view('accesslog', ["userlist"=>$userlist]);
      }

      public function getaccesslog(Request $data)
      {
        if($data['user']!=""){
          $whereuser = "and a.userid in ( ".$data['user'].")";
        }else{
          $whereuser = "and 1=1";
        }
        $datestart = $data['datestart'];
        $datestart = str_replace('/', '-', $datestart);
        $datestart = date('Y-m-d', strtotime($datestart));

        if($data['datestart']!=""){
          $wheredatestart = "and date(a.date) >= '".$datestart."'";
        }else{
          $wheredatestart = "and 1=1";
        }
        $dateend = $data['dateend'];
        $dateend = str_replace('/', '-', $dateend);
        $dateend = date('Y-m-d', strtotime($dateend));
        if($data['dateend']!=""){
          $wheredateend = "and date(a.date) <= '".$dateend."'";
        }else{
          $wheredateend = "and 1=1";
        }
        $userlist = DB::select(DB::raw("
          select *,a.id as recid from `master.accesslog` a
          join `master_user` b on a.userid = b.id
          where true
          and b.status = 1
          "
          .$whereuser.
          "
          "
          .$wheredatestart.
          "
          "
          .$wheredateend.
          "
          order by b.username
          ;"
        ));
        return response()->json($userlist);
      }

      public function exportaccesslog(Request $data)
      {
        $this->updatelog('Export daily invoice');
        $fileName = 'User_log_'.time().'.xlsx';

        if($data['user']!=""){
          $whereuser = "and a.userid in ( ".$data['user'].")";
        }else{
          $whereuser = "and 1=1";
        }
        $datestart = $data['datestart'];
        $datestart = str_replace('/', '-', $datestart);
        $datestart = date('Y-m-d', strtotime($datestart));

        if($data['datestart']!=""){
          $wheredatestart = "and date(a.date) >= '".$datestart."'";
        }else{
          $wheredatestart = "and 1=1";
        }
        $dateend = $data['dateend'];
        $dateend = str_replace('/', '-', $dateend);
        $dateend = date('Y-m-d', strtotime($dateend));
        if($data['dateend']!=""){
          $wheredateend = "and date(a.date) <= '".$dateend."'";
        }else{
          $wheredateend = "and 1=1";
        }

        $userlist = DB::select(DB::raw("
          select a.id,b.username,b.staffid,b.email,a.date,a.type from `master.accesslog` a
          join `master_user` b on a.userid = b.id
          where true
          and b.status = 1
          "
          .$whereuser.
          "
          "
          .$wheredatestart.
          "
          "
          .$wheredateend.
          "
          order by b.username
          ;"
        ));
        //Excel::store(new DailyInvoiceExport($data['year'],$data['period'],$data['mrid'],$data['flmid'],$data['productgroupid'],$data['channelid'],$data['buid'],$data['subchannel2id'],$data['sourceid']), $fileName, 'public_download');
        $list = collect($userlist);
        (new FastExcel($list))->export($fileName);
        $file_path = $fileName;
        //$file_path = '/download'.$fileName;
        $download_link = url($file_path);

        return Response()->json([
           "success" => true,
           "file" => $download_link
        ]);
       }



       public function target2()
         {
           $this->updatelastlogin();
           $this->updatelog('View target');

           if(Auth::user()->territorytypeid==0){
             $where = "and 1=1";
           }elseif(Auth::user()->territorytypeid==1){
             if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
               $where = "and nsmid in (1,2)";
             }else{
               $where = "and nsmid = ".Auth::user()->territoryid;
             }
           }elseif(Auth::user()->territorytypeid==2){
             $where = "and flmuserid = ".Auth::user()->id;
           }elseif(Auth::user()->territorytypeid==3){
             $where = "and mruserid = ".Auth::user()->id;
           }
           //drop down list
           $yearlist = DB::select(DB::raw("
               SELECT distinct year
               FROM `sales.view_target_dtl`
               where true
               "
               .$where.
               "
               ;"
           ));
           $periodlist = DB::select(DB::raw("
               SELECT distinct period
               FROM `sales.view_target_dtl`
               where true
               "
               .$where.
               "
               ;"
           ));
           $mrcodelist = DB::select(DB::raw("
               SELECT distinct mrid,mrcode,mrname
               FROM `sales.view_target_dtl`
               where true
               "
               .$where.
               "
               order by mrcode,mrname
               ;"
           ));
           $channellist = DB::select(DB::raw("
               SELECT distinct channelid,channel
               FROM `sales.view_target_dtl`
               where true
               "
               .$where.
               "
               order by channel
               ;"
           ));
           $subchannel2list = DB::select(DB::raw("
               SELECT distinct subchannel2id,subchannel2
               FROM `sales.view_target_dtl`
               where true
               "
               .$where.
               "
               order by subchannel2
               ;"
           ));
           $productgrouplist = DB::select(DB::raw("
               SELECT distinct productgroupid,productgroup
               FROM `sales.view_target_dtl`
               where true
               "
               .$where.
               "
               order by productgroup
               ;"
           ));

           $currenttgt = DB::select(DB::raw("
               select year,period from `sales.target_dtl` where lockstatus = 0 order by year,period limit 1
           ;"
           ));
             return view('target2', ["targetlist"=>[],"yearlist"=>$yearlist,"periodlist"=>$periodlist,"channellist"=>$channellist,"subchannel2list"=>$subchannel2list,"mrcodelist"=>$mrcodelist,"productgrouplist"=>$productgrouplist,"currenttgt"=>$currenttgt]);
         }


        public function gettarget2(Request $data)
        {

          if(Auth::user()->territorytypeid==0){
            $where = "and 1=1";
          }elseif(Auth::user()->territorytypeid==1){
            if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
              $where = "and nsmid in (1,2)";
            }else{
              $where = "and nsmid = ".Auth::user()->territoryid;
            }
          }elseif(Auth::user()->territorytypeid==2){
            $where = "and flmuserid = ".Auth::user()->id;
          }elseif(Auth::user()->territorytypeid==3){
            $where = "and mruserid = ".Auth::user()->id;
          }

          if($data['year']!=""){
            $whereyear = "and year in ( ".$data['year'].")";
          }else{
            $whereyear = "and 1=1";
          }

          if($data['period']!=""){
            $whereperiod = "and period in ( ".$data['period'].")";
          }else{
            $whereperiod = "and 1=1";
          }

          if($data['mrid']!=""){
            $wheremr = "and mrid in ( ".$data['mrid'].")";
          }else{
            $wheremr = "and 1=1";
          }

          if($data['channelid']!=""){
            $wherechannel = "and channelid in ( ".$data['channelid'].")";
          }else{
            $wherechannel = "and 1=1";
          }

          if($data['subchannel2id']!=""){
            $wheresubchannel2 = "and subchannel2id in ( ".$data['subchannel2id'].")";
          }else{
            $wheresubchannel2 = "and 1=1";
          }

          if($data['productgroupid']!=""){
            $whereproductgroup = "and productgroupid in ( ".$data['productgroupid'].")";
          }else{
            $whereproductgroup = "and 1=1";
          }

          $targetlist = DB::select(DB::raw("
           select * From (
              SELECT a.*,a.targetdtlid as recid,IFNULL(b.tgt, 0) as lasttgt,if(a.year=c.year and a.period = c.period,a.tgt_temp,a.tgt) as tgt_temp2
              FROM `sales.view_target_dtl` a
              left join `sales.target_dtl` b on a.mrid = b.mrid and a.productgroupid = b.productgroupid and a.productgroupid = b.productgroupid and a.channelid = b.channelid and a.subchannel2id = b.subchannel2id
               and year(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = year(DATE(CONCAT_WS('-', b.year, b.period, 1)))
               and month(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = month(DATE(CONCAT_WS('-', b.year, b.period, 1)))
               ,
               (select year,period from `sales.target_dtl` where lockstatus = 0 order by year,period limit 1) c
               ) aaa
              where true
              "
              .$where.
              "
              "
              .$whereyear.
              "
              "
              .$whereperiod.
              "
              "
              .$wheremr.
              "
              "
              .$wherechannel.
              "
              "
              .$wheresubchannel2.
              "
              "
              .$whereproductgroup.
              "
              order by year,period,mrcode,productgroup
              ;"
          ));
          return response()->json($targetlist);
        }

        public function savetarget2(Request $data)
        {

          $this->updatelog('Update target');
          $maxrow = count($data['changes']);
          for($u = 0; $u<$maxrow; $u++){
             $recid = $data['changes'][$u]['recid'];
             $tgt = $data['changes'][$u]['tgt_temp2'];
             $query = DB::select(DB::raw("
               update `sales.target_dtl`
               set tgt_temp = '".(int)$tgt."'
               ,tgt = '".(int)$tgt."'
               where id = '".$recid."'
               ;"
             ));
          }
          return response()->json('success');

        }

       public function locktarget2(Request $data)
       {

         $this->updatelog('Lock target');

         $currenttgt = DB::select(DB::raw("
             select year,period from `sales.target_dtl` where lockstatus = 0 order by year,period limit 1
         ;"));

         $query = DB::select(DB::raw("
           update `sales.target_dtl`
           set tgt = tgt_temp,
           lockstatus = 1,
           lockdate = now(),
           lockby = '".Auth::user()->id."'
           where year = '".$currenttgt[0]->year."'
           and period = '".$currenttgt[0]->period."'
           ;"
         ));

         $currenttgt = DB::select(DB::raw("
             select year,period from `sales.target_dtl` where lockstatus = 0 order by year,period limit 1
         ;"));

         $monthNum  = $currenttgt[0]->period;
         $dateObj   = DateTime::createFromFormat('!m', $monthNum);
         $monthName = $dateObj->format('F');
         $nexttgt = DB::select(DB::raw("
             select year,period,'".$monthName."' as monthname from `sales.target_dtl` where lockstatus = 0 order by year,period limit 1
         ;"));

         return response()->json($nexttgt);

       }
       public function exporttarget2(Request $data)
       {
         $this->updatelog('Export target');

         $fileName = 'Target2_'.time().'.xlsx';
          Excel::store(new Target2Export($data['year'],$data['period'],$data['mrid'],$data['productgroupid'],$data['channelid'],$data['subchannel2id']), $fileName, 'public_download');
          $file_path = '/download/'.$fileName;
          $download_link = url($file_path);

          return Response()->json([
              "success" => true,
              "file" => $download_link
          ]);
        }

        public function importtarget2 (Request $data) {

          $this->updatelog('Import target');

          //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
          $excel = Excel::toArray(new Target2Import, $data['file'], 'public_upload');
          $sheet1 = $excel[0];

          if($sheet1[0][1]!='Product Group'){
            return Response()->json([
                "success" => false,
                'errors' => 'Wrong file.'
            ]);
          }elseif(count($excel) < 2){
            return Response()->json([
                "success" => false,
                'errors' => 'Wrong file.'
            ]);
          }else{
            $sheet2 = $excel[1];
            $currentfc = DB::select(DB::raw("
                select year,period from `sales.target_dtl` where lockstatus = 0 order by year,period limit 1
            ;"));
            if($currentfc[0]->period == $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] && Auth::user()->id == $sheet2[1][2]){
              foreach ($sheet1 as $row)
              {
                if($row[0]!="id"){
                     if($row[0]!=""){
                       $query = DB::select(DB::raw("
                           update `sales.target_dtl`
                           set tgt_temp = ".(float)$row[6]."
                           ,tgt = ".(float)$row[6]."
                           where id = ".$row[0]."
                           ;"
                       ));
                     }else{
                         $product = DB::select(DB::raw("
                             select * From `master.product_group`
                             where upper(productgroup) = upper('".trim($row[1])."')
                             ;"
                         ));
                         $mr = DB::select(DB::raw("
                             select * From `master.territory_mr`
                             where mrcode = '".trim($row[4])."'
                             ;"
                         ));
                         $channel = DB::select(DB::raw("
                             select * From `master.channel`
                             where channel = '".trim($row[2])."'
                             ;"
                         ));
                         $subchannel2 = DB::select(DB::raw("
                             select * From `master.subchannel2`
                             where subchannel2 = '".trim($row[3])."'
                             ;"
                         ));
                         if(count($product)==1 && count($mr)==1 && count($channel)==1 && count($subchannel2)==1){

                           $checkfc2 = DB::select(DB::raw("
                               select * from `sales.target_dtl`
                               where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and mrid = '".$mr[0]->id."' and productgroupid = '".$product[0]->id."' and channelid = '".$channel[0]->id."' and subchannel2id = '".$subchannel2[0]->id."'
                               ;"
                           ));
                           if(count($checkfc2)==0){
                             $query = DB::select(DB::raw("
                                 insert into `sales.target_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                                  '".$mr[0]->id."', '".$channel[0]->id."', '".$subchannel2[0]->id."', '".$product[0]->id."', '".(float)$row[6]."', 0, now(), now(),'".Auth::user()->id."',
                                   '".Auth::user()->id."', 1, '".(float)$row[6]."', 0, null, null)
                                 ;"
                             ));
                           }else{
                             $query = DB::select(DB::raw("
                                 update `sales.target_dtl`
                                 set tgt_temp = ".(float)$row[6]."
                                 ,tgt = ".(float)$row[6]."
                                 where id = ".$checkfc2[0]->id."
                                 ;"
                             ));
                           }
                         }
                   }
                 }
              }

              return Response()->json([
                  "success" => true
              ]);
            }elseif(($currentfc[0]->period > $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] || $currentfc[0]->year < $sheet2[1][0]) && Auth::user()->id == $sheet2[1][2]){

              foreach ($sheet1 as $row)
              {
                if($row[0]!="id"){
                   if($row[0]!=""){
                     $query = DB::select(DB::raw("
                         update `sales.target_dtl`
                         set tgt_temp = ".(float)$row[6].",tgt = ".(float)$row[6]."
                         where id = ".$row[0]."
                         ;"
                     ));
                   }else{
                       $product = DB::select(DB::raw("
                           select * From `master.product_group`
                           where upper(productgroup) = upper('".trim($row[1])."')
                           ;"
                       ));
                       $mr = DB::select(DB::raw("
                           select * From `master.territory_mr`
                           where mrcode = '".trim($row[4])."'
                           ;"
                       ));
                       $channel = DB::select(DB::raw("
                           select * From `master.channel`
                           where channel = '".trim($row[2])."'
                           ;"
                       ));
                       $subchannel2 = DB::select(DB::raw("
                           select * From `master.subchannel2`
                           where subchannel2 = '".trim($row[3])."'
                           ;"
                       ));
                       if(count($product)==1 && count($mr)==1 && count($channel)==1 && count($subchannel2)==1){
                         $checkfc = DB::select(DB::raw("
                             select * from `sales.target_dtl`
                             where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."'
                             ;"
                         ));
                         $checkfc2 = DB::select(DB::raw("
                             select * from `sales.target_dtl`
                             where year = '".$sheet2[1][0]."' and period = '".$sheet2[1][1]."' and mrid = '".$mr[0]->id."' and productgroupid = '".$product[0]->id."' and channelid = '".$channel[0]->id."' and subchannel2id = '".$subchannel2[0]->id."'
                             ;"
                         ));
                         if(count($checkfc2)==0){
                           $query = DB::select(DB::raw("
                               insert into `sales.target_dtl` values (null, '".$sheet2[1][0]."', '".$sheet2[1][1]."',
                                '".$mr[0]->id."', '".$channel[0]->id."', '".$subchannel2[0]->id."', '".$product[0]->id."', '".(float)$row[6]."', 0, now(), now(),'".Auth::user()->id."',
                                 '".Auth::user()->id."', 1, '".(float)$row[6]."', '".$checkfc[0]->lockstatus."', '".$checkfc[0]->lockdate."', '".$checkfc[0]->lockby."')
                               ;"
                           ));
                         }else{
                           $query = DB::select(DB::raw("
                               update `sales.target_dtl`
                               set tgt_temp = ".(float)$row[6].",tgt = ".(float)$row[6]."
                               where id = ".$checkfc2[0]->id."
                               ;"
                           ));
                         }

                       }
                     }
                   }
              }

              return Response()->json([
                  "success" => true
              ]);
              /*return Response()->json([
                  "success" => false,
                  'errors' => 'Please use the latest file.'
              ]);*/
            }else{
              return Response()->json([
                  "success" => false,
                  'errors' => 'Please use the latest file.'
              ]);
            }
            /*if($currentfc[0]->period == $sheet2[1][1] && $currentfc[0]->year == $sheet2[1][0] && Auth::user()->id == $sheet2[1][2]){
              foreach ($sheet1 as $row)
              {
                $query = DB::select(DB::raw("
                    update `sales.target_dtl`
                    set tgt_temp = ".(float)$row[4]."
                    where id = ".$row[0]."
                    ;"
                ));
              }

              return Response()->json([
                  "success" => true
              ]);
            }else{

              return Response()->json([
                  "success" => false,
                  'errors' => 'Please use the latest file.'
              ]);
            }*/
          }

       }


       public function getaccess()
       {

         $accesslist = DB::select(DB::raw("
         SELECT
             `b`.`userid` AS `userid`,
                 SUM(IF((`b`.`accessid` = 1), 1, 0)) AS `access1`,
                 SUM(IF((`b`.`accessid` = 2), 1, 0)) AS `access2`,
                 SUM(IF((`b`.`accessid` = 3), 1, 0)) AS `access3`,
                 SUM(IF((`b`.`accessid` = 4), 1, 0)) AS `access4`,
                 SUM(IF((`b`.`accessid` = 5), 1, 0)) AS `access5`,
                 SUM(IF((`b`.`accessid` = 6), 1, 0)) AS `access6`,
                 SUM(IF((`b`.`accessid` = 7), 1, 0)) AS `access7`,
                 SUM(IF((`b`.`accessid` = 8), 1, 0)) AS `access8`,
                 SUM(IF((`b`.`accessid` = 9), 1, 0)) AS `access9`,
                 SUM(IF((`b`.`accessid` = 10), 1, 0)) AS `access10`,
                 SUM(IF((`b`.`accessid` = 11), 1, 0)) AS `access11`,
                 SUM(IF((`b`.`accessid` = 12), 1, 0)) AS `access12`,
                 SUM(IF((`b`.`accessid` = 13), 1, 0)) AS `access13`,
                 SUM(IF((`b`.`accessid` = 14), 1, 0)) AS `access14`,
                 SUM(IF((`b`.`accessid` = 15), 1, 0)) AS `access15`,
                 SUM(IF((`b`.`accessid` = 16), 1, 0)) AS `access16`
         FROM
             (`master.portal_access` `a`
         LEFT JOIN `master.portal_access_mapping` `b` ON ((`a`.`id` = `b`.`accessid`)))
         WHERE
             `b`.`userid` = '".Auth::user()->id."'
         GROUP BY `b`.`userid`
             ;"
         ));

         return response()->json($accesslist);
       }


	public function doctor()
       {
        $this->updatelog('View doctor');

        $this->updatelastlogin();
      //drop down list
        $statelist = DB::select(DB::raw("
          SELECT distinct state as id,state as text,state
          FROM `master.customer`
          where true
          ;"
        ));
        $specialistlist = DB::select(DB::raw("
          SELECT id,specialist as text,specialist
          FROM `master.specialist`
          where true
          ;"
        ));
        $fieldofpracticelist = DB::select(DB::raw("
          SELECT id,fieldofpractice as text,fieldofpractice
          FROM `master.field_of_practice`
          where true
          ;"
        ));

        $countryoptionlist = DB::select(DB::raw("
          SELECT distinct id,country as text
          FROM `master.country`
          where true
          ;"
        ));
        $genderlist = array();
        $genderlist[0] = (object) array( 'id' => 'M', 'text' => 'Male' );
        $genderlist[1] = (object) array( 'id' => 'F', 'text' => 'Female' );

        return view('doctor', ["doctorlist"=>[],"countrylist"=>$countryoptionlist,"countryoptionlist"=>json_encode($countryoptionlist),"specialistlist"=>$specialistlist,"genderoptionlist"=>json_encode($genderlist),"fieldofpracticelist"=>$fieldofpracticelist,"stateoptionlist"=>json_encode($statelist),"specialistoptionlist"=>json_encode($specialistlist),"fieldofpracticeoptionlist"=>json_encode($fieldofpracticelist)]);
      }



      public function getdoctor(Request $data)
      {
        DB::enableQueryLog();
        if($data['code']!=""){
         $whereshiptocode = "and code like '%".$data['code']."%'";
       }else{
         $whereshiptocode = "and 1=1";
       }

       if($data['name']!=""){
        $whereshiptoname = "and name like '%".$data['name']."%'";
      }else{
        $whereshiptoname = "and 1=1";
      }
      if($data['country']!=""){
       $wherecountry = "and countryid in ( ".$data['country'].")";
     }else{
       $wherecountry = "and 1=1";
     }

    $doctorlist = DB::select(DB::raw("
      select a.*,a.id as recid,a.id as doctorid,b.country From `master.doctor` a
      left join `master.country` b on a.countryid = b.id
      where true
      "
      .$whereshiptocode.
      "
      "
      .$whereshiptoname.
      "
      "
      .$wherecountry.
      "
      ;"
    ));
    return response()->json($doctorlist);
  }



  public function exportdoctor(Request $data)
  {
      //$this->updatelog('Export doctor');
    $fileName = 'doctor_'.date("Y-m-d").'.xlsx';
    Excel::store(new DoctorExport($data['code'],$data['name'],$data['country']), $fileName, 'public_download');
    $file_path = '/download/'.$fileName;
    $download_link = url($file_path);

    return Response()->json([
     "success" => true,
     "file" => $download_link
   ]);
  }

  public function importdoctor (Request $data) {
   $this->updatelog('Import doctor');
       //$data = Excel::import(new ForecastImport, 'Forecast2.xlsx', 'public_upload');
   $excel = Excel::toArray(new DoctorImport, $data['file'], 'public_upload');

   $sheet1 = $excel[0];
   if($sheet1[0][0]!='Code'){
     return Response()->json([
       "success" => false,
       'errors' => 'Wrong file.'
     ]);
   }elseif(count($excel[0]) < 2){
     return Response()->json([
       "success" => false,
       'errors' => 'Wrong file.'
     ]);
   }else{
     foreach ($sheet1 as $row)
     {
       if($row[2]!=""){
         $query = DB::select(DB::raw("
           SELECT * FROM `master.doctor`
           where code = '".trim($row[0])."'
           ;"
         ));
         if(count($query)>0){
           $doctorid = $query[0]->id;
         }else{
           $doctorid = 0;
         }
         $query2 = DB::select(DB::raw("
           SELECT * FROM `master.country`
           where country = '".trim($row[2])."'
           ;"
         ));
         if(count($query2)>0){
           $countryid = $query2[0]->id;
         }else{
           $countryid = 0;
         }
         if(count($query)>0){
           DB::select(DB::raw("
             update `master.doctor`
             set code = '".$row[0]."',
             name = '".str_replace("'", "\'", $row[1])."',
             countryid = '".$countryid."',
             datemodified = now(),
             modifiedby = '".Auth::user()->id."'
             where id = '".$doctorid."'
             ;"));
         }else{
           if($row[0]!= 'Code'){
             DB::select(DB::raw("
               insert into `master.doctor`
               (code,
               name,countryid,
               status,datecreated,datemodified,createdby,modifiedby)
               values
               (
               '".$row[0]."',
               '".str_replace("'", "\'", $row[1])."',
               '".$countryid."',
               1,now(),now(),'".Auth::user()->id."','".Auth::user()->id."'
               )
               ;"));
           }
         }
       }
     }
     return Response()->json([
      "success" => true
    ]);
   }

 }
 public function savedoctor(Request $data)
 {
   $this->updatelog('Update doctor');
   if($data['doctorid']!=""){
     $query = DB::select(DB::raw("
       update `master.doctor`
       set code = '".$data['code']."',
       name = '".str_replace("'", "\'", $data['name'])."',
       countryid = '".(int)$data['countryid']."',
       modifiedby = '".Auth::user()->id."',
       datemodified = now()
       where id = '".$data['doctorid']."'
       ;"
     ));
   }else{
     $query = DB::select(DB::raw("
      insert into `master.doctor`
       (code,name,countryid,
       status,createdby,modifiedby,datecreated,datemodified)
      VALUES
      ('".$data['code']."','".str_replace("'", "\'", $data['name'])."','".(int)$data['countryid']."',1,'".Auth::user()->id."','".Auth::user()->id."',now(),now())
      ;"
    ));
   }

   return response()->json('success');

 }

       
       
       public function mapcustomerdoctor()
       {
         //$this->updatelog('View map customer doctor');
         //$this->updatelastlogin();

        $customeroptionlist = DB::select(DB::raw("
            SELECT id ,concat(shiptocode,' - ',shiptoname) as text
            FROM `master.customer`
            where true
            ;"
        ));
        $doctoroptionlist = DB::select(DB::raw("
            SELECT id ,concat(code,' - ',name) as text
            FROM `master.doctor`
            where true
            ;"
        ));
         return view('mapcustomerdoctor', ["productlist"=>[],"customeroptionlist"=>$customeroptionlist,"doctoroptionlist"=>$doctoroptionlist]);
       }


      public function getmapcustomerdoctor(Request $data)
      {
        if($data['shiptocode']!=""){
          $whereshiptocode = "and a.shiptocode like '%".$data['shiptocode']."%'";
        }else{
          $whereshiptocode = "and 1=1";
        }
        if($data['shiptoname']!=""){
          $whereshiptoname = "and a.shiptoname like '%".$data['shiptoname']."%'";
        }else{
          $whereshiptoname = "and 1=1";
        }
        if($data['doctorcode']!=""){
          $wheredoctorcode = "and a.doctorcode like '%".$data['doctorcode']."%'";
        }else{
          $wheredoctorcode = "and 1=1";
        }
        if($data['doctorname']!=""){
          $wheredoctorname = "and a.doctorname like '%".$data['doctorname']."%'";
        }else{
          $wheredoctorname = "and 1=1";
        }

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.view_map_customer_doctor` a
          where true
          "
          .$whereshiptocode.
          "
          "
          .$whereshiptoname.
          "
          "
          .$wheredoctorcode.
          "
          "
          .$wheredoctorname.
          "
          ;"
        ));
        return response()->json($productlist);
      }


      public function deletemapcustomerdoctor(Request $data)
      {
        if($data['shiptocode']!=""){
          $whereshiptocode = "and a.shiptocode like '%".$data['shiptocode']."%'";
        }else{
          $whereshiptocode = "and 1=1";
        }
        if($data['shiptoname']!=""){
          $whereshiptoname = "and a.shiptoname like '%".$data['shiptoname']."%'";
        }else{
          $whereshiptoname = "and 1=1";
        }
        if($data['doctorcode']!=""){
          $wheredoctorcode = "and a.doctorcode like '%".$data['doctorcode']."%'";
        }else{
          $wheredoctorcode = "and 1=1";
        }
        if($data['doctorname']!=""){
          $wheredoctorname = "and a.doctorname like '%".$data['doctorname']."%'";
        }else{
          $wheredoctorname = "and 1=1";
        }
        $query = DB::select(DB::raw("
          delete from `master.map_customer_doctor`
          where id = '".$data['recid']."'
        ;"
        ));

        $productlist = DB::select(DB::raw("
          select *,id as recid from `master.view_map_customer_doctor` a
          where true
          "
          .$whereshiptocode.
          "
          "
          .$whereshiptoname.
          "
          "
          .$wheredoctorcode.
          "
          "
          .$wheredoctorname.
          "
          ;"
        ));
        return response()->json($productlist);
      }

      public function savemapcustomerdoctor(Request $data)
      {
        //$this->updatelog('Update map customer doctor');
        if($data['id']!=""){
          $query = DB::select(DB::raw("
            update `master.map_customer_doctor`
            set cutomerid = '".$data['customerid']."',
            doctorid = '".$data['doctorid']."',
            modifiedby = '".Auth::user()->id."',
            datemodified = now()
            where id = '".$data['id']."'
          ;"
          ));
        }else{
          $query = DB::select(DB::raw("
            insert into `master.map_customer_doctor`
            VALUES
            (null,'".$data['customerid']."','".$data['doctorid']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1)
          ;"
          ));
        }
        return response()->json('success');
      }



  public function sample()
   {
     //$this->updatelastlogin();
     //$this->updatelog('View sample quota');
     //drop down list 
     $sampleoptionlist = DB::select(DB::raw("
         SELECT 1 id ,'Yes' as text 
         union all 
         SELECT 0 id ,'No' as text
         ;"
     ));
     $sourceoptionlist = DB::select(DB::raw("
         SELECT distinct source as id ,source as text
         FROM `master.product`
         where true
         ;"
     ));
     $productgroupoptionlist = DB::select(DB::raw("
         SELECT id ,`productgroup` as text
         FROM `master.product_group`
         where true
         ;"
     ));
     $buoptionlist = DB::select(DB::raw("
         SELECT id ,bu as text
         FROM `master.bu`
         where true
         ;"
     ));
    $yearoptionlist = array();
    $y = 0;
    for ($x = 2022; $x <= date("Y"); $x++) {
      $yearoptionlist[$y] = (object) array( 'id' => $x, 'text' => $x );
      $y++;
    }
     return view('sample', ["productlist"=>[],"sourceoptionlist"=>json_encode($sourceoptionlist),"sampleoptionlist"=>json_encode($sampleoptionlist),"productgroupoptionlist"=>json_encode($productgroupoptionlist),"productgroupoptionlist2"=>$productgroupoptionlist,"buoptionlist"=>$buoptionlist,"yearoptionlist"=>json_encode($yearoptionlist)]);
   }


  public function getsample(Request $data)
  {

    if($data['productgroup']!=""){
      $whereproductgroup = "and productgroupid in (".$data['productgroup'].")";
    }else{
      $whereproductgroup = "and 1=1";
    }

   if($data['code']!=""){
     $wherecode = "and productcode like '%".$data['code']."%'";
   }else{
     $wherecode = "and 1=1";
   }
    if($data['product']!=""){
      $whereproduct = "and productdesc in ( ".$data['product'].")";
    }else{
      $whereproduct = "and 1=1";
    }

    if($data['altproductcode']!=""){
      $wherealtproductcode = "and altproductcode in ( ".$data['altproductcode'].")";
    }else{
      $wherealtproductcode = "and 1=1";
    }

    if($data['altproduct']!=""){
      $wherealtproduct = "and altproduct in ( ".$data['altproduct'].")";
    }else{
      $wherealtproduct = "and 1=1";
    }

    if($data['bu']!=""){
      $wherebu = "and buid in (".$data['bu'].")";
    }else{
      $wherebu = "and 1=1";
    }
    $productlist = DB::select(DB::raw("
     select  a.productgroup,a.id as productgroupid,a.id as recid,null as productid,b.qty,b.id,ifnull(b.year,year(now())) as year From `master.product_group` a
     left join `master.sample_quota` b on a.id = b.productgroupid 
        where true
        "
        .$whereproductgroup.
        "
        "
        .$wherecode.
        "
        "
        .$whereproduct.
        "
        "
        .$wherealtproductcode.
        "
        "
        .$wherealtproduct.
        "
        "
        .$wherebu.
        "
        ;"
    ));
    return response()->json($productlist);
  }

  public function savesample(Request $data)
  {
    //$this->updatelog('Update sample quota');
    if($data['id']!=""){
      $query = DB::select(DB::raw("
       update `master.sample_quota`
       set year = null,
       qty = '".$data['qty']."',
       productgroupid = '".$data['productgroup']."',
       modifiedby = '".Auth::user()->id."',
       datemodified = now()
       where id = '".$data['id']."'
       ;"
      ));
    }else{
      $query = DB::select(DB::raw("
        insert into `master.sample_quota`
        VALUES
        (null,null,null,'".$data['qty']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1,'".$data['productgroup']."')
      ;"
      ));
    }
    return response()->json('success');
  }

	

    public function samplereport(Request $data)
    {
      $this->updatelog('View Sample Report Detail');
      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and teamid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==1){
          $where = "and territoryid = ".Auth::user()->territoryid;
        }

        
        $doctorlist = DB::select(DB::raw("
            SELECT id as  doctorid,code as doctorcode,name as doctorname
            FROM `master.doctor`
            where true
            order by name
            ;"
        ));

        $customerlist = DB::select(DB::raw("
            SELECT id as  customerid,shiptocode as shiptocode,shiptoname as shiptoname
            FROM `master.customer`
            where true
            order by shiptoname
            ;"
        ));


        $productgrouplist = DB::select(DB::raw("
            SELECT id as  productgroupid,productgroup as productgroupname
            FROM `master.product_group`
            where true
            order by productgroup
            ;"
        ));
       return view('samplereport', ["doctorlist"=>$doctorlist,"customerlist"=>$customerlist,"productgrouplist"=>$productgrouplist]);
      }

      public function getsamplereport(Request $data)
      {


          if(Auth::user()->territorytypeid==0){
            $where = "and 1=1";
          }elseif(Auth::user()->territorytypeid==1){
            if(Auth::user()->territoryid == 0){
              $where = "and 1=1";
            }else{
              $where = "and orderby = ".Auth::user()->id;
            }
          }elseif(Auth::user()->territorytypeid==2){
            $where = "and flmuserid = ".Auth::user()->id;
          }

          if($data['customerid']!=""){
            $wherecustomerid = "and customerid in ( ".$data['customerid'].")";
          }else{
            $wherecustomerid = "and 1=1";
          }
          if($data['doctorid']!=""){
            $wheredoctorid = "and doctorid in ( ".$data['doctorid'].")";
          }else{
            $wheredoctorid = "and 1=1";
          }
	
          if($data['productgroupid']!=""){
            $whereproductgroupid = "and productgroupid in ( ".$data['productgroupid'].")";
          }else{
            $whereproductgroupid = "and 1=1";
          }

          $invoicelist = DB::select(DB::raw("
           SELECT concat(doctorid,'_',productgroupid) as recid,shiptocode,shiptoname,doctorcode,doctorname,productgroup,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 1,qty,0)) as jan,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 2,qty,0)) as feb,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 3,qty,0)) as mar,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 4,qty,0)) as apr,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 5,qty,0)) as may,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 6,qty,0)) as jun,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 7,qty,0)) as jul,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 8,qty,0)) as aug,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 9,qty,0)) as sep,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 10,qty,0)) as oct,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 11,qty,0)) as nov,
            sum(if(year(orderdate) = year(now()) and month(orderdate) = 12,qty,0)) as `dec`,
          sum(if(year(orderdate) = year(now()) ,qty,0)) as `total`
             FROM sampledb.`sales.view_order_sample_detail`
	     where true
		and status != 3
             ".$where."
             ".$wherecustomerid."
	     ".$wheredoctorid."
	     ".$whereproductgroupid."
             group by doctorcode,doctorname,productgroup,productgroupid,doctorid,shiptocode,shiptoname;"
          ));

        return response()->json($invoicelist);
      }

      public function exportsamplereport(Request $data)
      {
        $this->updatelog('Export Sample Report Summary');
        $fileName = 'HCP_Sample_Order_Summary_'.time().'.xlsx';
        

        if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==1){
          if(Auth::user()->territoryid == 0){
            $where = "and 1=1";
          }else{
            $where = "and orderby = ".Auth::user()->id;
          }
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and flmuserid = ".Auth::user()->id;
        }

        if($data['customerid']!=""){
          $wherecustomerid = "and customerid in ( ".$data['customerid'].")";
        }else{
          $wherecustomerid = "and 1=1";
        }
        if($data['doctorid']!=""){
          $wheredoctorid = "and doctorid in ( ".$data['doctorid'].")";
        }else{
          $wheredoctorid = "and 1=1";
        }
	
          if($data['productgroupid']!=""){
            $whereproductgroupid = "and productgroupid in ( ".$data['productgroupid'].")";
          }else{
            $whereproductgroupid = "and 1=1";
          }

        $invoicelist = DB::select(DB::raw("
         SELECT shiptocode as `Ship To Code`,shiptoname as `Ship To Name`,doctorcode as `Doctor Code`,doctorname as `Doctor Name`,productgroup as `Product Group`,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 1,qty,0)) as jan,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 2,qty,0)) as feb,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 3,qty,0)) as mar,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 4,qty,0)) as apr,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 5,qty,0)) as may,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 6,qty,0)) as jun,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 7,qty,0)) as jul,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 8,qty,0)) as aug,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 9,qty,0)) as sep,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 10,qty,0)) as oct,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 11,qty,0)) as nov,
          sum(if(year(orderdate) = year(now()) and month(orderdate) = 12,qty,0)) as `dec`,
          sum(if(year(orderdate) = year(now()) ,qty,0)) as `total`
           FROM sampledb.`sales.view_order_sample_detail`
	   where true
	and status != 3
           ".$where."
           ".$wherecustomerid."
	   ".$wheredoctorid."
	   ".$whereproductgroupid."
           group by doctorcode,doctorname,productgroup,doctorid,shiptocode,shiptoname;"
        ));
         $list = collect($invoicelist);

        (new FastExcel($list))->export($fileName);
         $file_path = $fileName;
         //$file_path = '/download'.$fileName;
         $download_link = url($file_path);

         return Response()->json([
             "success" => true,
             "file" => $download_link
         ]);
      }

public function sampletrackerreport(Request $data)
{
  $this->updatelog('View Sample Report Detail');
  if(Auth::user()->territorytypeid==0){
    $where = "and 1=1";
  }elseif(Auth::user()->territorytypeid==2){
    $where = "and teamid = ".Auth::user()->territoryid;
  }elseif(Auth::user()->territorytypeid==1){
    $where = "and territoryid = ".Auth::user()->territoryid;
  }


  $doctorlist = DB::select(DB::raw("
    SELECT id as  doctorid,code as doctorcode,name as doctorname
    FROM `master.doctor`
    where true
    order by name
    ;"
  ));

  $customerlist = DB::select(DB::raw("
    SELECT id as  customerid,shiptocode as shiptocode,shiptoname as shiptoname
    FROM `master.customer`
    where true
    order by shiptoname
    ;"
  ));


  $productgrouplist = DB::select(DB::raw("
    SELECT id as  productgroupid,productgroup as productgroupname
    FROM `master.product_group`
    where true
    order by productgroup
    ;"
  ));
  return view('sampletrackerreport', ["doctorlist"=>$doctorlist,"customerlist"=>$customerlist,"productgrouplist"=>$productgrouplist]);
}
public function getsampletrackerreport(Request $data)
{


  if(Auth::user()->territorytypeid==0){
    $where = "and 1=1";
  }elseif(Auth::user()->territorytypeid==1){
    if(Auth::user()->territoryid == 0){
      $where = "and 1=1";
    }else{
      $where = "and orderby = ".Auth::user()->id;
    }
  }elseif(Auth::user()->territorytypeid==2){
    $where = "and flmuserid = ".Auth::user()->id;
  }

  if($data['customerid']!=""){
    $wherecustomerid = "and customerid in ( ".$data['customerid'].")";
  }else{
    $wherecustomerid = "and 1=1";
  }
  if($data['doctorid']!=""){
    $wheredoctorid = "and doctorid in ( ".$data['doctorid'].")";
  }else{
    $wheredoctorid = "and 1=1";
  }

  if($data['productgroupid']!=""){
    $whereproductgroupid = "and productgroupid in ( ".$data['productgroupid'].")";
  }else{
    $whereproductgroupid = "and 1=1";
  }

  $invoicelist = DB::select(DB::raw("
   SELECT concat(doctorid,'_',productgroupid) as recid,orderbyname,shiptocode,shiptoname,doctorcode,doctorname,productgroup,productcode,productname,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 1,qty,0)) as jansample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 2,qty,0)) as febsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 3,qty,0)) as marsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 4,qty,0)) as aprsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 5,qty,0)) as maysample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 6,qty,0)) as junsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 7,qty,0)) as julsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 8,qty,0)) as augsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 9,qty,0)) as sepsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 10,qty,0)) as octsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 11,qty,0)) as novsample,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 12,qty,0)) as `decsample`,
   sum(if(year(orderdate) = year(now()) ,qty,0)) as `total`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 1,salesqty,0)) as jansales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 2,salesqty,0)) as febsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 3,salesqty,0)) as marsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 4,salesqty,0)) as aprsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 5,salesqty,0)) as maysales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 6,salesqty,0)) as junsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 7,salesqty,0)) as julsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 8,salesqty,0)) as augsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 9,salesqty,0)) as sepsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 10,salesqty,0)) as octsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 11,salesqty,0)) as novsales,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 12,salesqty,0)) as `decsales`,
   sum(if(year(orderdate) = year(now()) ,salesqty,0)) as `totalsales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 1,qty - salesqty,0)) as janvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 2,qty - salesqty,0)) as febvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 3,qty - salesqty,0)) as marvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 4,qty - salesqty,0)) as aprvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 5,qty - salesqty,0)) as mayvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 6,qty - salesqty,0)) as junvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 7,qty - salesqty,0)) as julvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 8,qty - salesqty,0)) as augvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 9,qty - salesqty,0)) as sepvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 10,qty - salesqty,0)) as octvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 11,qty - salesqty,0)) as novvar,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 12,qty - salesqty,0)) as `decvar`,
   sum(if(year(orderdate) = year(now()) ,qty-salesqty,0)) as `totalvar`
   FROM sampledb.`sales.view_order_sample_detailv2`
   where true
   ".$where."
   ".$wherecustomerid."
   ".$wheredoctorid."
   ".$whereproductgroupid."
   group by orderbyname,shiptocode,shiptoname,doctorcode,doctorname,productgroup,productcode,productname,doctorid,productgroupid;"
 ));

  return response()->json($invoicelist);
}
public function exportsampletrackerreport(Request $data)
{
  $this->updatelog('Export Sample Tracker Report');
  $fileName = 'Sample_Tracker_Report_'.time().'.xlsx';


  if(Auth::user()->territorytypeid==0){
    $where = "and 1=1";
  }elseif(Auth::user()->territorytypeid==1){
    if(Auth::user()->territoryid == 0){
      $where = "and 1=1";
    }else{
      $where = "and orderby = ".Auth::user()->id;
    }
  }elseif(Auth::user()->territorytypeid==2){
    $where = "and flmuserid = ".Auth::user()->id;
  }

  if($data['customerid']!=""){
    $wherecustomerid = "and customerid in ( ".$data['customerid'].")";
  }else{
    $wherecustomerid = "and 1=1";
  }
  if($data['doctorid']!=""){
    $wheredoctorid = "and doctorid in ( ".$data['doctorid'].")";
  }else{
    $wheredoctorid = "and 1=1";
  }

  if($data['productgroupid']!=""){
    $whereproductgroupid = "and productgroupid in ( ".$data['productgroupid'].")";
  }else{
    $whereproductgroupid = "and 1=1";
  }

  $invoicelist = DB::select(DB::raw("
   SELECT orderbyname as `MR Name`,shiptocode as `Ship To Code`,shiptoname as `Ship To Name`,doctorcode as `Doctor Code`,doctorname as `Doctor Name`,productgroup as `Product Group`,productcode as `Product Code`,productname as `Product Name`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 1,qty,0)) as `Jan Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 1,salesqty,0)) as `Jan Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 1,qty - salesqty,0)) as `Jan Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 2,qty,0)) as `Feb Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 2,salesqty,0)) as `Feb Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 2,qty - salesqty,0)) as `Feb Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 3,qty,0)) as `Mar Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 3,salesqty,0)) as `Mar Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 3,qty - salesqty,0)) as `Mar Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 4,qty,0)) as `Apr Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 4,salesqty,0)) as `Apr Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 4,qty - salesqty,0)) as `Apr Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 5,qty,0)) as `May Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 5,salesqty,0)) as `May Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 5,qty - salesqty,0)) as `May Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 6,qty,0)) as `Jun Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 6,salesqty,0)) as `Jun Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 6,qty - salesqty,0)) as `Jun Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 7,qty,0)) as `Jul Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 7,salesqty,0)) as `Jul Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 7,qty - salesqty,0)) as `Jul Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 8,qty,0)) as `Aug Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 8,salesqty,0)) as `Aug Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 8,qty - salesqty,0)) as `Aug Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 9,qty,0)) as `Sep Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 9,salesqty,0)) as `Sep Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 9,qty - salesqty,0)) as `Sep Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 10,qty,0)) as `Oct Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 10,salesqty,0)) as `Oct Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 10,qty - salesqty,0)) as `Oct Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 11,qty,0)) as `Nov Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 11,salesqty,0)) as `Nov Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 11,qty - salesqty,0)) as `Nov Discrepency`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 12,qty,0)) as `Dec Order`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 12,salesqty,0)) as `Dec Sales`,
   sum(if(year(orderdate) = year(now()) and month(orderdate) = 12,qty - salesqty,0)) as `Dec Discrepency`,
   sum(if(year(orderdate) = year(now()) ,qty,0)) as `Total Order`,
   sum(if(year(orderdate) = year(now()) ,salesqty,0)) as `Total Sales`,
   sum(if(year(orderdate) = year(now()) ,qty-salesqty,0)) as `Discrepency`
   FROM sampledb.`sales.view_order_sample_detailv2`
   where true
   ".$where."
   ".$wherecustomerid."
   ".$wheredoctorid."
   ".$whereproductgroupid."
   group by orderbyname,shiptocode,shiptoname,doctorcode,doctorname,productgroup,productcode,productname,doctorid,productgroupid;"
 ));
  $list = collect($invoicelist);

  (new FastExcel($list))->export($fileName);
  $file_path = $fileName;
         //$file_path = '/download'.$fileName;
  $download_link = url($file_path);

  return Response()->json([
   "success" => true,
   "file" => $download_link
 ]);
}

    public function samplereportdetail(Request $data)
    {
      $this->updatelog('View Sample Report Detail');
      if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==2){
          $where = "and teamid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==1){
          $where = "and territoryid = ".Auth::user()->territoryid;
        }

        
        $doctorlist = DB::select(DB::raw("
            SELECT id as  doctorid,code as doctorcode,name as doctorname
            FROM `master.doctor`
            where true
            order by name
            ;"
        ));

        $customerlist = DB::select(DB::raw("
            SELECT id as  customerid,shiptocode as shiptocode,shiptoname as shiptoname
            FROM `master.customer`
            where true
            order by shiptoname
            ;"
        ));

	$productgrouplist = DB::select(DB::raw("
            SELECT id as  productgroupid,productgroup as productgroupname
            FROM `master.product_group`
            where true
            order by productgroup
            ;"
        ));
       return view('samplereportdetail', ["doctorlist"=>$doctorlist,"customerlist"=>$customerlist,"productgrouplist"=>$productgrouplist]);
      }

      public function getsamplereportdetail(Request $data)
      {

          if(Auth::user()->territorytypeid==0){
            $where = "and 1=1";
          }elseif(Auth::user()->territorytypeid==1){
            if(Auth::user()->territoryid == 0){
              $where = "and 1=1";
            }else{
              $where = "and orderby = ".Auth::user()->id;
            }
          }elseif(Auth::user()->territorytypeid==2){
            $where = "and flmuserid = ".Auth::user()->id;
          }

          if($data['customerid']!=""){
            $wherecustomerid = "and customerid in ( ".$data['customerid'].")";
          }else{
            $wherecustomerid = "and 1=1";
          }
          if($data['doctorid']!=""){
            $wheredoctorid = "and doctorid in ( ".$data['doctorid'].")";
          }else{
            $wheredoctorid = "and 1=1";
          }
	
          if($data['productgroupid']!=""){
            $whereproductgroupid = "and productgroupid in ( ".$data['productgroupid'].")";
          }else{
            $whereproductgroupid = "and 1=1";
          }

          $invoicelist = DB::select(DB::raw("
           SELECT *,id as recid,
           CASE
              WHEN status = 1 THEN 'Waiting For Approval'
              WHEN status = 2 THEN 'Approved'
              WHEN status = 3 THEN 'Rejected'
              ELSE 'Saved'
          END as statusdesc
             FROM sampledb.`sales.view_order_sample_detail`
             where true
             ".$where."
             ".$wherecustomerid."
             ".$wheredoctorid."
	     
             ".$whereproductgroupid."
	     ;"
          ));
        return response()->json($invoicelist);
      }

      public function exportsamplereportdetail(Request $data)
      {
        $this->updatelog('Export Sample Report Detail');
        $fileName = 'HCP_Sample_Order_Detail_'.time().'.xlsx';
        
          if(Auth::user()->territorytypeid==0){
            $where = "and 1=1";
          }elseif(Auth::user()->territorytypeid==1){
            if(Auth::user()->territoryid == 0){
              $where = "and 1=1";
            }else{
              $where = "and orderby = ".Auth::user()->id;
            }
          }elseif(Auth::user()->territorytypeid==2){
            $where = "and flmuserid = ".Auth::user()->id;
          }
          
          if($data['customerid']!=""){
            $wherecustomerid = "and customerid in ( ".$data['customerid'].")";
          }else{
            $wherecustomerid = "and 1=1";
          }
          if($data['doctorid']!=""){
            $wheredoctorid = "and doctorid in ( ".$data['doctorid'].")";
          }else{
            $wheredoctorid = "and 1=1";
	  }

          if($data['productgroupid']!=""){
            $whereproductgroupid = "and productgroupid in ( ".$data['productgroupid'].")";
          }else{
            $whereproductgroupid = "and 1=1";
          }

          $invoicelist = DB::select(DB::raw("
           SELECT shiptocode as `Ship To Code`,
            shiptoname as `Ship To Name`,
            doctorcode as `Doctor Code`,
            doctorname as `Doctor Name`,
            orderno as `Order No`,
            orderdate as `Order Date`,
            reference as `Reference`,
            approvebyname as `Approve By`,
            approvedate as `Approve Date`,
            rejectbyname as `Reject By`,
            rejectdate as `Reject Date`,
	   productgroup as `Product Group`,
		 productcode as `Product Code`,
            productname as `Product Name`,
            remark as `Instruction`,
           CASE
              WHEN status = 1 THEN 'Waiting For Approval'
              WHEN status = 2 THEN 'Approved'
              WHEN status = 3 THEN 'Rejected'
              ELSE 'Saved'
          END as Status
             FROM sampledb.`sales.view_order_sample_detail`
             where true
             ".$where."
             ".$wherecustomerid."
             ".$wheredoctorid."
             ".$whereproductgroupid."
             ;"
          ));
         //Excel::store(new DailyInvoiceExport($data['year'],$data['period'],$data['mrid'],$data['flmid'],$data['productgroupid'],$data['channelid'],$data['buid'],$data['subchannel2id'],$data['sourceid']), $fileName, 'public_download');
         $list = collect($invoicelist);

        (new FastExcel($list))->export($fileName);
         $file_path = $fileName;
         //$file_path = '/download'.$fileName;
         $download_link = url($file_path);

         return Response()->json([
             "success" => true,
             "file" => $download_link
         ]);
      }


      public function sampleorder()
       {
         //drop down list
         //$this->updatelog('View sample oder');
        if(Auth::user()->territorytypeid==0){
            $where = "and 1=1";
          }elseif(Auth::user()->territorytypeid==1){
            if(Auth::user()->territoryid == 0){
              $where = "and 1=1";
            }else{
              $where = "and c.mruserid = ".Auth::user()->id;
            }

          }elseif(Auth::user()->territorytypeid==2){
            $where = "and c.flmuserid = ".Auth::user()->id;
          }
         $doctoroptionlist = DB::select(DB::raw("
             SELECT id ,concat(REPLACE(code, '\n', ''),' - ',name) as text
             FROM `master.doctor` a
             where true
             and countryid in (
              select d.countryid from  `master.view_map_approver` c
               join `master.view_map_territory_country` d on c.territoryid = d.territoryid 
               where true
              "
              .$where.
              "
               )
             ;"
         ));
         /*$customeroptionlist = DB::select(DB::raw("
             SELECT id ,concat(REPLACE(shiptocode, '\n', ''),' - ',shiptoname) as text
             FROM `master.customer`
             where true
	    
	     and shiptocode = '70037122' 
             ;"
	      ));*/
         /*$customeroptionlist = DB::select(DB::raw("
             SELECT a.id ,concat(REPLACE(a.shiptocode, '\n', ''),' - ',a.shiptoname) as text
             FROM `master.view_customer` a
	      
             left join `master.view_map_territory_country` b on a.countryid = b.countryid
             left join `master.view_map_approver` c on b.territoryid = c.territoryid
	    	
             where 1 = 1
	     and shiptocode like '7%'
	     "
              .$where.
              "
             ;"
	 ));*/

	 $customeroptionlist = DB::select(DB::raw("
            SELECT a.id ,concat(REPLACE(a.shiptocode, '\n', ''),' - ',a.shiptoname) as text
            FROM `master.view_customer` a

            left join (select distinct b.countryid from `master.view_map_approver` c
            left join `master.view_map_territory_country` b on c.territoryid = b.territoryid
                        where true
                        "
                        .$where.
                        "
            ) b on a.countryid = b.countryid
            where 1 = 1
            and shiptocode like '7%'

             ;"
           ));
	/*$customeroptionlist = DB::select(DB::raw("
             SELECT a.id ,concat(REPLACE(a.shiptocode, '\n', ''),' - ',a.shiptoname) as text
             FROM `master.view_customer` a
              left join `master.view_map_territory_customer` b on a.id = b.customerid
              left join `master.view_map_approver` c on b.territoryid = c.territoryid
              where 1 = 1
              "
              .$where.
              "
             ;"
	 ));*/

	/* $skuoptionlist = DB::select(DB::raw("
             SELECT id ,concat(REPLACE(Code, '\n', ''),' - ',`Desc`) as text
             FROM `master.product`
             where true
             and sampletype = 1
             ;"
	 ));*/

	
         /*$skuoptionlist = DB::select(DB::raw("
         SELECT id ,concat(REPLACE(Code, '\n', ''),' - ',`Desc`) as text
             FROM `master.product` a
               join (select distinct productgroupid,territoryid from `master.map_territory_customer_product`) b on a.productgroupid = b.productgroupid
               join `master.view_map_approver` c on b.territoryid = c.territoryid
               join `master.view_map_territory_country` d on b.territoryid = d.territoryid and a.countryid = d.countryid
             where true
             and a.sampletype = 1
             and a.status = 1
              "
              .$where.
              "
             ;"
	 ));*/

           $skuoptionlist = DB::select(DB::raw("
             SELECT a.ID as id ,concat(REPLACE(Code, '\n', ''),' - ',`Desc`) as text
             FROM (select *,".Auth::user()->territoryid." as territoryid from `master.product`) a
             join `master.view_map_approver` c on a.territoryid = c.territoryid
             join `master.view_map_territory_country` d on a.territoryid = d.territoryid and a.countryid = d.countryid
             where true
             and a.sampletype = 1
             and a.status = 1
             ;"
           ));

        $statuslist = array();
        $statuslist[0] = (object) array( 'id' => 0, 'text' => 'Saved' );
        $statuslist[1] = (object) array( 'id' => 1, 'text' => 'Waiting For Approval' );
        $statuslist[2] = (object) array( 'id' => 2, 'text' => 'Approved' );
        $statuslist[3] = (object) array( 'id' => 3, 'text' => 'Rejected' );

        if(Auth::user()->territorytypeid==0){
          $where = "and 1=1";
        }elseif(Auth::user()->territorytypeid==1){
          if(Auth::user()->territoryid==1 or Auth::user()->territoryid==2){
            $where = "and nsmid in (1,2)";
          }else{
            $where = "and nsmid = ".Auth::user()->territoryid;
          }

        }elseif(Auth::user()->territorytypeid==2){
          $where = "and flmid = ".Auth::user()->territoryid;
        }elseif(Auth::user()->territorytypeid==3){
          $where = "and mrid = ".Auth::user()->territoryid;
        }

        if(Session::get('ka')==0){
          $targettablename = "`sales.portal_target_trail`";
        }else{
          $targettablename = "`sales.portal_target2_trail`";
        }


    return view('sampleorder', ["userlist"=>[],"doctoroptionlist"=>json_encode($doctoroptionlist),"customeroptionlist"=>json_encode($customeroptionlist),"skuoptionlist"=>json_encode($skuoptionlist),"statuslist"=>json_encode($statuslist)]);
   }


  public function getsampleorder(Request $data)
  {
    if($data['reference']!=""){
      $whereref = "and a.reference like '%".$data['reference']."%'";
    }else{
      $whereref = "and 1=1";
    }
    if($data['orderno']!=""){
      $whereorderno = "and a.orderno like '%".$data['orderno']."%'";
    }else{
      $whereorderno = "and 1=1";
    }

    if($data['hcp']!=""){
      $wherehcp = "and (a.doctorcode like '%".$data['hcp']."%') or (a.doctorname like '%".$data['hcp']."%')";
    }else{
      $wherehcp = "and 1=1";
    }
    if($data['customer']!=""){
      $wherecustomer = "and (a.shiptocode like '%".$data['customer']."%') or (a.shiptoname like '%".$data['customer']."%')";
    }else{
      $wherecustomer = "and 1=1";
    }
    if($data['product']!=""){
      $whereproduct = "and (productcode like '%".$data['product']."%') or (productname like '%".$data['product']."%')";
    }else{
      $whereproduct = "and 1=1";
    }
    
    if($data['status']!=""){
      $wherestatus = "and status in ( ".$data['status'].")";
    }else{
      $wherestatus = "and 1=1";
    }
    if(Auth::user()->territorytypeid==0){
      $where = "and 1=1";
    }elseif(Auth::user()->territorytypeid==1){
      if(Auth::user()->territoryid == 0){
        $where = "and 1=1";
      }else{
        $where = "and orderby = ".Auth::user()->id;
      }
      
    }elseif(Auth::user()->territorytypeid==2){
      $where = "and flmuserid = ".Auth::user()->id;
    }


    $userlist = DB::select(DB::raw("
     select distinct a.*,a.orderno as recid
     from `sales.view_order_sample` a
	join (
     select orderno from `sales.view_order_sample_detail` 
     where true
      "
      .$whereproduct.
      "
     ) b on a.orderno = b.orderno
        where true
        "
        .$where.
        "
        "
        .$wherestatus.
        "
        "
        .$whereref.
        "
        "
        .$whereorderno.
	"
	"
        .$wherehcp.
        "
        "
        .$wherecustomer.
	"
	order by orderdate desc
        ;"
    ));
    return response()->json($userlist);
  }


  public function getskulist2(Request $data)
  {
	 
    $productlist = array();
    $array = explode(',', $data['skulist']);
    $array2 = explode(',', $data['qtylist']);
    $array3 = explode(',', $data['batchnolist']);
	
          $querydate = DB::select(DB::raw("
            select year(orderdate) as yearorderdate from `sales.view_order_sample_detail`
            where orderno = '".$data['orderno']."'
            ;"
          ));
          if($data['orderno'] != ""){
            $yearorderdate = $querydate[0]->yearorderdate;
          }else{
            $yearorderdate = 'year(now())';
          }

    if ($data['skulist'] != "") {
      foreach ($array as $value => $val) {
          $query = DB::select(DB::raw("
            select a.*,ifnull(c.usedqty,0) as usedqty,b.qty as quotaqty,(b.qty-ifnull(c.usedqty,0)) as balqty,a.id as recid,d.productgroup from `master.product` a 
            left join `master.sample_quota` b on a.productgroupid = b.productgroupid
            left join `master.product_group` d on a.productgroupid = d.id
            left join (select sum(qty) as usedqty,productgroupid,year(orderdate) as year From `sales.view_order_sample_detail` where  status !=3 and orderno != '".$data['orderno']."' and doctorid = '".$data['doctorid']."'  	group by productgroupid,year(orderdate)) c on a.productgroupid = c.productgroupid  and c.year = '".$yearorderdate."'
                        where 1=1
            and a.id = ".$val."
            ;"
        ));
	//$query = DB::getQueryLog();
	//dd(DB::getQueryLog());
	//dd($data['orderno']);

        $productlist[$value] = (object) array( 'recid' => $val, 'Code' => $query[0]->Code, 'product' => $query[0]->Desc, 'productgroup' => $query[0]->productgroup,'balqty'=> $query[0]->balqty, 'qty' => str_replace("'", "", $array2[$value]), 'batchno' => str_replace("'", "", $array3[$value]) );
      }
    }   

	$query = DB::select(DB::raw("
            select a.*,id as recid from `sales.view_order_sample_detail` a 
            join (select distinct productgroupid,doctorid,orderdate from `sales.view_order_sample_detail` where orderno = '".$data['orderno']."' and year(orderdate) = '".$yearorderdate."') b on a.doctorid = b.doctorid and a.productgroupid = b.productgroupid and a.orderdate < b.orderdate
	    where a.orderno != '".$data['orderno']."' and a.status != '3'
		and year(a.orderdate) = '".$yearorderdate."'
            ;"
          ));
          $data['query']= $productlist;
          $data['query2']= $query;
    return response()->json($data);
  }


  public function checkquota(Request $data)
  {DB::enableQueryLog();
    $productlist = array();
    $array = explode(',', $data['skulist']);
    $array2 = explode(',', $data['qtylist']);
    $array3 = explode(',', $data['batchnolist']);
    $array4 = explode(',', $data['productbatchnolist']);

	$skuarray = [];
          $qtyarray = [];
          foreach ($array as $value => $val) {
            if(array_search($val,$skuarray) !== false){
              $qtyarray[array_search($val,$skuarray)] = $qtyarray[array_search($val,$skuarray)] + str_replace("'", "", $array2[$value]);
            }else{
              $skuarray[$value] = $array[$value];
              $qtyarray[$value] = str_replace("'", "", $array2[$value]);
            }
          }
    $productgroupqty = array();
    $productgroupbalqty = array();
    $productgroupname = array();

          $querydate = DB::select(DB::raw("
            select year(orderdate) as yearorderdate from `sales.view_order_sample_detail`
            where orderno = '".$data['orderno']."'
            ;"
          ));
          if($data['orderno'] != ""){
            $yearorderdate = $querydate[0]->yearorderdate;
          }else{
            $yearorderdate = 'year(now())';
          }
    if ($data['skulist'] != "") {
          /*$query = DB::select(DB::raw("
            select ifnull(c.usedqty,0) as usedqty,b.qty as quotaqty,(b.qty-ifnull(c.usedqty,0)) as balqty,d.id as recid,d.productgroup from `master.product_group` d
            left join `master.sample_quota` b on d.id = b.productgroupid
            left join (select sum(qty) as usedqty,productgroupid,year(orderdate) as year From `sales.view_order_sample_detail` where orderno != '".$data['orderno']."' and doctorid = '".$data['doctorid']."' group by productgroupid,year(orderdate)) c on b.productgroupid = c.productgroupid  and c.year = year(now())
            where 1=1
            and b.productgroupid in ( select productgroupid from `master.product` where id in (".$data['skulist']."))
            ;"
        ));*/
      foreach ($skuarray as $value => $val) {
        $query = DB::select(DB::raw("
          select a.*,ifnull(c.usedqty,0) as usedqty,b.qty as quotaqty,(b.qty-ifnull(c.usedqty,0)) as balqty,a.id as recid,d.productgroup,a.productgroupid from `master.product` a 
          left join `master.sample_quota` b on a.productgroupid = b.productgroupid
          left join `master.product_group` d on a.productgroupid = d.id
          left join (select sum(qty) as usedqty,productgroupid,year(orderdate) as year From `sales.view_order_sample_detail` where orderno != '".$data['orderno']."' and doctorid = '".$data['doctorid']."' and status != 3 group by productgroupid,year(orderdate)) c on a.productgroupid = c.productgroupid  and c.year = '".$yearorderdate."'
                      where 1=1
          and a.id = ".$val."
          ;"
        ));
        if(isset($productgroupqty[$query[0]->productgroupid])){
          $productgroupqty[$query[0]->productgroupid] = $productgroupqty[$query[0]->productgroupid] + str_replace("'", "", $qtyarray[$value]);
        }else{
          $productgroupqty[$query[0]->productgroupid] = str_replace("'", "", $qtyarray[$value]);
        }
        $productgroupbalqty[$query[0]->productgroupid] = $query[0]->balqty;
        $productgroupname[$query[0]->productgroupid] = $query[0]->productgroup;
      }
      $data['productgrouplist'] = DB::select(DB::raw("
        select distinct productgroupid from `master.product` where id in (".$data['skulist'].")
        ;"
      ));

      $data['customerinfo'] = DB::select(DB::raw("
        select * from `master.customer` where id = '".$data['customerid']."'
        ;"
      ));
      $data['productgroupqty'] = $productgroupqty;
      $data['productgroupbalqty'] = $productgroupbalqty;
      $data['productgroupname'] = $productgroupname;
      //$query = DB::getQueryLog();
      //dd(DB::getQueryLog());
      //dd($data['orderno']);
        $productlist = $data;
    }   


    return response()->json($productlist);
  }

  public function getbalqty(Request $data)
  {
	
      $query = DB::select(DB::raw("
        select (b.qty-ifnull(c.usedqty,0)) as balqty from `master.sample_quota` b
        left join (
          select sum(a.qty) as usedqty,a.productgroupid
          From `sales.view_order_sample_detail` a 
	  where 1 = 1 
	and status != 3
	and a.doctorid = '".$data['doctorid']."'
	
          and year(a.orderdate) = year(now())
          group by a.productgroupid
          ) c on b.productgroupid = c.productgroupid  
        where 1=1
         and b.productgroupid in (select productgroupid from `master.product` where Code = '".$data['codeno']."');
        
      "));
    return response()->json($query);
  }

  public function approvesampleorder(Request $data)
  {DB::beginTransaction();
        try {
    if($data['recid']!=""){
        $whereorderno = "and orderno = '".$data['recid']."'";
      }else{
        $whereorderno = "and 1=1";
      }
      $checkstatus = DB::select(DB::raw("
        select 
        * from 
        `sales.view_order_sample_detail`
        where true
        "
        .$whereorderno.
        "
        ;"
      ));
      if($checkstatus[0]->status == 1){
	      //$this->updatelog('Approve sample order');
    $query = DB::select(DB::raw("
      update `sales.order_sample`
      set 
      approveby = ".Auth::user()->id.",
      approvedate = now(),
      
      status = 2
      ,datemodified = now()
      ,modifiedby = '".Auth::user()->id."'
      where orderno = '".$data['recid']."'
      ;"
    ));

      if($data['recid']!=""){
        $whereorderno = "and orderno = '".$data['recid']."'";
      }else{
        $whereorderno = "and 1=1";
      }
      $query = DB::select(DB::raw("
        select 
        * from 
        `sales.view_order_sample_detail`
        where true
        "
        .$whereorderno.
        "
        ;"
      ));

	$check = DB::select(DB::raw("	
         select * from `sales.order_sample`
         where orderno = '".$data['recid']."'
         limit 1
         ;"
       ));
	$checkusr = DB::select(DB::raw("
         select * from `master_user`
         where id = '".$check[0]->orderby."'
         ;"
       ));
	
            $checkflmusr = DB::select(DB::raw("
             select * from `master_user`
             where id = '".Auth::user()->id."'
             ;"
           ));
      	//$emailorderby = 'hilmie@tinosstech.com';
        $emailorderby = $checkusr[0]->email;
	if($check[0]->countryid == 1){
        $email = 'rpa-order@zuelligpharma.com';
        //$email = 'hilmie@tinosstech.com';

        $spreadsheet = IOFactory::Load('sampleform.xlsx');
        $spreadsheet->getActiveSheet()->setCellValue('E8',$query[0]->orderbyname);
        $spreadsheet->getActiveSheet()->setCellValue('E9',$checkusr[0]->email);
        $spreadsheet->getActiveSheet()->setCellValue('E14',$query[0]->soldtocode);
        $spreadsheet->getActiveSheet()->setCellValue('F14',$query[0]->shiptocode);
        $spreadsheet->getActiveSheet()->setCellValue('G14',$query[0]->orderno);
        $spreadsheet->getActiveSheet()->setCellValue('H14',trim($query[0]->remark));
        $rowno = 16;
	foreach($query as $result) {
                $spreadsheet->getActiveSheet()->setCellValue('C'.$rowno,$result->productsapcode);
                $spreadsheet->getActiveSheet()->setCellValue('D'.$rowno,$result->qty);
                $spreadsheet->getActiveSheet()->setCellValue('J'.$rowno,$result->batchno);
                $rowno = $rowno + 1;
        }
        $writer = new Xlsx($spreadsheet);
        $fileName = 'Sample_Order_'.$data['orderno'].'_'.date("Y-m-d").'.xlsx';
        $file_path = public_path() .'/download/'.$fileName;
        $writer->save($file_path);
	
      $download_link = url($file_path);       
	}elseif($check[0]->countryid == 2){
        $email = ['zeom-sg@zuelligpharma.com','sgzpscallcentermailbox@zuelligpharma.com'];
        //$email = ['hilmie@tinosstech.com','hifzil.hilmie@hotmail.com'];

	

        $fileName = 'PECWEB_Bayer_SSO_'.date("YmdHis").'.csv';
        Excel::store(new SampleOrderExport($data['recid']), $fileName, 'public_download');
        $file_path = public_path() .'/download/'.$fileName;
        $download_link = url($file_path);

      }else{
        $email = 'hilmie@tinosstech.com';
      }


      $queryorder = DB::select(DB::raw("
         select * from `sales.view_order_sample_detail`
         where orderno = '".$data['recid']."'
         ;"
       )); 
      $details = [
        'fromname' => $checkusr[0]->username,
	'filename' => $file_path,
        'orderno' => $data['recid'] ,
        'queryorder' => $queryorder
      ];

      //$email = 'zeom-sg@zuelligpharma.com';
      //Mail::to($email)->cc(['support@tinosstech.com'])->send(new ApproveSampleOrderMail($details));
      //$ccemail = ['hifzil.hilmie@gmail.com','hifzil.hilmie@hotmail.com'];
      $ccemail = ['support@tinosstech.com',$checkusr[0]->email,$checkflmusr[0]->email];
      //dd($ccemail2);
      Mail::to($email)->cc($ccemail)->send(new ApproveSampleOrderMail($details));

      Mail::to($emailorderby)->send(new ApproveSampleOrderMailRespond($details));
      //$email2 = 'sgzpscallcentermailbox@zuelligpharma.com';
      //Mail::to($email2)->send(new ApproveSampleOrderMail($details));
     DB::commit(); 
         return Response()->json([
		 "success" => true,
		 "errormsg" => '',
             "file" => $download_link
         ]);
      }elseif($checkstatus[0]->status == 2){
        return Response()->json([
          'success' => false,
	  'errormsg' => 'Order already approved.',
	  'file' => ''
        ]);
      }elseif($checkstatus[0]->status == 3){
        return Response()->json([
          'success' => false,
	  'errormsg' => 'Order already rejected.',
	  'file' => ''
        ]);
      }else{
        return Response()->json([
          'success' => false,
	  'errormsg' => 'Error.',
	  'file' => ''
        ]);
      }
          }catch (\Exception $e) {
            DB::rollback(); // something went wrong
            return Response()->json([
              'success' => false,
	      'errormsg' => 'Error.',
            ]);
          }
  }

  public function rejectsampleorder(Request $data)
  {DB::beginTransaction();
        try {
    if($data['recid']!=""){
        $whereorderno = "and orderno = '".$data['recid']."'";
      }else{
        $whereorderno = "and 1=1";
      }
      $checkstatus = DB::select(DB::raw("
        select 
        * from 
        `sales.view_order_sample_detail`
        where true
        "
        .$whereorderno.
        "
        ;"
      ));
      if($checkstatus[0]->status == 1){
    //$this->updatelog('Approve sample order');
    $query = DB::select(DB::raw("
      update `sales.order_sample`
      set 
      rejectby = ".Auth::user()->id.",
      rejectdate = now(),
 
      status = 3
      ,datemodified = now()
      ,modifiedby = '".Auth::user()->id."'
      where orderno = '".$data['recid']."'
      ;"
    ));

    
    $check = DB::select(DB::raw("
       select * from `sales.order_sample`
       where orderno = '".$data['recid']."'
       limit 1
       ;"
     )); 
    $checkusr = DB::select(DB::raw("
       select * from `master_user`
       where id = '".$check[0]->orderby."'
       ;"
     )); 
    //$email = 'hilmie@tinosstech.com'; 
    $email = $checkusr[0]->email;
    $details = [
      'fromname' => Auth::user()->username,
      'toname' => $checkusr[0]->username,
      'orderno' => $data['recid']
    ];
    Mail::to($email)->send(new RejectSampleOrderMail($details));
    DB::commit();
    return Response()->json([
	    "success" => true,
	    "errormsg" => ''
    ]);
    }elseif($checkstatus[0]->status == 2){
        return Response()->json([
          'success' => false,
          'errormsg' => 'Order already approved.',
        ]);
      }elseif($checkstatus[0]->status == 3){
        return Response()->json([
          'success' => false,
          'errormsg' => 'Order already rejected.',
        ]);
      }else{
        return Response()->json([
          'success' => false,
          'errormsg' => 'Error.',
        ]);
      }
          }catch (\Exception $e) {
            DB::rollback(); // something went wrong
            return Response()->json([
              'success' => false,
              'errormsg' => 'Error.',
            ]);
          }
  }


      public function rejectsampleorderadmin(Request $data)
      {
        try {
          if($data['recid']!=""){
            $whereorderno = "and orderno = '".$data['recid']."'";
          }else{
            $whereorderno = "and 1=1";
          }
          $checkstatus = DB::select(DB::raw("
            select 
          * from 
            `sales.view_order_sample_detail`
            where true
            "
            .$whereorderno.
            "
            ;"
          ));
          if($checkstatus[0]->status == 2){
      //$this->updatelog('Approve sample order');
            $query = DB::select(DB::raw("
              update `sales.order_sample`
              set 
              rejectby = ".Auth::user()->id.",
              rejectdate = now(),
              remark = '".$data['remark']."',
              status = 3
              ,datemodified = now()
              ,modifiedby = '".Auth::user()->id."'
              where orderno = '".$data['recid']."'
              ;"
            ));
      //      $email = 'hilmie@tinosstech.com';
            $check = DB::select(DB::raw("
             select * from `sales.order_sample`
             where orderno = '".$data['recid']."'
             limit 1
             ;"
           )); 
            $checkusr = DB::select(DB::raw("
             select * from `master_user`
             where id = '".$check[0]->orderby."'
             ;"
           )); 

      $email = $checkusr[0]->email;
            $details = [
              'fromname' => Auth::user()->username,
              'toname' => $checkusr[0]->username,
              'orderno' => $data['recid']
            ];
            Mail::to($email)->send(new RejectSampleOrderMail($details));

            return Response()->json([
             "success" => true,
             "errormsg" => ''
           ]);
          }else{
            return Response()->json([
              'success' => false,
              'errormsg' => 'Error.',
            ]);
          }

        return Response()->json([
          'success' => true,
          'errormsg' => '',
        ]);

        }catch (\Exception $e) {
          return Response()->json([
            'success' => false,
            'errormsg' => 'Error.',
          ]);
        }
      }

  public function savesampleorder(Request $data)
  { DB::beginTransaction();
        try {
    $data['productlist'] = str_replace("'","",$data['productlist']);
    if($data['recid']!=""){
      //$this->updatelog('Update sample order');
      $orderdate = ($data['orderdate'] == null) ? "null" : "'".$data['orderdate']."'";
      $array = explode(',', $data['productlist']);
      $array2 = explode(',', $data['qtylist']);
            $array3 = explode(',', $data['batchnolist']);

      foreach ($array as $val => $row){
        $check = DB::select(DB::raw("
           select * from `sales.order_sample`
           where productid = '".$row."'
           and orderno = '".$data['recid']."'
           ;"
         ));
	if(count($check)>0){
    		
          $checkcountry = DB::select(DB::raw("
             select * from `master.customer`
             where id = '".(int)$data['customerid'] ."'
             ;"
          ));  		
          $query = DB::select(DB::raw("
            update `sales.order_sample`
            set reference = '".$data['reference']."',
            orderdate = '".$data['orderdate']."',
            orderby = '".$check[0]->orderby."',
            countryid = '".$checkcountry[0]->countryid."',
	    doctorid = '".(int)$data['doctorid']."',
            customerid = '".(int)$data['customerid']."',
            qty = '".str_replace("'", "", $array2[$val])."',
                  batchno = '".str_replace("'", "", $array3[$val])."',
            unitprice = '0',
            remark = '".$data['remark']."',
            datemodified = now(),
            modifiedby = ".Auth::user()->id.",
            status = ".(int)$data['status']."
            where id = '".$check[0]->id."'
            ;"
          ));
        }else{
          $checkorder = DB::select(DB::raw("
             select * from `sales.order_sample`
             where orderno = '".$data['recid']."'
             ;"
           ));
	
          $checkcountry = DB::select(DB::raw("
             select * from `master.customer`
             where id = '".(int)$data['customerid'] ."'
             ;"
          ));  
          $query = DB::select(DB::raw("
	    insert into `sales.order_sample` 
(id, trkno, orderno, orderdate, orderby, approveby, approvedate, rejectby, rejectdate, reference, countryid, customerid, doctorid, productid, qty, unitprice, remark, datecreated, datemodified, createdby, modifiedby, status,batchno)
values (null,'".$checkorder[0]->trkno."','".$checkorder[0]->orderno."','".$data['orderdate']."','".Auth::user()->id."',0,null,0,null,'".$data['reference']."','".$checkcountry[0]->countryid."','".(int)$data['customerid']."','".(int)$data['doctorid']."','".$row."','".str_replace("'", "", $array2[$val])."',0,'".str_replace("'","\'",$data['remark'])."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."','".(int)$data['status']."','".str_replace("'", "", $array3[$val])."')
            ;"
          ));
        }
        $checkremove = DB::select(DB::raw("
           delete from `sales.order_sample`
           where productid not in (".$data['productlist'].")
           and orderno = '".$data['recid']."'
           ;"
         ));
      }
      $orderno = $data['recid'];
    }else{
      //$this->updatelog('Insert sample order');
      $orderdate = ($data['orderdate'] == null) ? "null" : "'".$data['orderdate']."'";
      $array = explode(',', $data['productlist']);
      $array2 = explode(',', $data['qtylist']);
            $array3 = explode(',', $data['batchnolist']);
      
      $gettrkno = DB::select(DB::raw("
         select max(trkno) as trkno from `sales.order_sample`
         ;"
      ));
      $trkno = $gettrkno[0]->trkno+1;
      $orderno = 'ODR'.str_pad($trkno, 6, '0', STR_PAD_LEFT);
	
          $checkcountry = DB::select(DB::raw("
             select * from `master.customer`
             where id = '".(int)$data['customerid'] ."'
             ;"
          ));  

      foreach ($array as $val => $row){
          $query = DB::select(DB::raw("
	    insert into `sales.order_sample` 
(id, trkno, orderno, orderdate, orderby, approveby, approvedate, rejectby, rejectdate, reference, countryid, customerid, doctorid, productid, qty, unitprice, remark, datecreated, datemodified, createdby, modifiedby, status,batchno)
values (null,'".$trkno."','".$orderno."','".$data['orderdate']."','".Auth::user()->id."',0,null,0,null,'".$data['reference']."','".$checkcountry[0]->countryid."','".(int)$data['customerid']."','".(int)$data['doctorid']."','".$row."','".str_replace("'", "", $array2[$val])."',0,'".str_replace("'","\'",$data['remark'])."',now(),now(),'".Auth::user()->id."','".Auth::user()->id."','".(int)$data['status']."','".str_replace("'", "", $array3[$val])."')
            ;"
          ));
        
      }
    }
    if((int)$data['status']==1){
      
      $usrid = Auth::user()->id;
      //$usrid = 41;
      $check = DB::select(DB::raw("
         select * from `master.view_map_approver`
         where mruserid = '".$usrid."'
         ;"
       )); 
      //$email = 'hilmie@tinosstech.com'; 
      $email = $check[0]->approveremail;
      $queryorder = DB::select(DB::raw("
         select * from `sales.view_order_sample_detail`
         where orderno = '".$orderno."'
         ;"
       ));

     	$querydate = DB::select(DB::raw("
            select year(orderdate) as yearorderdate from `sales.view_order_sample_detail`
            where orderno = '".$orderno."'
            ;"
          ));
        
            $yearorderdate = $querydate[0]->yearorderdate;

          $queryhistory = DB::select(DB::raw("
            select a.*,id as recid from `sales.view_order_sample_detail` a
            join (select distinct productgroupid,doctorid,orderdate from `sales.view_order_sample_detail` where orderno = '".$orderno."'  and year(orderdate) = '".$yearorderdate."') b on a.doctorid = b.doctorid and a.productgroupid = b.productgroupid and a.orderdate < b.orderdate
	    where a.orderno != '".$orderno."' and a.status != '3'
	and year(a.orderdate) = '".$yearorderdate."'
            ;"
          ));


      $approveurllink = URL::temporarySignedRoute(
          'approvesampleorder', now()->addHours(48), ['orderno' => $orderno, 'approveby' => $check[0]->approveruserid]
      );
      $rejecturllink = URL::temporarySignedRoute(
          'rejectsampleorder', now()->addHours(48), ['orderno' => $orderno, 'rejectby' => $check[0]->approveruserid]
      );
      $details = [
        'fromname' => Auth::user()->username,
        'toname' => $check[0]->approvername,
        'orderno' => $orderno ,
        'queryorder' => $queryorder ,
        'queryhistory' => $queryhistory ,
        'approveurllink' => $approveurllink,
        'rejecturllink' => $rejecturllink
      ];

            if($check[0]->flmuserid==377){
              //$ccemail = ['support@tinosstech.com','hilmie@tinosstech.com'];
              $ccemail = ['support@tinosstech.com','sabrina.chew@bayer.com'];
            }else{
              $ccemail = ['support@tinosstech.com'];
            }
            Mail::to($email)->cc($ccemail)->send(new SampleOrderMail($details));
      //Mail::to($email)->send(new SampleOrderMail($details));
    }
    
	
    
            DB::commit();
            return Response()->json([
              'success' => true,
              'errormsg' => '',
            ]);
          }catch (\Exception $e) {
            DB::rollback(); // something went wrong
            return Response()->json([
              'success' => false,
              'errormsg' =>  'Error.',
              'errormsg2' =>  $e->getMessage(),
            ]);
          }

  }

  public function exportsampleorder(Request $data)
  {
    $this->updatelog('Export sampleorder');
    $fileName = 'sampleorder_'.date("Y-m-d").'.xlsx';

     Excel::store(new sampleorderExport($data['sampleorderref'],$data['institution'],$data['typeid'],$data['agentid'],$data['status']), $fileName, 'public_download');
     $file_path = '/download/'.$fileName;
     $download_link = url($file_path);

     return Response()->json([
         "success" => true,
         "file" => $download_link
     ]);
   }


  public function addsampleorder(Request $data)
  {
    $this->updatelog('Update user');
    if ($data['replace'] === "1") {
      $query = DB::select(DB::raw(
        "
        update `master_user`
        set status = '0'
        where territorytypeid = '".(int)$data['territorytypeid']."' AND territoryid = '".(int)$data['territoryid']."' AND status = '1'
        ;"
      ));
    }
    $datejoined = ($data['datejoined'] == null) ? "null" : "'".$data['datejoined']."'";
    $dateresigned = ($data['dateresigned'] == null) ? "null" : "'".$data['dateresigned']."'";

    $query = DB::select(DB::raw("
      insert into `master_user`
      (id, title, username, territorytypeid, territoryid, staffid, email, rptpermissionid, accesslevel, datejoined, dateresigned, sendpassword, status,sendemail)
      VALUES
      (null, '".$data['title']."', '".$data['username']."', '".(int)$data['territorytypeid']."', '".(int)$data['territoryid']."', '".$data['staffid']."', '".$data['email']."',
      '".(int)$data['rptpermissionid']."', '".(int)$data['accesslevel']."', ".$datejoined.", ".$dateresigned.", '1', '1','1')
    ;"
    ));


    return response()->json('success');

  }


  public function specialist()
   {
     $this->updatelastlogin();

     $this->updatelog('View specialist');
     return view('specialist', ["productlist"=>[]]);
   }


  public function getspecialist(Request $data)
  {
    if($data['specialist']!=""){
      $wherespecialist = "and a.specialist like '%".$data['specialist']."%'";
    }else{
      $wherespecialist = "and 1=1";
    }

    $productlist = DB::select(DB::raw("
      select *,id as recid from `master.specialist` a
      where true
      "
      .$wherespecialist.
      "
      ;"
    ));
    return response()->json($productlist);
  }

  public function savespecialist(Request $data)
  {
    $this->updatelog('Update sales line');
    if($data['id']!=""){
      $query = DB::select(DB::raw("
        update `master.specialist`
        set specialist = '".$data['specialist']."',
        modifiedby = '".Auth::user()->id."',
        datemodified = now()
        where id = '".$data['id']."'
      ;"
      ));
    }else{
      $query = DB::select(DB::raw("
        insert into `master.specialist`
        VALUES
        (null,'".$data['specialist']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1)
      ;"
      ));
    }
    return response()->json('success');
  }


  public function fieldofpractice()
   {
     $this->updatelastlogin();

     $this->updatelog('View field of practice');
     return view('fieldofpractice', ["productlist"=>[]]);
   }


  public function getfieldofpractice(Request $data)
  {
    if($data['fieldofpractice']!=""){
      $wherefieldofpractice = "and a.fieldofpractice like '%".$data['fieldofpractice']."%'";
    }else{
      $wherefieldofpractice = "and 1=1";
    }

    $productlist = DB::select(DB::raw("
      select *,id as recid from `master.field_of_practice` a
      where true
      "
      .$wherefieldofpractice.
      "
      ;"
    ));
    return response()->json($productlist);
  }

  public function savefieldofpractice(Request $data)
  {
    $this->updatelog('Update sales line');
    if($data['id']!=""){
      $query = DB::select(DB::raw("
        update `master.field_of_practice`
        set fieldofpractice = '".$data['fieldofpractice']."',
        modifiedby = '".Auth::user()->id."',
        datemodified = now()
        where id = '".$data['id']."'
      ;"
      ));
    }else{
      $query = DB::select(DB::raw("
        insert into `master.field_of_practice`
        VALUES
        (null,'".$data['fieldofpractice']."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1)
      ;"
      ));
    }
    return response()->json('success');
  }


  public function approvesampleresult(Request $data)
  {
    return view('approvesampleresult');
  }
  public function rejectsampleresult(Request $data)
  {
    return view('rejectsampleresult');
  }

  public function testtemplate()
       {
         //drop down list
         //$this->updatelog('View sample oder');
         $query = DB::select(DB::raw("
             SELECT *
             FROM `sales.view_order_sample_detail`
             where true
             and orderno = 'ODR000012'
             ;"
         ));
    return view('sampletemplate', ["query"=>$query]);
   }
	
       
       public function mapapprover()
       {
          $this->updatelog('View Map Approver');
          $data = DB::select(DB::raw("
            select *,id as recid from `master.view_team`  order by username
           ;"
         ));

         return view('mapapprover', ["jsondata"=>json_encode($data)]);
       }


       public function getmapapprover(Request $data)
       {

        if($data['flmuserid']!=""){
          $whereflmuserid = "and flmuserid = '".$data['flmuserid']."'";
        }else{
          $whereflmuserid = "and 1=1";
        }
        $data = DB::select(DB::raw("
          select *,id as recid from
          `master.view_map_approver` 
          where true
          ".$whereflmuserid."
          order by mrname
          ;"
        ));
        return response()->json($data);
        }


      public function deletemapapprover(Request $data)
      {

        $this->updatelog('Delete Map Approver');
        if($data['id']!=""){
          $whereid = "and id = '".$data['id']."'";

          $data = DB::select(DB::raw("
            delete from `master.map_approver`
            where true
            ".$whereid."
            ;"
          ));
        }
        return response()->json($data);
      }


      public function getmapapproverlist()
      {
        $data = DB::select(DB::raw("
           select territoryid as recid,mrcode,mrname
           from
           `master.view_map_approver` 
           where true
           order by mrcode
          ;"
        ));
        return response()->json($data);
      }

      public function getmapapproverlist2(Request $data)
      {
        $data = DB::select(DB::raw("
            select *,id as recid 
            from `master.view_territory` 
            where id not in (select mruserid from `master.map_approver`) 
            order by username
          ;"
        ));
        return response()->json($data);
      }

      public function savemapapprover(Request $data)
      {
        $this->updatelog('Update Map Approver');
        $flmuserid = $data['flmuserid'];
        $mruseridlist = $data['mruseridlist'];
        foreach ($mruseridlist as $value => $val) {
          $query = DB::select(DB::raw("
            insert into `master.map_approver` values (null,'".$flmuserid."','".$val."','".Auth::user()->id."','".Auth::user()->id."',now(),now(),1);
          "));
        }
        

        return response()->json('success');
      }
}
