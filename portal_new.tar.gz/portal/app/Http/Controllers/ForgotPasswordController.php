<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Routing\Redirector;

class ForgotPasswordController extends Controller
{
    public function forgotpassword() {
        return view('forgotpassword');
    }

    public function checkemail(Request $data)
    {
      $query = DB::select(DB::raw("
        select * from `master.user`
        where email = '".$data['email']."'
        and status = 1
        ;"
      ));
      $error = 0;
      if (is_countable($query) && count($query) > 0){
        $error1msg = '';
      }
      else{
        $error = $error + 1;
        $error1msg = 'Email not found.';
      }

      if($error > 0){
       return Response()->json([
           'success' => false,
           'error1msg' => $error1msg
       ]);
      }else{

         return Response()->json([
             'success' => true,
             'error1msg' => ''
         ]);

     }

    }
    public function resetpassword($email){
        return view('resetpassword',["email"=>$email]);
    }


    public function updatepassword2(Request $data)
    {
       $error = 0;

       if (!preg_match('/[\'~!^£$%&*()}{@#~?><>,|=_+¬-]/', $data['newpassword'])){
           $error = $error + 1;
           $error1msg = '<p>At least one special character (~!^£$%&*()}{@#~?>...).</p>';
       }else{
           $error1msg = '';
       }
       if ($data['newpassword']!=$data['confirmpassword']) {
           $error = $error + 1;
           $error2msg = '<p>Confirm password not match.</p>';
       }else{
           $error2msg = '';
       }


       if (strlen($data['newpassword']) >= 6){
           $error3msg = '';
       }else{
           $error = $error + 1;
           $error3msg = '<p>At least 6 characters long.</p>';
       }

       if(preg_match("/[A-Z]/", $data['newpassword'])){
           $error4msg = '';
       }else{
           $error = $error + 1;
           $error4msg = '<p>At least one upper case letter.</p>';
       }

       if (preg_match('~[0-9]~', $data['newpassword'])) {
           $error5msg = '';
       }else{
           $error = $error + 1;
           $error5msg = '<p>At least one number.</p>';
       }

       $query = DB::select(DB::raw("
         select * from `master.user`
         where email = '".$data['email']."'
         and status = 1
         ;"
       ));

       if ($data['resetpassword']!=$query[0]->resetpassword) {
           $error = $error + 1;
           $error6msg = '<p>Invalid verification code.</p>';
       }else{
           $error6msg = '';
       }
       if($error > 0){
         return Response()->json([
             'success' => false,
             'error1msg' => $error1msg,
             'error2msg' => $error2msg,
             'error3msg' => $error3msg,
             'error4msg' => $error4msg,
             'error5msg' => $error5msg,
             'error6msg' => $error6msg
         ]);
       }else{
         $query = DB::select(DB::raw("
           update `master.user`
           set password = '".Hash::make($data['newpassword'])."',
           lastupdatepassword = now()
           where id = '".$query[0]->id."'
           ;"
         ));
         return Response()->json([
             'success' => true,
             'error1msg' => '',
             'error2msg' => '',
             'error3msg' => '',
             'error4msg' => '',
             'error5msg' => '',
             'error6msg' => ''
         ]);
     }

    }
}
