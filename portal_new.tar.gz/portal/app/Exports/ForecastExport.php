<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class ForecastExport implements WithMultipleSheets
{

    use Exportable;

    private $period;
    private $year;
    private $mrid;
    private $productgroupid;

    public function __construct( $year,  $period,  $mrid,  $productgroupid)
      {
          $this->period = $period;
          $this->year  = $year;
          $this->mrid  = $mrid;
          $this->productgroupid  = $productgroupid;
      }
    public function sheets(): array
      {
         $sheets = [];

         $sheets[] = new ForecastSheet1Export($this->year, $this->period, $this->mrid, $this->productgroupid);
         $sheets[] = new ForecastSheet2Export($this->year, $this->period);

         return $sheets;
      }
}
?>
