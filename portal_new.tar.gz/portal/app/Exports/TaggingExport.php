<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class TaggingExport implements WithMultipleSheets
{

    use Exportable;

    private $state;
    private $shiptocode;
    private $productgroupid;

    public function __construct( $state,  $shiptocode,  $productgroupid)
      {
          $this->state = $state;
          $this->shiptocode  = $shiptocode;
          $this->productgroupid  = $productgroupid;
      }
    public function sheets(): array
      {
         $sheets = [];

         $sheets[] = new TaggingSheet1Export($this->state, $this->shiptocode, $this->productgroupid);
         $sheets[] = new TaggingSheet2Export();

         return $sheets;
      }
}
?>
