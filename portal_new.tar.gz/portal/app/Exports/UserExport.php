<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Auth;
use DB;

class UserExport implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    use Exportable;

    private $title;
    private $username;
    private $territorytypeid;

      public function __construct($title,$username,$territorytypeid)
      {
          $this->title  = $title;
          $this->username  = $username;
          $this->territorytypeid  = $territorytypeid;
      }

      public function array(): array
      {
          if($this->title!=""){
            $wheretitle = "and a.title in ( ".$this->title.")";
          }else{
            $wheretitle = "and 1=1";
          }
         if($this->username!=""){
           $whereusername = "and a.username like '%".$this->username."%'";
         }else{
           $whereusername = "and 1=1";
         }
          if($this->territorytypeid!=""){
            $whereterritorytypeid = "and a.territorytypeid in ( ".$this->territorytypeid.")";
          }else{
            $whereterritorytypeid = "and 1=1";
          }

          $userlist = DB::select(DB::raw("
            select  CASE a.territorytypeid
                when '1' then 'NSM'
                when '2' then 'FLM'
                when '3' then 'MR'
                when '0' then 'Unknow'
             END as territorytype,
             CASE a.territorytypeid
                when '1' then f.nsmcode
                when '2' then e.flmcode
                when '3' then d.mrcode
                when '0' then ''
             END as `code`,
             a.staffid,a.title,a.username, a.fullname, a.datejoined, a.dateresigned,a.email,
             CASE a.status when '1' then 'Active' when '0' then 'Inactive' END as status,a.last_login,
             b.description,
             if(g.access1= 1,'Yes','No') as asscess1,
             if(g.access2= 1,'Yes','No') as asscess2,
             if(g.access3= 1,'Yes','No') as asscess3,
             if(g.access4= 1,'Yes','No') as asscess4,
             if(g.access5= 1,'Yes','No') as asscess5,
             if(g.access6= 1,'Yes','No') as asscess6,
             if(g.access7= 1,'Yes','No') as asscess7,
             if(g.access8= 1,'Yes','No') as asscess8,
             if(g.access9= 1,'Yes','No') as asscess9,
             if(g.access10= 1,'Yes','No') as asscess10,
             if(g.access11= 1,'Yes','No') as asscess11,
             if(g.access12= 1,'Yes','No') as asscess12,
             if(g.access13= 1,'Yes','No') as asscess13,
             if(g.access14= 1,'Yes','No') as asscess14,
             if(g.access15= 1,'Yes','No') as asscess15,
             if(g.access16= 1,'Yes','No') as asscess16
             From `master_user` a
             left join `master.report_permission` b on a.rptpermissionid = b.id
             left join `master.territory_mr` d on a.territoryid = d.id
             left join `master.territory_flm` e on a.territoryid = e.id
             left join `master.territory_nsm` f on a.territoryid = f.id
             LEFT JOIN (SELECT
            `b`.`userid` AS `userid`,
                SUM(IF((`b`.`accessid` = 1), 1, 0)) AS `access1`,
                SUM(IF((`b`.`accessid` = 2), 1, 0)) AS `access2`,
                SUM(IF((`b`.`accessid` = 3), 1, 0)) AS `access3`,
                SUM(IF((`b`.`accessid` = 4), 1, 0)) AS `access4`,
                SUM(IF((`b`.`accessid` = 5), 1, 0)) AS `access5`,
                SUM(IF((`b`.`accessid` = 6), 1, 0)) AS `access6`,
                SUM(IF((`b`.`accessid` = 7), 1, 0)) AS `access7`,
                SUM(IF((`b`.`accessid` = 8), 1, 0)) AS `access8`,
                SUM(IF((`b`.`accessid` = 9), 1, 0)) AS `access9`,
                SUM(IF((`b`.`accessid` = 10), 1, 0)) AS `access10`,
                SUM(IF((`b`.`accessid` = 11), 1, 0)) AS `access11`,
                SUM(IF((`b`.`accessid` = 12), 1, 0)) AS `access12`,
                SUM(IF((`b`.`accessid` = 13), 1, 0)) AS `access13`,
                SUM(IF((`b`.`accessid` = 14), 1, 0)) AS `access14`,
                SUM(IF((`b`.`accessid` = 15), 1, 0)) AS `access15`,
                SUM(IF((`b`.`accessid` = 16), 1, 0)) AS `access16`
        FROM
            (`master.portal_access` `a`
        LEFT JOIN `master.portal_access_mapping` `b` ON ((`a`.`id` = `b`.`accessid`)))
        WHERE
            (`b`.`userid` IS NOT NULL)
        GROUP BY `b`.`userid`) `g` ON `a`.`id` = `g`.`userid`
             left join (
                SELECT userid,GROUP_CONCAT(accessid SEPARATOR ',') as accessmodule
                FROM `master.portal_access_mapping`
                where status = 1
                GROUP BY userid
              ) c on a.id = c.userid
                where true
              "
              .$wheretitle.
              "
              "
              .$whereusername.
              "
              "
              .$whereterritorytypeid.
              "
              ;"
          ));

        $this->maxrow  = count($userlist) + 1;
        return $userlist;
      }
      public function headings(): array
      {
          return [
            'Territory Type'	,
            'Territory Code'	,
            'Staff ID'	,
            'Title'	,
            'User Name'	,
            'Full Name'	,
            'Date Joined'	,
            'Date Resigned'	,
            'Email'	,
            'Status'	,
            'last_login'	,
            'Report Permission',
            'Dashboard',
            'Dashboard (HQ)',
            'Dashboard (KA)',
            'Dashboard (LKA)',
            'FC Accuracy',
            'Sales Forecast',
            'Sales Target',
            'Company Target',
            'KA Target',
            'Sales Mapping',
            'Retag Sales Mapping',
            'Daily Invoice',
            'Customer',
            'User',
            'Report Permission',
            'Product'

          ];
      }

      public function registerEvents(): array
      {
          return [
              AfterSheet::class    => function(AfterSheet $event) {
                  // All headers - set font size to 14
                  //$cellRange = 'A1:W1';
                  //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                  // Apply array of styles to B2:G8 cell range
                  $styleArray = [
                      'borders' => [
                          'allBorders' => [
                              'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                          ]
                      ]
                  ];
                  $event->sheet->getDelegate()->getStyle('A1:AB'.$this->maxrow)->applyFromArray($styleArray);

                  //$event->sheet->getDelegate()->getStyle('A1:A'.$this->maxrow)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);
                  //$event->sheet->getDelegate()->getStyle('C1:C'.$this->maxrow)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);
                  //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                  // Set first row to height 20
                  //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                  // Set A1:D4 range to wrap text in cells
                  //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
              },
          ];
      }
}
?>
