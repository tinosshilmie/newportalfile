<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Auth;
use DB;

class DailyInvoiceExport implements FromArray, WithHeadings
{

    use Exportable;

    private $year;
    private $period;
    private $mrid;
    private $flmid;
    private $productgroupid;
    private $channelid;
    private $buid;
    private $subchannel2id;
    private $sourceid;
    private $tagging;

    public function __construct( $year,$period,$mrid,$flmid,$productgroupid,$channelid,$buid,$subchannel2id,$sourceid,$tagging)
      {
          $this->year  = $year;
          $this->period  = $period;
          $this->mrid  = $mrid;
          $this->flmid  = $flmid;
          $this->productgroupid  = $productgroupid;
          $this->channelid  = $channelid;
          $this->buid  = $buid;
          $this->subchannel2id  = $subchannel2id;
          $this->sourceid  = $sourceid;
          $this->tagging  = $tagging;
      }
      public function array(): array
      {
        if(Auth::user()->territorytypeid==0){
            $where = "and 1=1";
          }elseif(Auth::user()->territorytypeid==1){
            $where = "and nsmid = ".Auth::user()->territoryid;
          }elseif(Auth::user()->territorytypeid==2){
            $where = "and flmid = ".Auth::user()->territoryid;
          }elseif(Auth::user()->territorytypeid==3){
            $where = "and mrid = ".Auth::user()->territoryid;
          }
          if($this->year!=""){
            $whereyear = "and a.year in ( ".$this->year.")";
          }else{
            $whereyear = "and 1=1";
          }
          if($this->period!=""){
            $whereperiod = "and a.period in ( ".$this->period.")";
          }else{
            $whereperiod = "and 1=1";
          }

         if($this->mrid!=""){
           $wheremr = "and a.mrid in ( ".$this->mrid.")";
         }else{
           $wheremr = "and 1=1";
         }

         if($this->flmid!=""){
           $whereflm = "and a.flmid in ( ".$this->flmid.")";
         }else{
           $whereflm = "and 1=1";
         }

         if($this->productgroupid!=""){
           $whereproductgroup = "and a.productgroupid in ( ".$this->productgroupid.")";
         }else{
           $whereproductgroup = "and 1=1";
         }

        if($this->channelid!=""){
          $wherechannel = "and a.channelid in ( ".$this->channelid.")";
        }else{
          $wherechannel = "and 1=1";
        }
        if($this->buid!=""){
          $wherebu = "and a.buid in ( ".$this->buid.")";
        }else{
          $wherebu = "and 1=1";
        }
        if($this->subchannel2id!=""){
          $wheresubchannel2 = "and a.subchannel2id in ( ".$this->subchannel2id.")";
        }else{
          $wheresubchannel2 = "and 1=1";
        }
        if($this->sourceid!=""){
          $wheresource = "and a.sourceid in ( ".$this->sourceid.")";
        }else{
          $wheresource = "and 1=1";
        }

        if($tagging==1){
          $invoicelist = DB::select(DB::raw("

           select  year	,
                   period	,
                   invoicedate	,
                   invoiceno	,
                   transactiontype	,
                   shiptocode	,
                   shiptoname	,
                   address1	,
                   address2	,
                   address3	,
                   state	,
                   postalcode	,
                   imschannel1	,
                   imschannel2	,
                   localgroup1	,
                   localgroup2	,
                   localgroup3	,
                   channel	,
                   subchannel1	,
                   subchannel2	,
                   subchannel3	,
                   bu	,
                   productcategory	,
                   productgroup	,
                   productcode	,
                   product	,
                   qty	,
                   foc	,
                   sls	,
                   datasource	,
                   nsmcode	,
                   nsmname	,
                   flmcode	,
                   flmname	,
                   mrcode	,
                   mrname	,
                   salesline,
                   seq	 From`sales.rpt_invoice_trail` a
              where true
              and a.ffyear in (select max(year) as year from `sales.invoice`)
              ".$where."
              "
              .$whereyear.
              "
              "
              .$whereperiod.
              "
              "
              .$wheremr.
              "
              "
              .$whereflm.
              "
              "
              .$whereproductgroup.
              "
              "
              .$wherechannel.
              "
              "
              .$wherebu.
              "
              "
              .$wheresubchannel2.
              "
              "
              .$wheresource.
              "
              order by invoicedate
          ;"));
        }else{
          $invoicelist = DB::select(DB::raw("

           select  year	,
                   period	,
                   invoicedate	,
                   invoiceno	,
                   transactiontype	,
                   shiptocode	,
                   shiptoname	,
                   address1	,
                   address2	,
                   address3	,
                   state	,
                   postalcode	,
                   imschannel1	,
                   imschannel2	,
                   localgroup1	,
                   localgroup2	,
                   localgroup3	,
                   channel	,
                   subchannel1	,
                   subchannel2	,
                   subchannel3	,
                   bu	,
                   productcategory	,
                   productgroup	,
                   productcode	,
                   product	,
                   qty	,
                   foc	,
                   sls	,
                   datasource	,
                   nsmcode	,
                   nsmname	,
                   flmcode	,
                   flmname	,
                   mrcode	,
                   mrname	,
                   salesline,
                   seq	 From
                   (select * from `sales.view_invoice_dtl` a
                   where true
                   and shared=0
                   ".$where."
                   "
                   .$whereyear.
                   "
                   "
                   .$whereperiod.
                   "
                   "
                   .$wheremr.
                   "
                   "
                   .$whereflm.
                   "
                   "
                   .$whereproductgroup.
                   "
                   "
                   .$wherechannel.
                   "
                   "
                   .$wherebu.
                   "
                   "
                   .$wheresubchannel2.
                   "
                   "
                   .$wheresource.
                   "
                   ".$whereseq."
                    union all
                    select * from `sales.view_shared_invoice_dtl` a
                    where true
                    ".$where."
                    "
                    .$whereyear.
                    "
                    "
                    .$whereperiod.
                    "
                    "
                    .$wheremr.
                    "
                    "
                    .$whereflm.
                    "
                    "
                    .$whereproductgroup.
                    "
                    "
                    .$wherechannel.
                    "
                    "
                    .$wherebu.
                    "
                    "
                    .$wheresubchannel2.
                    "
                    "
                    .$wheresource.
                    "
                    ".$whereseq."
                    )
                    a
              where true

              order by invoicedate
          ;"));
        }

        $this->maxrow  = count($invoicelist) + 1;
        return $invoicelist;
      }
      public function headings(): array
      {
          return [
            'Year'	,
            'Period'	,
            'Invoice Date'	,
            'Invoice No'	,
            'Transaction Type'	,
            'Ship To Code'	,
            'Ship To Name'	,
            'Address 1'	,
            'Address 2'	,
            'Address 3'	,
            'State'	,
            'Postcode'	,
            'IMS Channel 1'	,
            'IMS Channel 2'	,
            'Local Group 1'	,
            'Local Group 2'	,
            'Local Group 3'	,
            'Channel'	,
            'Sub Channel 1'	,
            'Sub Channel 2'	,
            'Sub Channel 3'	,
            'BU'	,
            'Product Category'	,
            'Product Group'	,
            'Product Code'	,
            'Product Name'	,
            'Qty'	,
            'FOC'	,
            'SLS'	,
            'Datasource'	,
            'NSM Code'	,
            'NSM Name'	,
            'FLM Code'	,
            'FLM Name'	,
            'MR Code'	,
            'MR Name'	,
            'Sales Line',
            'Seq'
          ];
      }

      public function registerEvents(): array
      {
          return [
              AfterSheet::class    => function(AfterSheet $event) {
                  // All headers - set font size to 14
                  //$cellRange = 'A1:W1';
                  //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                  // Apply array of styles to B2:G8 cell range
                  $styleArray = [
                      'borders' => [
                          'allBorders' => [
                              'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                          ]
                      ]
                  ];
                  $event->sheet->getDelegate()->getStyle('A1:AL'.$this->maxrow)->applyFromArray($styleArray);
                  //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                  // Set first row to height 20
                  //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                  // Set A1:D4 range to wrap text in cells
                  //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
              },
          ];
      }
}
?>
