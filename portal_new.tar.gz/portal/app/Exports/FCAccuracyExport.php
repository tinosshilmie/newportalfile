<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class FCAccuracyExport implements WithMultipleSheets
{

    use Exportable;

    private $year;

    public function __construct( $year)
      {
          $this->year  = $year;
      }
    public function sheets(): array
      {
         $sheets = [];

         $sheets[] = new FCAccuracySheet1Export($this->year);
         $sheets[] = new FCAccuracySheet2Export($this->year);

         return $sheets;
      }
}
?>
