<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Auth;
use DB;

class SampleOrderExport implements FromArray
{

    use Exportable;

    private $orderno;

      public function __construct($orderno)
      {
          $this->orderno  = $orderno;
      }

      public function array(): array
      {
          if($this->orderno!=""){
            $whereorderno = "and orderno = '".$this->orderno."'";
          }else{
            $whereorderno = "and 1=1";
          }
          $userlist = DB::select(DB::raw("		
		select
              '' as a,'ZPSG_ECWEB',2601,'ZPFB','810','' as b,10,'00','EDP',
              '' as c,'' as d,'' as e,'' as f,shiptocode,DATE_FORMAT(DATE_ADD(orderdate, INTERVAL 2 DAY), '%Y%m%d') as deliverydate,orderno,DATE_FORMAT(orderdate, '%Y%m%d'),orderbyname,'' as g,productsapcode,'' as h,'' as i,qty,'' as j,'' as k,'' as l,'' as m,'' as n,'' as o,'' as p,'' as q,batchno,'' as s,remark2 as remark,'' as t,'' as u from
              `sales.view_order_sample_detail`
              where true
		  "
              .$whereorderno.
              "
              ;"
          ));

        $this->maxrow  = count($userlist) + 1;
        return $userlist;
      }
      

      public function registerEvents(): array
      {
          return [
              /*AfterSheet::class    => function(AfterSheet $event) {
                  $styleArray = [
                      'borders' => [
                          'allBorders' => [
                              'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                          ]
                      ]
                  ];
                  $event->sheet->getDelegate()->getStyle('A1:K'.$this->maxrow)->applyFromArray($styleArray);

              },*/
          ];
      }
}
?>
