<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
use Auth;

class FCAccuracySheet2Export implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    private $year;
    private $maxrow;

    public function __construct( $year)
    {
        $this->year  = $year;
    }
    public function array(): array
    {

      $forecastlist = DB::select(DB::raw("
        select a.flmcode,a.flmname,a.productcategory,
        sum(a.sls1) as sls1,
        sum(b.tgt1) as tgt1,
        (sum(b.tgt1)/sum(a.sls1)-1)*100 as month1,
        sum(a.sls2) as sls2,
        sum(b.tgt2) as tgt2,
        (sum(b.tgt2)/sum(a.sls2)-1)*100 as month2,
        sum(a.sls3) as sls3,
        sum(b.tgt3) as tgt3,
        (sum(b.tgt3)/sum(a.sls3)-1)*100 as month3,
        ((sum(b.tgt1)/sum(a.sls1)-1)+(sum(b.tgt2)/sum(a.sls2)-1)+(sum(b.tgt3)/sum(a.sls3)-1))/3*100 as fcaccuracy1,
        sum(a.sls4) as sls4,
        sum(b.tgt4) as tgt4,
        (sum(b.tgt4)/sum(a.sls4)-1)*100 as month4,
        sum(a.sls5) as sls5,
        sum(b.tgt5) as tgt5,
        (sum(b.tgt5)/sum(a.sls5)-1)*100 as month5,
        sum(a.sls6) as sls6,
        sum(b.tgt6) as tgt6,
        (sum(b.tgt6)/sum(a.sls6)-1)*100 as month6,
        ((sum(b.tgt4)/sum(a.sls4)-1)+(sum(b.tgt5)/sum(a.sls5)-1)+(sum(b.tgt6)/sum(a.sls6)-1))/3*100 as fcaccuracy2,
        sum(a.sls7) as sls7,
        sum(b.tgt7) as tgt7,
        (sum(b.tgt7)/sum(a.sls7)-1)*100 as month7,
        sum(a.sls8) as sls8,
        sum(b.tgt8) as tgt8,
        (sum(b.tgt8)/sum(a.sls8)-1)*100 as month8,
        sum(a.sls9) as sls9,
        sum(b.tgt9) as tgt9,
        (sum(b.tgt9)/sum(a.sls9)-1)*100 as month9,
        ((sum(b.tgt7)/sum(a.sls7)-1)+(sum(b.tgt8)/sum(a.sls8)-1)+(sum(b.tgt9)/sum(a.sls9)-1))/3*100 as fcaccuracy3,
        sum(a.sls10) as sls10,
        sum(b.tgt10) as tgt10,
        (sum(b.tgt10)/sum(a.sls10)-1)*100 as month10,
        sum(a.sls11) as sls11,
        sum(b.tgt11) as tgt11,
        (sum(b.tgt11)/sum(a.sls11)-1)*100 as month11,
        sum(a.sls12) as sls12,
        sum(b.tgt12) as tgt12,
        (sum(b.tgt12)/sum(a.sls12)-1)*100 as month12,
        ((sum(b.tgt10)/sum(a.sls10)-1)+(sum(b.tgt11)/sum(a.sls11)-1)+(sum(b.tgt12)/sum(a.sls12)-1))/3*100 as fcaccuracy4
        from
        (
           select a.period,a.flmcode,a.flmname,a.productgroupid,a.flmid,a.productcategory,
           Sum(IF(a.period = '1', a.sls, 0)) AS `sls1`,
           Sum(IF(a.period = '2', a.sls, 0)) AS `sls2`,
           Sum(IF(a.period = '3', a.sls, 0)) AS `sls3`,
           Sum(IF(a.period = '4', a.sls, 0)) AS `sls4`,
           Sum(IF(a.period = '5', a.sls, 0)) AS `sls5`,
           Sum(IF(a.period = '6', a.sls, 0)) AS `sls6`,
           Sum(IF(a.period = '7', a.sls, 0)) AS `sls7`,
           Sum(IF(a.period = '8', a.sls, 0)) AS `sls8`,
           Sum(IF(a.period = '9', a.sls, 0)) AS `sls9`,
           Sum(IF(a.period = '10', a.sls, 0)) AS `sls10`,
           Sum(IF(a.period = '11', a.sls, 0)) AS `sls11`,
           Sum(IF(a.period = '12', a.sls, 0)) AS `sls12`

           from `sales.rpt_invoice_trail` a
           where true
           and a.flmid is not null
           and a.year =".$this->year."
           group by a.period,a.flmcode,a.flmname,a.productgroupid,a.productcategory,a.flmid) a
           left join (
             select a.period,flmcode,flmname,productgroupid,a.flmid,
              Sum(IF(a.period = '1', a.tgt, 0)) AS `tgt1`,
              Sum(IF(a.period = '2', a.tgt, 0)) AS `tgt2`,
              Sum(IF(a.period = '3', a.tgt, 0)) AS `tgt3`,
              Sum(IF(a.period = '4', a.tgt, 0)) AS `tgt4`,
              Sum(IF(a.period = '5', a.tgt, 0)) AS `tgt5`,
              Sum(IF(a.period = '6', a.tgt, 0)) AS `tgt6`,
              Sum(IF(a.period = '7', a.tgt, 0)) AS `tgt7`,
              Sum(IF(a.period = '8', a.tgt, 0)) AS `tgt8`,
              Sum(IF(a.period = '9', a.tgt, 0)) AS `tgt9`,
              Sum(IF(a.period = '10', a.tgt, 0)) AS `tgt10`,
              Sum(IF(a.period = '11', a.tgt, 0)) AS `tgt11`,
              Sum(IF(a.period = '12', a.tgt, 0)) AS `tgt12`
             from `sales.rpt_target_trail` a
             where true
             and a.flmid is not null
             and a.year =".$this->year."
             group by a.period,flmcode,flmname,productgroupid,a.flmid
             ) b on a.flmid = b.flmid and a.productgroupid = b.productgroupid and a.period = b.period

            group by a.flmcode,a.flmname,a.flmid,a.productcategory
            order by a.flmcode,a.productcategory
            ;"
        ));
        $this->maxrow  = count($forecastlist) + 1;
        return $forecastlist;
    }
    public function headings(): array
    {
        return [
            'FLM',
            'Team',
            'Product Cat',
            'Jan Sales',
            'Jan Tgt',
            'Jan',
            'Feb Sales',
            'Feb Tgt',
            'Feb',
            'Mar Sales',
            'Mar Tgt',
            'Mar',
            'Q1 '.$this->year.' FC Accuracy',
            'Apr Sales',
            'Apr Tgt',
            'Apr',
            'May Sales',
            'May Tgt',
            'May',
            'Jun Sales',
            'Jun Tgt',
            'Jun',
            'Q2 '.$this->year.' FC Accuracy',
            'Jul Sales',
            'Jul Tgt',
            'Jul',
            'Aug Sales',
            'Aug Tgt',
            'Aug',
            'Sep Sales',
            'Sep Tgt',
            'Sep',
            'Q3 '.$this->year.' FC Accuracy',
            'Oct Sales',
            'Oct Tgt',
            'Oct',
            'Nov Sales',
            'Nov Tgt',
            'Nov',
            'Dec Sales',
            'Dec Tgt',
            'Dec',
            'Q4 '.$this->year.' FC Accuracy',
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                // All headers - set font size to 14
                //$cellRange = 'A1:W1';
                //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                // Apply array of styles to B2:G8 cell range
                $styleArray = [
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ]
                    ]
                ];
                $event->sheet->getDelegate()->getStyle('A1:AQ'.$this->maxrow)->applyFromArray($styleArray);
                //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                // Set first row to height 20
                //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                // Set A1:D4 range to wrap text in cells
                //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
            },
        ];
    }
}
?>
