<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
use Auth;

class KATargetSheet1Export implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    private $period;
    private $year;
    private $subchannelid;
    private $productgroupid;
    private $katypeid;
    private $maxrow;

    public function __construct( $year,  $period,  $subchannelid,  $productgroupid, $katypeid)
      {
          $this->period = $period;
          $this->year  = $year;
          $this->subchannelid  = $subchannelid;
          $this->productgroupid  = $productgroupid;
          $this->katypeid  = $katypeid;
      }
    public function array(): array
    {

         if(Auth::user()->territorytypeid==0){
           $where = "and 1=1";
         }elseif(Auth::user()->territorytypeid==1){
           $where = "and nsmuserid = ".Auth::user()->id;
         }elseif(Auth::user()->territorytypeid==2){
           $where = "and flmuserid = ".Auth::user()->id;
         }elseif(Auth::user()->territorytypeid==3){
           $where = "and mruserid = ".Auth::user()->id;
         }
         if($this->subchannelid!=""){
           $wheresubchannel = "and subchannelid in ( ".$this->subchannelid.")";
         }else{
           $wheresubchannel = "and 1=1";
         }

         if($this->productgroupid!=""){
           $whereproductgroup = "and productgroupid in ( ".$this->productgroupid.")";
         }else{
           $whereproductgroup = "and 1=1";
         }

         if($this->katypeid!=""){
           $wherekatype = "and katypeid in ( ".$this->katypeid.")";
         }else{
           $wherekatype = "and 1=1";
         }
        $KATargetlist = DB::select(DB::raw("
         select katargetdtlid as id,productgroup,subchannel,katype,tgt_temp From (
            SELECT a.*,a.katargetdtlid as recid,IFNULL(b.tgt, 0) as lasttgt
            FROM `sales.view_ka_target_dtl` a
            left join `sales.ka_target_dtl` b on a.subchannelid = b.subchannelid and a.productgroupid = b.productgroupid and a.katypeid = b.katypeid
             and year(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = year(DATE(CONCAT_WS('-', b.year, b.period, 1)))
             and month(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = month(DATE(CONCAT_WS('-', b.year, b.period, 1)))
             ) aaa
            where true
            and year = ".$this->year."
            and period = ".$this->period."
            "
            .$where.
            "
            "
            .$wheresubchannel.
            "
            "
            .$whereproductgroup.
            "
            "
            .$wherekatype.
            "
            order by year,period,subchannel,productgroup,katype
            ;"
        ));
        $this->maxrow  = count($KATargetlist) + 1;
        return $KATargetlist;
    }
    public function headings(): array
    {
        return [
            'id',
            'Product Group',
            'Sub Channel',
            'KA Type',
            'TGT Amount'
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                // All headers - set font size to 14
                //$cellRange = 'A1:W1';
                //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                // Apply array of styles to B2:G8 cell range
                $styleArray = [
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ]
                    ]
                ];
                $event->sheet->getDelegate()->getStyle('A1:E'.$this->maxrow)->applyFromArray($styleArray);
                if(Auth::user()->territorytypeid!=0){
                  $event->sheet->getProtection()->setSheet(true);
                  $event->sheet->getDelegate()->getStyle('E2:E'.$this->maxrow)->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                }
                $event->sheet->getColumnDimension('A')->setVisible(false);
                //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                // Set first row to height 20
                //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                // Set A1:D4 range to wrap text in cells
                //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
            },
        ];
    }
}
?>
