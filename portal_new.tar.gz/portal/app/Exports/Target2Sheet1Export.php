<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
use Auth;

class Target2Sheet1Export implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    private $period;
    private $year;
    private $mrid;
    private $productgroupid;
    private $channelid;
    private $subchannel2id;
    private $maxrow;

    public function __construct( $year,  $period,  $mrid,  $productgroupid,$channelid,$subchannel2id)
    {
        $this->period = $period;
        $this->year  = $year;
        $this->mrid  = $mrid;
        $this->productgroupid  = $productgroupid;
        $this->channelid  = $channelid;
        $this->subchannel2id  = $subchannel2id;
    }
    public function array(): array
    {

         if(Auth::user()->territorytypeid==0){
           $where = "and 1=1";
         }elseif(Auth::user()->territorytypeid==1){
           $where = "and nsmuserid = ".Auth::user()->id;
         }elseif(Auth::user()->territorytypeid==2){
           $where = "and flmuserid = ".Auth::user()->id;
         }elseif(Auth::user()->territorytypeid==3){
           $where = "and mruserid = ".Auth::user()->id;
         }
         if($this->mrid!=""){
           $wheremr = "and mrid in ( ".$this->mrid.")";
         }else{
           $wheremr = "and 1=1";
         }
         if($this->channelid!=""){
           $wherechannel = "and channelid in ( ".$this->channelid.")";
         }else{
           $wherechannel = "and 1=1";
         }
         if($this->subchannel2id!=""){
           $wheresubchannel2 = "and subchannel2id in ( ".$this->subchannel2id.")";
         }else{
           $wheresubchannel2 = "and 1=1";
         }

         if($this->productgroupid!=""){
           $whereproductgroup = "and productgroupid in ( ".$this->productgroupid.")";
         }else{
           $whereproductgroup = "and 1=1";
         }
        $Targetlist = DB::select(DB::raw("
         select targetdtlid as id,productgroup,channel,subchannel2,mrcode,mrname,tgt_temp From (
            SELECT a.*,a.targetdtlid as recid,IFNULL(b.tgt, 0) as lasttgt
            FROM `sales.view_target_dtl` a
            left join `sales.target_dtl` b on a.mrid = b.mrid and a.productgroupid = b.productgroupid and a.channelid = b.channelid and a.subchannel2id = b.subchannel2id
             and year(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = year(DATE(CONCAT_WS('-', b.year, b.period, 1)))
             and month(DATE_ADD(DATE(CONCAT_WS('-', a.year, a.period, 1)), INTERVAL -1 MONTH)) = month(DATE(CONCAT_WS('-', b.year, b.period, 1)))
             ) aaa
            where true
            and year = ".$this->year."
            and period = ".$this->period."
            "
            .$where.
            "
            "
            .$wheremr.
            "
            "
            .$wherechannel.
            "
            "
            .$wheresubchannel2.
            "
            "
            .$whereproductgroup.
            "

            order by year,period,mrcode,productgroup
            ;"
        ));
        $this->maxrow  = count($Targetlist) + 1;
        return $Targetlist;
    }
    public function headings(): array
    {
        return [
            'id',
            'Product Group',
            'Channel',
            'Sub Channel 2',
            'Mr Code',
            'Mr Name',
            'TGT Amount'
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                // All headers - set font size to 14
                //$cellRange = 'A1:W1';
                //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                // Apply array of styles to B2:G8 cell range
                $styleArray = [
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ]
                    ]
                ];
                $event->sheet->getDelegate()->getStyle('A1:G'.$this->maxrow)->applyFromArray($styleArray);
                if(Auth::user()->territorytypeid!=0){
                  $event->sheet->getProtection()->setSheet(true);
                  $event->sheet->getDelegate()->getStyle('E2:G'.$this->maxrow)->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                }
                $event->sheet->getColumnDimension('A')->setVisible(false);
                //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                // Set first row to height 20
                //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                // Set A1:D4 range to wrap text in cells
                //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
            },
        ];
    }
}
?>
