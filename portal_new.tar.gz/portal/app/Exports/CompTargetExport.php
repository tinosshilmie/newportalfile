<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class CompTargetExport implements WithMultipleSheets
{

    use Exportable;

    private $period;
    private $year;
    private $channelid;
    private $productgroupid;

    public function __construct( $year,  $period,  $channelid,  $productgroupid)
      {
          $this->period = $period;
          $this->year  = $year;
          $this->channelid  = $channelid;
          $this->productgroupid  = $productgroupid;
      }
    public function sheets(): array
      {
         $sheets = [];

         $sheets[] = new CompTargetSheet1Export($this->year, $this->period, $this->channelid, $this->productgroupid);
         $sheets[] = new CompTargetSheet2Export($this->year, $this->period);

         return $sheets;
      }
}
?>
