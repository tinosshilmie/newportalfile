<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class KATargetExport implements WithMultipleSheets
{

    use Exportable;

    private $period;
    private $year;
    private $subchannelid;
    private $productgroupid;
    private $katypeid;

    public function __construct( $year,  $period,  $subchannelid,  $productgroupid, $katypeid)
      {
          $this->period = $period;
          $this->year  = $year;
          $this->subchannelid  = $subchannelid;
          $this->productgroupid  = $productgroupid;
          $this->katypeid  = $katypeid;
      }
    public function sheets(): array
      {
         $sheets = [];

         $sheets[] = new KATargetSheet1Export($this->year, $this->period, $this->subchannelid, $this->productgroupid, $this->katypeid);
         $sheets[] = new KATargetSheet2Export($this->year, $this->period);

         return $sheets;
      }
}
?>
