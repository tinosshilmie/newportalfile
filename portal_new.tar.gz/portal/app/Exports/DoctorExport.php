<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Auth;
use DB;

class DoctorExport implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    use Exportable;

    private $code;
    private $name;
    private $country;

    public function __construct($code,$name,$country)
      {
          $this->code  = $code;
          $this->name  = $name;
          $this->country  = $country;
      }

      public function array(): array
      {
          if($this->code!=""){
            $wherecode = "and code in ( ".$this->code.")";
          }else{
            $wherecode = "and 1=1";
          }
          if($this->name!=""){
            $wherename = "and name in ( ".$this->name.")";
          }else{
            $wherename = "and 1=1";
          }

         if($this->country!=""){
           $wherecountry = "and countryid in ( ".$this->country.")";
         }else{
           $wherecountry = "and 1=1";
         }

         $customerlist = DB::select(DB::raw("
          select a.code,a.name,b.country From `master.doctor` a
          left join `master.country` b on a.countryid = b.id
          where true
          "
            .$wherecode.
          "
          "
            .$wherename.
          "
          "
            .$wherecountry.
          "
          ;"
         ));
        $this->maxrow  = count($customerlist) + 1;
        return $customerlist;
      }
      public function headings(): array
      {
          return [
            'Code'  ,
            'Name'	,
            'Country'	

          ];
      }

      public function registerEvents(): array
      {
          return [
              AfterSheet::class    => function(AfterSheet $event) {
                  // All headers - set font size to 14
                  //$cellRange = 'A1:W1';
                  //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                  // Apply array of styles to B2:G8 cell range
                  $styleArray = [
                      'borders' => [
                          'allBorders' => [
                              'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                          ]
                      ]
                  ];
                  $event->sheet->getDelegate()->getStyle('A1:C'.$this->maxrow)->applyFromArray($styleArray);

                  //$event->sheet->getDelegate()->getStyle('A1:A'.$this->maxrow)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);
                  //$event->sheet->getDelegate()->getStyle('C1:C'.$this->maxrow)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);
                  //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                  // Set first row to height 20
                  //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                  // Set A1:D4 range to wrap text in cells
                  //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
              },
          ];
      }
}
?>

