<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class RetaggingExport implements WithMultipleSheets
{

    use Exportable;

    private $state;
    private $shiptocode;
    private $productgroupid;
    private $mrcode;

    public function __construct( $state,  $shiptocode,  $productgroupid, $mrcode)
      {
          $this->state = $state;
          $this->shiptocode  = $shiptocode;
          $this->productgroupid  = $productgroupid;
          $this->mrcode  = $mrcode;
      }
    public function sheets(): array
      {
         $sheets = [];

         $sheets[] = new RetaggingSheet1Export($this->state, $this->shiptocode, $this->productgroupid, $this->mrcode);
         $sheets[] = new RetaggingSheet2Export();

         return $sheets;
      }
}
?>
