<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class Target2Export implements WithMultipleSheets
{

    use Exportable;

    private $period;
    private $year;
    private $mrid;
    private $productgroupid;
    private $channelid;
    private $subchannel2id;

    public function __construct( $year,  $period,  $mrid,  $productgroupid,$channelid,$subchannel2id)
      {
          $this->period = $period;
          $this->year  = $year;
          $this->mrid  = $mrid;
          $this->productgroupid  = $productgroupid;
          $this->channelid  = $channelid;
          $this->subchannel2id  = $subchannel2id;
      }
    public function sheets(): array
      {
         $sheets = [];

         $sheets[] = new Target2Sheet1Export($this->year, $this->period, $this->mrid, $this->productgroupid, $this->channelid, $this->subchannel2id);
         $sheets[] = new Target2Sheet2Export($this->year, $this->period);

         return $sheets;
      }
}
?>
