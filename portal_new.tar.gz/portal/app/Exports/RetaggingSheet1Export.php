<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
use Auth;

class RetaggingSheet1Export implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    private $state;
    private $shiptocode;
    private $productgroupid;
    private $mrcode;
    private $maxrow;

    public function __construct( $state,  $shiptocode,  $productgroupid, $mrcode)
    {
        $this->state = $state;
        $this->shiptocode  = $shiptocode;
        $this->productgroupid  = $productgroupid;
        $this->mrcode  = $mrcode;
    }
    public function array(): array
    {

        if($this->productgroupid!=""){
          $whereproductgroup = "and a.productgroupid in ( ".$this->productgroupid.")";
        }else{
          $whereproductgroup = "and 1=1";
        }
        if($this->shiptocode!=""){
          $whereshiptocode = "and b.shiptocode like '%".$this->shiptocode."%'";
        }else{
          $whereshiptocode = "and 1=1";
        }
        if($this->state!=""){
          $wherestate = "and b.state in ( ".$this->state .")";
        }else{
          $wherestate = "and 1=1";
        }
        if($this->mrcode!=""){
          $wheremrcode = "and c.mrid in ( ".$this->mrcode.")";
        }else{
          $wheremrcode = "and 1=1";
        }

        $forecastlist = DB::select(DB::raw("
          select a.customerid,a.productgroupid,a.territoryid,'' as a,'' as b,c.mrcode,c.mrname,d.`Desc` as productgroup,b.channel,
          b.shiptocode,b.shiptoname,b.address1,b.address2,b.address3,b.postalcode,b.state,b.imsgroup1,b.imsgroup2  from
           `master.map_territory_customer_product` a
          left join `master.view_customer` b on a.customerid = b.id
          left join `master.view_territoryV2` c on a.territoryid = c.mrid
          left join `master.product_group` d on a.productgroupid = d.id
          where true
          "
          .$whereproductgroup.
          "
          "
          .$whereshiptocode.
          "
          "
          .$wherestate.
          "
          "
          .$wheremrcode.
          "
          ;"
        ));
      $this->maxrow  = count($forecastlist) + 1;
      return $forecastlist;
    }
    public function headings(): array
    {
        return [
            'customerid',
            'productgroupid',
            'mrid',
            'New MR Code',
            'New Mr Name',
            'Current MR Code',
            'Current Mr Name',
            'Product Group',
            'Channel',
            'Shiptocode',
            'Shiptoname',
            'Address1',
            'Address2',
            'Address3',
            'Postal Code',
            'State',
            'IMS Group 1',
            'IMS Group 2'
        ];

    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                // All headers - set font size to 14
                //$cellRange = 'A1:W1';
                //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                // Apply array of styles to B2:G8 cell range
                $styleArray = [
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ]
                    ]
                ];
                $event->sheet->getDelegate()->getStyle('A1:R'.$this->maxrow)->applyFromArray($styleArray);
                $event->sheet->getProtection()->setSheet(true);
                $event->sheet->getDelegate()->getStyle('D2:E'.$this->maxrow)->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $event->sheet->getColumnDimension('A')->setVisible(false);
                $event->sheet->getColumnDimension('B')->setVisible(false);
                $event->sheet->getColumnDimension('C')->setVisible(false);
                //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                // Set first row to height 20
                //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                // Set A1:D4 range to wrap text in cells
                //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
            },
        ];
    }
}
?>
