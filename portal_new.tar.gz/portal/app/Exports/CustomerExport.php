<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Auth;
use DB;

class CustomerExport implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    use Exportable;

    private $shiptocode;
    private $shiptoname;
    private $country;

    public function __construct($shiptocode,$shiptoname,$country)
      {
          $this->shiptocode  = $shiptocode;
          $this->shiptoname  = $shiptoname;
          $this->country  = $country;
      }

      public function array(): array
      {
          if($this->shiptocode!=""){
            $whereshiptocode = "and shiptocode in ( ".$this->shiptocode.")";
          }else{
            $whereshiptocode = "and 1=1";
          }
          if($this->shiptoname!=""){
            $whereshiptoname = "and shiptoname in ( ".$this->shiptoname.")";
          }else{
            $whereshiptoname = "and 1=1";
          }

         if($this->country!=""){
           $wherecountry = "and country in ( ".$this->country.")";
         }else{
           $wherecountry = "and 1=1";
         }
         $customerlist = DB::select(DB::raw("
          select sapcode,shiptocode,shiptoname,b.country From `master.customer` a
          left join `master.country` b on a.countryid = b.id
           where true
           "
           .$whereshiptocode.
           "
           "
           .$whereshiptoname.
           "
           "
           .$wherecountry.
           "
           ;"
         ));
        $this->maxrow  = count($customerlist) + 1;
        return $customerlist;
      }
      public function headings(): array
      {
          return [
            'SAP Code'	,
            'Ship to Code'  ,
            'Ship to Name'	,
            'Country'	

          ];
      }

      public function registerEvents(): array
      {
          return [
              AfterSheet::class    => function(AfterSheet $event) {
                  // All headers - set font size to 14
                  //$cellRange = 'A1:W1';
                  //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                  // Apply array of styles to B2:G8 cell range
                  $styleArray = [
                      'borders' => [
                          'allBorders' => [
                              'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                          ]
                      ]
                  ];
                  $event->sheet->getDelegate()->getStyle('A1:D'.$this->maxrow)->applyFromArray($styleArray);

                  //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                  // Set first row to height 20
                  //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                  // Set A1:D4 range to wrap text in cells
                  //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
              },
          ];
      }
}
?>

