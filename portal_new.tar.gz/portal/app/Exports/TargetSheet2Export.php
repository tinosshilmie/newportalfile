<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;

use Auth;

class TargetSheet2Export implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    private $period;
    private $year;

    public function __construct(int $year, int $period)
    {
        $this->period = $period;
        $this->year  = $year;
    }
    public function array(): array
    {
        return [[$this->year, $this->period, Auth::user()->id]];
    }
    public function headings(): array
    {
        return [
            'year',
            'period',
            'userid'
        ];
    }
    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                // All headers - set font size to 14
                //$cellRange = 'A1:W1';
                //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                // Apply array of styles to B2:G8 cell range
                /*$event->sheet->getDelegate()->getStyle('A1:E'.$this->maxrow)->applyFromArray($styleArray);
                $event->sheet->getProtection()->setSheet(true);
                $event->sheet->getDelegate()->getStyle('E2:E'.$this->maxrow)->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $event->sheet->getColumnDimension('A')->setVisible(false);*/
                $event->sheet->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                // Set first row to height 20
                //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                // Set A1:D4 range to wrap text in cells
                //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
            },
        ];
    }
}
?>
