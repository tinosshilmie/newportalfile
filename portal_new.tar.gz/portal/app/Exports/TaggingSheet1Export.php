<?php
namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
use Auth;

class TaggingSheet1Export implements FromArray, WithHeadings,ShouldAutoSize,WithEvents
{

    private $state;
    private $shiptocode;
    private $productgroupid;
    private $maxrow;

    public function __construct( $state,  $shiptocode,  $productgroupid)
    {
        $this->state = $state;
        $this->shiptocode  = $shiptocode;
        $this->productgroupid  = $productgroupid;
    }
    public function array(): array
    {

        if($this->productgroupid!=""){
          $whereproductgroup = "and a.productgroupid in ( ".$this->productgroupid.")";
        }else{
          $whereproductgroup = "and 1=1";
        }
        if($this->shiptocode!=""){
          $whereshiptocode = "and a.shiptocode like '%".$this->shiptocode."%'";
        }else{
          $whereshiptocode = "and 1=1";
        }
        if($this->state!=""){
          $wherestate = "and a.state in ( ".$this->state .")";
        }else{
          $wherestate = "and 1=1";
        }

        /*and (a.year >= year(DATE_ADD(now(), INTERVAL -1 MONTH)) and a.period >= month(DATE_ADD(now(), INTERVAL -1 MONTH)))*/
       $forecastlist = DB::select(DB::raw("
          select distinct a.productgroupid,a.customerid,'' as a,'' as b,a.productgroup,a.channel,a.shiptocode,a.shiptoname,
          a.address1,a.address2,a.address3,a.postalcode,a.state,
          a.imsgroup1,a.imsgroup2 from
          `sales.view_invoice_dtl` `a`
          where true
          and (a.TerritoryID is null)
          and a.productgroupid is not null
          and a.customerid is not null
      and invoicedate >=  now()-interval 3 month
          "
          .$whereproductgroup.
          "
          "
          .$whereshiptocode.
          "
          "
          .$wherestate.
          "
          ;"
       ));
      $this->maxrow  = count($forecastlist) + 1;
      return $forecastlist;
    }
    public function headings(): array
    {
        return [
            'productgroupid',
            'customerid',
            'MR Code',
            'Mr Name',
            'Product Group',
            'Channel',
            'Shiptocode',
            'Shiptoname',
            'Address1',
            'Address2',
            'Address3',
            'Postal Code',
            'State',
            'IMS Group 1',
            'IMS Group 2'
        ];

    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                // All headers - set font size to 14
                //$cellRange = 'A1:W1';
                //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                // Apply array of styles to B2:G8 cell range
                $styleArray = [
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ]
                    ]
                ];
                $event->sheet->getDelegate()->getStyle('A1:O'.$this->maxrow)->applyFromArray($styleArray);
                $event->sheet->getProtection()->setSheet(true);
                $event->sheet->getDelegate()->getStyle('C2:D'.$this->maxrow)->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $event->sheet->getColumnDimension('A')->setVisible(false);
                $event->sheet->getColumnDimension('B')->setVisible(false);
                //$event->sheet->sheet('Setting')->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
                // Set first row to height 20
                //$event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

                // Set A1:D4 range to wrap text in cells
                //$event->sheet->getDelegate()->getStyle('A1:D4')->getAlignment()->setWrapText(true);
            },
        ];
    }
}
?>
