<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Exports\SampleOrderExport;
use App\Mail\ApproveSampleOrderMail;
use App\Mail\ApproveSampleOrderMailRespond;
use App\Mail\RejectSampleOrderMail;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
//use App\Http\Controllers\Saml2Controller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();
//Auth::routes(['register' => false]);

//app('debugbar')->disable();
Route::get('/', 'MenuController@verifylogin')->name('verifylogin');

//saml2

Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/importdata', 'MenuController@importdata')->name('importdata');

Route::post('/savesamplemy', 'MenuController@savesamplemy')->name('savesamplemy');
Route::post('/savesamplesg', 'MenuController@savesamplesg')->name('savesamplesg');
Route::post('/savesamplestatus', 'MenuController@savesamplestatus')->name('savesamplestatus');

Route::post('/rejectsampleorderadmin', 'MenuController@rejectsampleorderadmin')->name('rejectsampleorderadmin');

Route::get('file', 'FileController@index');
Route::post('store-file', 'FileController@store');
//Route::get('/verifylogin', 'MenuController@verifylogin')->name('verifylogin');
Route::get('/changepassword', 'MenuController@changepassword')->name('changepassword');
Route::post('/updatepassword', 'MenuController@updatepassword')->name('updatepassword');
Route::post('/updatepassword2', 'ForgotPasswordController@updatepassword2')->name('updatepassword2');

Route::post('/generatepassword', 'MailController@generatepassword')->name('generatepassword');
Route::get('/forgotpassword', 'ForgotPasswordController@forgotpassword')->name('forgotpassword');
Route::get('/resetpassword/{email}', 'ForgotPasswordController@resetpassword')->name('resetpassword');
Route::post('/checkemail', 'ForgotPasswordController@checkemail')->name('checkemail');
//Route::view('forgot_password', 'auth.reset_password')->name('password.reset');
Route::post('/password/reset', 'ForgotPasswordController@reset');
Route::get('file', 'FileController@index');

Route::get('/accesslog', 'MenuController@accesslog')->name('accesslog');
Route::post('/getaccesslog', 'MenuController@getaccesslog')->name('getaccesslog');
Route::get('/exportaccesslog', 'MenuController@exportaccesslog')->name('exportaccesslog');

Route::get('/customer', 'MenuController@customer')->name('customer');
Route::post('/getcustomer', 'MenuController@getcustomer')->name('getcustomer');
Route::post('/savecustomer', 'MenuController@savecustomer')->name('savecustomer');
Route::get('/exportcustomer', 'MenuController@exportcustomer')->name('exportcustomer');
Route::get('/importcustomer', 'MenuController@importcustomer')->name('importcustomer');

Route::get('/product', 'MenuController@product')->name('product');
Route::post('/getproduct', 'MenuController@getproduct')->name('getproduct');
Route::post('/saveproduct', 'MenuController@saveproduct')->name('saveproduct');

Route::get('/productgroup', 'MenuController@productgroup')->name('productgroup');
Route::post('/getproductgroup', 'MenuController@getproductgroup')->name('getproductgroup');
Route::post('/saveproductgroup', 'MenuController@saveproductgroup')->name('saveproductgroup');

Route::get('/user', 'MenuController@user')->name('user');
Route::post('/getuser', 'MenuController@getuser')->name('getuser');
Route::post('/saveuser', 'MenuController@saveuser')->name('saveuser');
Route::post('/adduser', 'MenuController@adduser')->name('adduser');
Route::get('/exportuser', 'MenuController@exportuser')->name('exportuser');
Route::post('/checkuserterritory', 'MenuController@checkuserterritory')->name('checkuserterritory');
Route::post('/checkstaffidexist', 'MenuController@checkstaffidexist')->name('checkstaffidexist');

Route::get('/getaccess', 'MenuController@getaccess')->name('getaccess');


Route::get('/sample', 'MenuController@sample')->name('sample');
Route::post('/getsample', 'MenuController@getsample')->name('getsample');
Route::post('/savesample', 'MenuController@savesample')->name('savesample');

Route::get('/samplereport', 'MenuController@samplereport')->name('samplereport');
Route::post('/getsamplereport', 'MenuController@getsamplereport')->name('getsamplereport');
Route::get('/exportsamplereport', 'MenuController@exportsamplereport')->name('exportsamplereport');

Route::get('/samplereportdetail', 'MenuController@samplereportdetail')->name('samplereportdetail');
Route::post('/getsamplereportdetail', 'MenuController@getsamplereportdetail')->name('getsamplereportdetail');
Route::get('/exportsamplereportdetail', 'MenuController@exportsamplereportdetail')->name('exportsamplereportdetail');


Route::get('/sampletrackerreport', 'MenuController@sampletrackerreport')->name('sampletrackerreport');
Route::post('/getsampletrackerreport', 'MenuController@getsampletrackerreport')->name('getsampletrackerreport');
Route::get('/exportsampletrackerreport', 'MenuController@exportsampletrackerreport')->name('exportsampletrackerreport');

Route::post('/getbalqty', 'MenuController@getbalqty')->name('getbalqty'); 
Route::post('/checkquota', 'MenuController@checkquota')->name('checkquota');
Route::get('/sampleorder', 'MenuController@sampleorder')->name('sampleorder');
Route::post('/getsampleorder', 'MenuController@getsampleorder')->name('getsampleorder');
Route::post('/getsampleorderinvoice', 'MenuController@getsampleorderinvoice')->name('getsampleorderinvoice');
Route::post('/getsampleorderlist', 'MenuController@getsampleorderlist')->name('getsampleorderlist');
Route::post('/getskulist2', 'MenuController@getskulist2')->name('getskulist2');
Route::post('/getcustlist2', 'MenuController@getcustlist2')->name('getcustlist2');
Route::post('/savesampleorder', 'MenuController@savesampleorder')->name('savesampleorder');
Route::post('/approvesampleorderportal', 'MenuController@approvesampleorderportal')->name('approvesampleorderportal');
Route::post('/rejectsampleorderportal', 'MenuController@rejectsampleorderportal')->name('rejectsampleorderportal');
Route::get('/exportsampleorder', 'MenuController@exportsampleorder')->name('exportsampleorder');
Route::get('/exportsampleorderinvoice', 'MenuController@exportsampleorderinvoice')->name('exportsampleorderinvoice');



Route::get('/doctor', 'MenuController@doctor')->name('doctor');
Route::post('/getdoctor', 'MenuController@getdoctor')->name('getdoctor');
Route::post('/savedoctor', 'MenuController@savedoctor')->name('savedoctor');
Route::get('/exportdoctor', 'MenuController@exportdoctor')->name('exportdoctor');
Route::get('/importdoctor', 'MenuController@importdoctor')->name('importdoctor');

Route::get('/mapcustomerdoctor', 'MenuController@mapcustomerdoctor')->name('mapcustomerdoctor');
Route::post('/getmapcustomerdoctor', 'MenuController@getmapcustomerdoctor')->name('getmapcustomerdoctor');
Route::post('/savemapcustomerdoctor', 'MenuController@savemapcustomerdoctor')->name('savemapcustomerdoctor');
Route::post('/deletemapcustomerdoctor', 'MenuController@deletemapcustomerdoctor')->name('deletemapcustomerdoctor');

Route::get('/specialist', 'MenuController@specialist')->name('specialist');
Route::post('/getspecialist', 'MenuController@getspecialist')->name('getspecialist');
Route::post('/savespecialist', 'MenuController@savespecialist')->name('savespecialist');


Route::get('/fieldofpractice', 'MenuController@fieldofpractice')->name('fieldofpractice');
Route::post('/getfieldofpractice', 'MenuController@getfieldofpractice')->name('getfieldofpractice');
Route::post('/savefieldofpractice', 'MenuController@savefieldofpractice')->name('savefieldofpractice');

Route::get('reset-mail/{temppassword}/{name}/{email}', function ($temppassword = null ,$name = null,$email = null) {
  $details = [
    'name' => $name,
    'temppassword' => $temppassword
  ];
  \Mail::to($email)->send(new \App\Mail\ResetMail($details));
  return Response()->json([
      'success' => true,
      'error1msg' => ''
  ]);
})->name('reset-mail');

Route::get('sendemail', function () {
  $userlist = DB::select(DB::raw("
    SELECT * FROM `master_user` where sendpassword = 1;
  "));
  foreach ($userlist as $row)
  {
    $temppassword = Str::random(8);
    $hashtemppassword = Hash::make($temppassword);
    $details = [
      'name' => $row->username,
      'loginid' => $row->staffid,
      'temppassword' => $temppassword
    ];
    \Mail::to($row->email)->send(new \App\Mail\NewPasswordMail($details));

    $query = DB::select(DB::raw("
      update `master_user`
      set password = '".$hashtemppassword."',
      lastupdatepassword = null,
      sendpassword = 0
      where id = '".$row->id."'
      ;"
    ));
  }
}
)->name('sendemail');
Route::get('/approvesampleorder/{orderno}/{approveby}', function ($orderno,$approveby,Request $request) {
    if (! $request->hasValidSignature()) {
      abort(419);
    }
	$data['recid'] = $orderno;
      if($data['recid']!=""){
        $whereorderno = "and orderno = '".$data['recid']."'";
      }else{
        $whereorderno = "and 1=1";
      }
      $checkstatus = DB::select(DB::raw("
        select
        * from
        `sales.view_order_sample_detail`
        where true
        "
        .$whereorderno.
        "
        ;"
      ));
      if($checkstatus[0]->status == 1){

    DB::beginTransaction();
    try {
    $query = DB::select(DB::raw("
      insert into `master.accesslog`
      values (null,'".$approveby."',now(),'Approve sample order via email')
      ;"
    ));
    $checkusr = DB::select(DB::raw("
       select * from `master_user`
       where id = '".$approveby."'
       ;"
     )); 
    $query = DB::select(DB::raw("
      update `sales.order_sample`
      set 
      approveby = ".$approveby.",
      approvedate = now(),
      status = 2
      ,datemodified = now()
      ,modifiedby = '".$approveby."'
      where orderno = '".$orderno."'
      ;"
    ));

	$data['recid'] = $orderno;
      if($data['recid']!=""){
        $whereorderno = "and orderno = '".$data['recid']."'";
      }else{
        $whereorderno = "and 1=1";
      }
      $query = DB::select(DB::raw("
        select
        * from
        `sales.view_order_sample_detail`
        where true
        "
        .$whereorderno.
        "
        ;"
      ));

        $check = DB::select(DB::raw("
         select * from `sales.order_sample`
         where orderno = '".$data['recid']."'
         limit 1
         ;"
       ));
        $checkusr = DB::select(DB::raw("
         select * from `master_user`
         where id = '".$check[0]->orderby."'
         ;"
       ));
	
      $checkflmusr = DB::select(DB::raw("
       select * from `master_user`
       where id = '".$approveby."'
       ;"
     ));
          $checkprincipal = DB::select(DB::raw("
           select * from `master.principal`
           where id = '".$check[0]->principalid."'
           ;"
         ));
        //$emailorderby = 'hilmie@tinosstech.com';
        $emailorderby = $checkusr[0]->email;
        if($check[0]->countryid == 1){
        $email = 'rpa-order@zuelligpharma.com';
        //$email = 'support@tinosstech.com';
        //$email = 'hilmie@tinosstech.com';

        $spreadsheet = IOFactory::Load('sampleform.xlsx');
        $spreadsheet->getActiveSheet()->setCellValue('E7',$checkprincipal[0]->principalcode);
        $spreadsheet->getActiveSheet()->setCellValue('E8',$query[0]->orderbyname);
        $spreadsheet->getActiveSheet()->setCellValue('E9',$checkusr[0]->email);
        $spreadsheet->getActiveSheet()->setCellValue('E14',$query[0]->soldtocode);
        $spreadsheet->getActiveSheet()->setCellValue('F14',$query[0]->shiptocode);
        $spreadsheet->getActiveSheet()->setCellValue('G14',$query[0]->orderno);
        $spreadsheet->getActiveSheet()->setCellValue('H14',trim($query[0]->remark));
        $rowno = 16;
        foreach($query as $result) {
                $spreadsheet->getActiveSheet()->setCellValue('C'.$rowno,$result->productsapcode);
                $spreadsheet->getActiveSheet()->setCellValue('D'.$rowno,$result->qty);
		$spreadsheet->getActiveSheet()->setCellValue('J'.$rowno,$result->batchno);
		$rowno = $rowno + 1;
        }
        $writer = new Xlsx($spreadsheet);
        $fileName = 'Sample_Order_'.$data['recid'].'_'.date("Y-m-d").'.xlsx';
        $file_path = public_path() .'/download/'.$fileName;
        $writer->save($file_path);

      $download_link = url($file_path);
        }elseif($check[0]->countryid == 2){
        $email = ['zeom-sg@zuelligpharma.com','sgzpscallcentermailbox@zuelligpharma.com'];
        //$email = ['hilmie@tinosstech.com','hifzil.hilmie@hotmail.com'];

        //$fileName = 'Sample_Order_'.$data['recid'].'_'.date("Y-m-d").'.xlsx';
        $fileName = 'PECWEB_Bayer_SSO_'.date("YmdHis").'.csv';
	Excel::store(new SampleOrderExport($data['recid']), $fileName, 'public_download');
        $file_path = public_path() .'/download/'.$fileName;
        $download_link = url($file_path);

      }else{
        $email = 'hilmie@tinosstech.com';
      }


      $queryorder = DB::select(DB::raw("
         select * from `sales.view_order_sample_detail`
         where orderno = '".$data['recid']."'
         ;"
       ));
      $details = [
        'fromname' => $checkusr[0]->username,
        'filename' => $file_path,
        'orderno' => $data['recid'] ,
        'queryorder' => $queryorder
      ];

      //$email = 'zeom-sg@zuelligpharma.com';
      //$ccemail = ['hifzil.hilmie@gmail.com','hifzil.hilmie@hotmail.com'];
      $ccemail = ['support@tinosstech.com',$checkusr[0]->email,$checkflmusr[0]->email];
      Mail::to($email)->cc($ccemail)->send(new ApproveSampleOrderMail($details));
      Mail::to($emailorderby)->send(new ApproveSampleOrderMailRespond($details));
	DB::commit();
    return View::make('approvesampleresult', ["orderno"=>$orderno,"approveby"=>$approveby]);
	}catch (\Exception $e) {
		DB::rollback(); // something went wrong
	//return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>$e->getMessage()]);
        return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>"Error"]);
      }
      }elseif($checkstatus[0]->status == 2){
        return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>" already approved by ".$checkstatus[0]->approvebyname." on ".$checkstatus[0]->approvedate]);
      }elseif($checkstatus[0]->status == 3){
        return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>" already rejected by ".$checkstatus[0]->rejectbyname." on ".$checkstatus[0]->rejectdate]);      
      }else{
        return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>"Error"]);
      }
	
})->name('approvesampleorder');


Route::get('/rejectsampleorder/{orderno}/{rejectby}', function ($orderno,$rejectby,Request $request) {
    if (! $request->hasValidSignature()) {
      abort(419);
    }
	$data['recid'] = $orderno;
      if($data['recid']!=""){
        $whereorderno = "and orderno = '".$data['recid']."'";
      }else{
        $whereorderno = "and 1=1";
      }
      $checkstatus = DB::select(DB::raw("
        select
        * from
        `sales.view_order_sample_detail`
        where true
        "
        .$whereorderno.
        "
        ;"
      ));
      if($checkstatus[0]->status == 1){

    DB::beginTransaction();
    try {
    $query = DB::select(DB::raw("
      insert into `master.accesslog`
      values (null,'".$rejectby."',now(),'Reject sample order via email')
      ;"
    ));
    $checkusr = DB::select(DB::raw("
       select * from `master_user`
       where id = '".$rejectby."'
       ;"
     )); 
    $query = DB::select(DB::raw("
      update `sales.order_sample`
      set 
      rejectby = ".$rejectby.",
      rejectdate = now(),
      status = 3
      ,datemodified = now()
      ,modifiedby = '".$rejectby."'
      where orderno = '".$orderno."'
      ;"
    ));

    $check = DB::select(DB::raw("
       select * from `sales.order_sample`
       where orderno = '".$orderno."'
       limit 1
       ;"
     )); 
    $checkusr2 = DB::select(DB::raw("
       select * from `master_user`
       where id = '".$check[0]->orderby."'
       ;"
     )); 
    //$email = 'hilmie@tinosstech.com';
    $email = $checkusr2[0]->email;
    $details = [
      'fromname' => $checkusr[0]->username,
      'toname' => $checkusr2[0]->username,
      'orderno' => $orderno
    ];
    Mail::to($email)->send(new RejectSampleOrderMail($details));
	
      DB::commit();
    
    return View::make('rejectsampleresult', ["orderno"=>$orderno,"rejectby"=>$rejectby]);

    }catch (\Exception $e) {
        DB::rollback(); // something went wrong
        return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>"Error"]);
      }
      
      }elseif($checkstatus[0]->status == 2){
        return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>" already approved by ".$checkstatus[0]->approvebyname." on ".$checkstatus[0]->approvedate]);
      }elseif($checkstatus[0]->status == 3){
        return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>" already rejected by ".$checkstatus[0]->rejectbyname." on ".$checkstatus[0]->rejectdate]);
      }else{
        return View::make('sampleerror', ["orderno"=>$orderno,"errormessage"=>"Error"]);
      }
	
})->name('rejectsampleorder');




Route::get('/mapapprover', 'MenuController@mapapprover')->name('mapapprover');
Route::post('/getmapapprover', 'MenuController@getmapapprover')->name('getmapapprover');
Route::post('/savemapapprover', 'MenuController@savemapapprover')->name('savemapapprover');
Route::post('/deletemapapprover', 'MenuController@deletemapapprover')->name('deletemapapprover');
Route::post('/getmapapproverlist', 'MenuController@getmapapproverlist')->name('getmapapproverlist');
Route::post('/getmapapproverlist2', 'MenuController@getmapapproverlist2')->name('getmapapproverlist2');
Route::post('/savemapapprovermaster', 'MenuController@savemapapprovermaster')->name('savemapapprovermaster');
